package com.joainfo.gasmaxeye.bean.list;


import java.util.HashMap;
import java.util.LinkedHashMap;

import com.joainfo.gasmaxeye.bean.MyCompany;

/**
 * 업체지도정보 정보의 해시 집합
 * @author 서경엔씨에스
 * @version 1.0
 */
public class MyCompanyMap {

	/**
	 * MyCompany 목록
	 */
	private LinkedHashMap<String, MyCompany> myCompanys;
	
	/**
	 * 전체 건수
	 */
	private String totalRowCount;
	
	/**
	 * 디폴트 생성자
	 */
	public MyCompanyMap(){
		if (myCompanys == null) {
			myCompanys = new LinkedHashMap<String, MyCompany>();
		}
	}
	
	/**
	 * @return LinkedHashMap
	 */
	public LinkedHashMap<String, MyCompany> getMyCompanys(){
		return myCompanys;
	}
	
	/**
	 * @param myCompanys
	 */
	public void setMyCompanys(LinkedHashMap<String, MyCompany> myCompanys){
		this.myCompanys = myCompanys;
	}
	
	/**
	 * @param id
	 * @return MyCompany
	 */
	public MyCompany getMyCompany(String id){
		return this.myCompanys.get(id);
	}
	
	/**
	 * @param id
	 * @param myCompanys
	 */
	public void setMyCompany(String id, MyCompany myCompany){
		this.myCompanys.put(id, myCompany);
	}
	
	/**
	 * @param myCompany
	 */
	public void setTankLevelList(MyCompany myCompany){
		this.myCompanys.put(myCompany.getKeyValue(), myCompany);
	}
	
	/**
	 * @param id
	 */
	public void removeMyCompany(String id){
		this.myCompanys.remove(id);
	}
	
	/**
	 * @return the totalRowCount
	 */
	public String getTotalRowCount() {
		return totalRowCount;
	}

	/**
	 * @param totalRowCount the totalRowCount to set
	 */
	public void setTotalRowCount(String totalRowCount) {
		this.totalRowCount = totalRowCount;
	}

	/**
	 * @param id
	 * @return 키에 해당하는 값의 존재 여부를 반환
	 */
	public boolean isExist(String id){
		return  this.myCompanys.get(id)==null?false:true;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return myCompanys.toString();
	}
	
	/**
	 * @return XML
	 */
	public String toXML(){
		String xml = "<MyCompanys>";
				
		java.util.Iterator<String> iterator = myCompanys.keySet().iterator(); 
		
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			xml += myCompanys.get(key).toXML();
		  }
		xml += "</MyCompanys>";
		
		return xml; 
	}

	/**
	 * XML을 페이지로 나눠서 HashMap으로 반환
	 * @param rowCount 한 페이지에 들어갈 행의 개수
	 * @return 페이지로 나눠 XML을 담은 HashMap
	 */
	public HashMap<String, String> toPagingXML(int rowCount){
		int pageNumber = 1;
		int rowNumber = 1;
		int totalRowCount = myCompanys.size();
		this.setTotalRowCount("" + totalRowCount);
		HashMap<String, String> pageXML = new HashMap<String, String>();
		java.util.Iterator<String> iterator = myCompanys.keySet().iterator(); 
		String xml = "";
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			MyCompany myCompany = myCompanys.get(key);
			if (rowNumber < (pageNumber * rowCount)) {
				xml += myCompany.toXML();
			} else {
				xml +=  myCompany.toXML();
				pageXML.put(new Integer(pageNumber).toString(), "<MyCompanys>" + new String(xml) + "</MyCompanys>");
				xml = "";
				pageNumber ++;
			}
			rowNumber ++;
		}
		if (!"".equals(xml)){
			pageXML.put(new Integer(pageNumber).toString(),  "<MyCompanys>" + new String(xml) + "</MyCompanys>");
		}
		return pageXML;
	}
	
	/**
	 * @return JSON
	 */
	public String toJSON(){
		String json = "\"myCompanys\":[";
				
		java.util.Iterator<String> iterator = myCompanys.keySet().iterator(); 
		while (iterator.hasNext()) { 
			String key = iterator.next();
			json += myCompanys.get(key).toJSON();
			
			if (iterator.hasNext()) {
				json += ",";
			}
		  }
		json += "]";
		
		return json; 
	}
}
