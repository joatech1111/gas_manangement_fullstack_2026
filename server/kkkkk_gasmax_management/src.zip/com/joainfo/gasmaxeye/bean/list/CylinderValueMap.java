package com.joainfo.gasmaxeye.bean.list;

import java.util.HashMap;
import java.util.LinkedHashMap;

import com.joainfo.gasmaxeye.bean.CylinderValue;

/**
 * 절체기 주간수신내역 정보의 해시 집합
 * @author 백원태
 * @version 1.0
 */
public class CylinderValueMap {
	
	private String XML_START_TAG = "<CylinderValues>";
	private String XML_END_TAG = "</CylinderValues>";

	/**
	 * CylinderValue 목록
	 */
	private LinkedHashMap<String, CylinderValue> mItems;
	
	/**
	 * 전체 건수
	 */
	private String totalRowCount;
	
	/**
	 * 디폴트 생성자
	 */
	public CylinderValueMap() {
		if (mItems == null) {
			mItems = new LinkedHashMap<String, CylinderValue>();
		}
	}
	
	/**
	 * @return LinkedHashMap
	 */
	public LinkedHashMap<String, CylinderValue> getItems(){
		return mItems;
	}
	
	/**
	 * @param items
	 */
	public void setItems(LinkedHashMap<String, CylinderValue> items){
		this.mItems = items;
	}
	
	/**
	 * @param id
	 * @return CylinderValue
	 */
	public CylinderValue getItem(String id){
		return this.mItems.get(id);
	}
	
	/**
	 * @param id
	 * @param item
	 */
	public void setItem(String id, CylinderValue item){
		this.mItems.put(id, item);
	}
	
	/**
	 * @param item
	 */
	public void setItem(CylinderValue item){
		this.mItems.put(item.getKeyValue(), item);
	}
	
	/**
	 * @param id
	 */
	public void removeItem(String id){
		this.mItems.remove(id);
	}
	
	/**
	 * @return the totalRowCount
	 */
	public String getTotalRowCount() {
		return totalRowCount;
	}

	/**
	 * @param totalRowCount the totalRowCount to set
	 */
	public void setTotalRowCount(String totalRowCount) {
		this.totalRowCount = totalRowCount;
	}

	/**
	 * @param id
	 * @return 키에 해당하는 값의 존재 여부를 반환
	 */
	public boolean isExist(String id){
		return  this.mItems.get(id)==null?false:true;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return mItems.toString();
	}
	
	/**
	 * @return XML
	 */
	public String toXML(){
		String xml = XML_START_TAG;

		java.util.Iterator<String> iterator = mItems.keySet().iterator();
		while (iterator.hasNext()) {
			String key = iterator.next(); 
			xml += mItems.get(key).toXML();
		}

		xml += XML_END_TAG;
		
		return xml; 
	}

	/**
	 * XML을 페이지로 나눠서 HashMap으로 반환
	 * @param rowCount 한 페이지에 들어갈 행의 개수
	 * @return 페이지로 나눠 XML을 담은 HashMap
	 */
	public HashMap<String, String> toPagingXML(int rowCount){
		int pageNumber = 1;
		int rowNumber = 1;
		int totalRowCount = mItems.size();
		this.setTotalRowCount("" + totalRowCount);
		HashMap<String, String> pageXML = new HashMap<String, String>();
		java.util.Iterator<String> iterator = mItems.keySet().iterator(); 
		String xml = "";
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			CylinderValue item = mItems.get(key);
			if (rowNumber < (pageNumber * rowCount)) {
				xml += item.toXML();
			} else {
				xml +=  item.toXML();
				pageXML.put(new Integer(pageNumber).toString(), XML_START_TAG + new String(xml) + XML_END_TAG);
				xml = "";
				pageNumber ++;
			}
			rowNumber ++;
		}
		if (!"".equals(xml)){
			pageXML.put(new Integer(pageNumber).toString(),  XML_START_TAG + new String(xml) + XML_END_TAG);
		}
		return pageXML;
	}	
}