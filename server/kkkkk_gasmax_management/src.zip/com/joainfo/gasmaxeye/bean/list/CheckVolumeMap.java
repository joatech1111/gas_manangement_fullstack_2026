package com.joainfo.gasmaxeye.bean.list;


import java.util.HashMap;
import java.util.LinkedHashMap;

import com.joainfo.gasmaxeye.bean.CheckVolume;

/**
 * 체적검침 정보의 해시 집합
 * @author 백원태
 * @version 1.0
 */
public class CheckVolumeMap {

	/**
	 * CheckVolume 목록
	 */
	private LinkedHashMap<String, CheckVolume> checkVolumes;
	
	/**
	 * 전체 건수
	 */
	private String totalRowCount;
	
	/**
	 * 디폴트 생성자
	 */
	public CheckVolumeMap(){
		if (checkVolumes == null) {
			checkVolumes = new LinkedHashMap<String, CheckVolume>();
		}
	}
	
	/**
	 * @return LinkedHashMap
	 */
	public LinkedHashMap<String, CheckVolume> getCheckVolumes(){
		return checkVolumes;
	}
	
	/**
	 * @param checkVolumes
	 */
	public void setCheckVolumes(LinkedHashMap<String, CheckVolume> checkVolumes){
		this.checkVolumes = checkVolumes;
	}
	
	/**
	 * @param id
	 * @return CheckVolume
	 */
	public CheckVolume getCheckVolume(String id){
		return this.checkVolumes.get(id);
	}
	
	/**
	 * @param id
	 * @param checkVolume
	 */
	public void setCheckVolume(String id, CheckVolume checkVolume){
		this.checkVolumes.put(id, checkVolume);
	}
	
	/**
	 * @param checkVolume
	 */
	public void setCheckVolume(CheckVolume checkVolume){
		this.checkVolumes.put(checkVolume.getKeyValue(), checkVolume);
	}
	
	/**
	 * @param id
	 */
	public void removeCheckVolume(String id){
		this.checkVolumes.remove(id);
	}
	
	/**
	 * @return the totalRowCount
	 */
	public String getTotalRowCount() {
		return totalRowCount;
	}

	/**
	 * @param totalRowCount the totalRowCount to set
	 */
	public void setTotalRowCount(String totalRowCount) {
		this.totalRowCount = totalRowCount;
	}

	/**
	 * @param id
	 * @return 키에 해당하는 값의 존재 여부를 반환
	 */
	public boolean isExist(String id){
		return  this.checkVolumes.get(id)==null?false:true;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return checkVolumes.toString();
	}
	
	/**
	 * @return XML
	 */
	public String toXML(){
		String xml = "<CheckVolumes>";
				
		java.util.Iterator<String> iterator = checkVolumes.keySet().iterator(); 
		
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			xml += checkVolumes.get(key).toXML();
		  }
		xml += "</CheckVolumes>";
		
		return xml; 
	}

	/**
	 * XML을 페이지로 나눠서 HashMap으로 반환
	 * @param rowCount 한 페이지에 들어갈 행의 개수
	 * @return 페이지로 나눠 XML을 담은 HashMap
	 */
	public HashMap<String, String> toPagingXML(int rowCount){
		int pageNumber = 1;
		int rowNumber = 1;
		int totalRowCount = checkVolumes.size();
		this.setTotalRowCount("" + totalRowCount);
		HashMap<String, String> pageXML = new HashMap<String, String>();
		java.util.Iterator<String> iterator = checkVolumes.keySet().iterator(); 
		String xml = "";
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			CheckVolume checkVolume = checkVolumes.get(key);
			if (rowNumber < (pageNumber * rowCount)) {
				xml += checkVolume.toXML();
			} else {
				xml +=  checkVolume.toXML();
				pageXML.put(new Integer(pageNumber).toString(), "<CheckVolumes>" + new String(xml) + "</CheckVolumes>");
				xml = "";
				pageNumber ++;
			}
			rowNumber ++;
		}
		if (!"".equals(xml)){
			pageXML.put(new Integer(pageNumber).toString(),  "<CheckVolumes>" + new String(xml) + "</CheckVolumes>");
		}
		return pageXML;
	}
	
}
