package com.joainfo.gasmaxeye.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;
import com.joainfo.gasmaxeye.bean.attribute.USER_REGISTER_TYPE;

/**
 * 거래처 지도(위/경도) 정보
 * @author 서경엔씨에스
 * @version 1.0
 */
public class CustomerMap {
	/**
	 * 업체코드 - key
	 */
	private String clientNumber;

	/**
	 * 거래처 코드 - key
	 */
	private String customerCode;

	/**
	 * 위도
	 */
	private String latitudeX;

	/**
	 * 경도
	 */
	private String longitudeY;

	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap(){
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("C_MNG_NO", getClientNumber());
		keys.put("CUST_CODE", getCustomerCode());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}

	/**
	 * @return the clientNumber
	 */
	public String getClientNumber() {
		return clientNumber;
	}

	/**
	 * @param clientNumber the clientNumber to set
	 */
	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	/**
	 * @return the customerCode
	 */
	public String getCustomerCode() {
		return customerCode;
	}

	/**
	 * @param customerCode the customerCode to set
	 */
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	/**
	 * @return the latitudeX
	 */
	public String getLatitudeX() {
		return latitudeX;
	}

	/**
	 * @param latitudeX the latitudeX to set
	 */
	public void setLatitudeX(String latitudeX) {
		this.latitudeX = latitudeX;
	}

	/**
	 * @return the longitudeY
	 */
	public String getLongitudeY() {
		return longitudeY;
	}

	/**
	 * @param longitudeY the longitudeY to set
	 */
	public void setLongitudeY(String longitudeY) {
		this.longitudeY = longitudeY;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AppUser [key=" + this.getKeyValue() 
				+ ", clientNumber=" + clientNumber + ", customerCode=" + customerCode
				+ ", latitudeX=" + latitudeX + ", longitudeY=" + longitudeY + "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<CustomerMap><key>" + this.getKeyValue()
				+ "</key><clientNumber>" + clientNumber
				+ "</clientNumber><customerCode>" + customerCode
				+ "</customerCode><latitudeX>" + latitudeX
				+ "</latitudeX><longitudeY>" + longitudeY
				+ "</longitudeY></CustomerMap>";
	}

}
