package com.joainfo.gasmaxeye.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 절체기 상세내역 정보 모델
 * @author 백원태
 * @version 1.0
 */
public class CylinderCustomerReceiveList {
	/**
	 * C_MNG_NO
	 * 업체번호 - key
	 */
	 private String clientNumber;

	/**
	 * CUST_CODE
	 * 거래처코드 - key
	 */
	 private String customerCode;

	/**
	 * R_TRANSM_CD
	 * 발신기번호
	 */
	 private String receiveTransmitterCode;
	 
	 /**
	  * R_DATE
	  * 수신일(YYYYMMDD)
	  */
	 private String receiveDate;
	 
	 /**
	  * R_TIME
	  * 수신시간(HHNNSS)
	  */
	 private String receiveTime;
	 
	 /**
	  * R_LEVEL
	  * 원격검침 값(99999999.99)
	  */
	 private String receiveLevel;
	 
	 /**
	  * R_EVENT
	  * 1,3,5: 요청
	  * 2,4,6: 완료
	  */
	 private String receiveEvent;
	 
	 /**
	  * R_EVENT_DIV_NAME
	  * 이벤트명
	  */
	 private String receiveEventName;
	 
	 /**
	  * R_BAT
	  * 배터리 전압(9.99)
	  */
	 private String receiveBatteryVolt;

	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap(){
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("C_MNG_NO", getClientNumber());
		keys.put("CUST_CODE", getCustomerCode());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}

	/**
	 * @return the clientNumber
	 */
	public String getClientNumber() {
		return clientNumber;
	}

	/**
	 * @param clientNumber the clientNumber to set
	 */
	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	/**
	 * @return the customerCode
	 */
	public String getCustomerCode() {
		return customerCode;
	}

	/**
	 * @param customerCode the customerCode to set
	 */
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	/**
	 * @return the receiveTransmitterCode
	 */
	public String getReceiveTransmitterCode() {
		return receiveTransmitterCode;
	}

	/**
	 * @param receiveTransmitterCode the receiveTransmitterCode to set
	 */
	public void setReceiveTransmitterCode(String receiveTransmitterCode) {
		this.receiveTransmitterCode = receiveTransmitterCode;
	}

	/**
	 * @return the receiveDate
	 */
	public String getReceiveDate() {
		return receiveDate;
	}

	/**
	 * @param receiveDate the receiveDate to set
	 */
	public void setReceiveDate(String receiveDate) {
		this.receiveDate = receiveDate;
	}

	/**
	 * @return the receiveTime
	 */
	public String getReceiveTime() {
		return receiveTime;
	}

	/**
	 * @param receiveTime the receiveTime to set
	 */
	public void setReceiveTime(String receiveTime) {
		this.receiveTime = receiveTime;
	}

	/**
	 * @return the receiveLevel
	 */
	public String getReceiveLevel() {
		return receiveLevel;
	}

	/**
	 * @param receiveLevel the receiveLevel to set
	 */
	public void setReceiveLevel(String receiveLevel) {
		this.receiveLevel = receiveLevel;
	}

	/**
	 * @return the receiveEvent
	 */
	public String getReceiveEvent() {
		return receiveEvent;
	}

	/**
	 * @param receiveEvent the receiveEvent to set
	 */
	public void setReceiveEvent(String receiveEvent) {
		this.receiveEvent = receiveEvent;
	}

	/**
	 * @return the receiveEventName
	 */
	public String getReceiveEventName() {
		return receiveEventName;
	}

	/**
	 * @param receiveEventName the receiveEventName to set
	 */
	public void setReceiveEventName(String receiveEventName) {
		this.receiveEventName = receiveEventName;
	}

	/**
	 * @return the receiveBatteryVolt
	 */
	public String getReceiveBatteryVolt() {
		return receiveBatteryVolt;
	}

	/**
	 * @param receiveBatteryVolt the receiveBatteryVolt to set
	 */
	public void setReceiveBatteryVolt(String receiveBatteryVolt) {
		this.receiveBatteryVolt = receiveBatteryVolt;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CylinderCustomerReceiveList [key=" + this.getKeyValue() + ", clientNumber="
				+ clientNumber
				+ ", customerCode="
				+ customerCode
				+ ", receiveTransmitterCode="
				+ receiveTransmitterCode
				+ ", receiveDate="
				+ receiveDate
				+ ", receiveTime="
				+ receiveTime
				+ ", receiveLevel="
				+ receiveLevel
				+ ", receiveEvent="
				+ receiveEvent
				+ ", receiveEventName="
				+ receiveEventName
				+ ", receiveBatteryVolt="
				+ receiveBatteryVolt
				+ "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<CylinderCustomerReceiveList><key>" + this.getKeyValue() + "</key><clientNumber>"
				+ clientNumber + "</clientNumber><customerCode>"
				+ customerCode + "</customerCode><receiveTransmitterCode>"
				+ receiveTransmitterCode + "</receiveTransmitterCode><receiveDate>"
				+ receiveDate + "</receiveDate><receiveTime>"
				+ receiveTime + "</receiveTime><receiveLevel>"
				+ receiveLevel + "</receiveLevel><receiveEvent>"
				+ receiveEvent + "</receiveEvent><receiveEventName><![CDATA["
				+ receiveEventName + "]]></receiveEventName><receiveBatteryVolt>"
				+ receiveBatteryVolt + "</receiveBatteryVolt></CylinderCustomerReceiveList>";
	}
		
}
