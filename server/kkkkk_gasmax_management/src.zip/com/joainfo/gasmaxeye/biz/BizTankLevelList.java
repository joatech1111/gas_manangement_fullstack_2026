package com.joainfo.gasmaxeye.biz;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.joainfo.common.util.jdbc.JdbcUtil;
import com.joainfo.gasmaxeye.bean.MyCompany;
import com.joainfo.gasmaxeye.bean.TankLevelList;
import com.joainfo.gasmaxeye.bean.list.MyCompanyMap;
import com.joainfo.gasmaxeye.bean.list.TankLevelListMap;

/**
 * BizTankLevelList
 * 탱크잔량조회 비즈니스 로직 처리 객체
 * @author 서경엔씨에스
 * @version 1.0
 */
public class BizTankLevelList {


	/**
	 * 탕크잔량조회 Select 쿼리의 ID
	 */
	public final String GASMAXEYE_TANK_LEVEL_LIST_SELECT_ID = "GASMAXEYE.TankLevelList.Select";
	
	/**
	 * 업체정보조회 Select 쿼리의 ID
	 */
	public final String GASMAXEYE_MY_COMPANY_SELECT_ID = "GASMAXEYE.MyCompany.Select";
	
	/**
	 * 탱크잔량조회 디폴트 DB 설정
	 */
	public final static String DEFAULT_TANK_LEVEL_LIST_SQL_CONFIG = "gasmaxeye_map";
	
	/**
	 * 탱크잔량조회 디폴트 DB 카탈로그 명
	 */
	public final static String DEFAULT_TANK_LEVEL_LIST_CATATLOG_NAME = "GasMax_EYE";
	
	/**
	 * BizTankLevelList 인스턴스
	 */
	private static BizTankLevelList bizTankLevelList;
	
	/**
	 * 디폴트 생성자
	 */
	public BizTankLevelList(){
	}
	
	/**
	 * Singleton으로 BizTankLevelList 인스턴스 생성
	 * @return bizTankLevelList
	 */
	public static BizTankLevelList getInstance(){
		if (bizTankLevelList == null){
			bizTankLevelList = new BizTankLevelList();
		}
		return bizTankLevelList;
	}
	
	/**
	 * 업체코드, 사원코드, 지역코드, 키워드로 검색한 탱크잔량 목록을 반환
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param clientNumber
	 * @param sawonCode
	 * @param areaTypeCode
	 * @param keyword
	 * @param dayLevel9
	 * @param dayLevel8
	 * @param dayLevel7
	 * @param dayLevel6
	 * @param dayLevel5
	 * @param dayLevel4
	 * @param dayLevel3
	 * @param dayLevel2
	 * @param dayLevel1
	 * @param dayLevel0
	 * @return tankLevelLists
	 */
	public TankLevelListMap getTankLevelLists(String clientNumber, String sawonCode, String areaTypeCode, String keyword, String levelStates, String noneMapPoint, String receiveDateOver, String uniformLevel, String lowBattery, String dayLevel9, String dayLevel8, String dayLevel7, String dayLevel6, String dayLevel5, String dayLevel4, String dayLevel3, String dayLevel2, String dayLevel1, String dayLevel0){
		String serverIp = BizTankLevelList.DEFAULT_TANK_LEVEL_LIST_SQL_CONFIG;
		String catalogName = BizTankLevelList.DEFAULT_TANK_LEVEL_LIST_CATATLOG_NAME;
		
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("clientNumber", clientNumber);
		condition.put("sawonCode", sawonCode);
		condition.put("areaTypeCode", areaTypeCode);
		condition.put("keyword", keyword);
		condition.put("dayLevel9", dayLevel9);
		condition.put("dayLevel8", dayLevel8);
		condition.put("dayLevel7", dayLevel7);
		condition.put("dayLevel6", dayLevel6);
		condition.put("dayLevel5", dayLevel5);
		condition.put("dayLevel4", dayLevel4);
		condition.put("dayLevel3", dayLevel3);
		condition.put("dayLevel2", dayLevel2);
		condition.put("dayLevel1", dayLevel1);
		condition.put("dayLevel0", dayLevel0);
		
		condition.put("levelStates", levelStates);
		
		condition.put("noneMapPoint", noneMapPoint);
		condition.put("receiveDateOver", receiveDateOver);
		condition.put("uniformLevel", uniformLevel);
		condition.put("lowBattery", lowBattery);

		return selectTankLevelLists(serverIp, catalogName, condition);
	}
	
	/**
	 * 탱크잔량 조회
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param condition 검색 조건
	 * @return TankLevelListMap 형식의 탱크잔량 목록 반환
	 */
	public TankLevelListMap selectTankLevelLists(String serverIp, String catalogName, Map<String, String> condition){
		TankLevelListMap tankLevelLists = new TankLevelListMap();
		condition.put("catalogName", catalogName);
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXEYE_TANK_LEVEL_LIST_SELECT_ID, condition);
		for( HashMap<String, String> map :  list) {
			TankLevelList tankLevelList = convertTankLevelList(map);
			tankLevelLists.setTankLevelList(tankLevelList.getKeyValue(), tankLevelList);
		}
		return tankLevelLists;
	}
	/**
	 * HashMap을 TankLevelList으로 변환
	 * @param map
	 * @return TankLevelList
	 */
	protected static TankLevelList convertTankLevelList(HashMap<String, String> map){
		TankLevelList tankLevelList = new TankLevelList();
		
		tankLevelList.setClientNumber(map.get("clientNumber"));
		tankLevelList.setCustomerCode(map.get("customerCode"));
		tankLevelList.setTankCode(map.get("tankCode"));
		tankLevelList.setTransmitterCode(map.get("transmitterCode"));
		
		tankLevelList.setCustomerName(map.get("customerName"));
		tankLevelList.setCustomerTel(map.get("customerTel"));
		tankLevelList.setCustomerHp(map.get("customerHp"));
		tankLevelList.setSawonCode(map.get("sawonCode"));
		tankLevelList.setSawonName(map.get("sawonName"));
		tankLevelList.setAreaTypeCode(map.get("areaTypeCode"));
		tankLevelList.setAreaTypeName(map.get("areaTypeName"));
		tankLevelList.setZipCode(map.get("zipCode"));	
		tankLevelList.setAddress(map.get("address"));
		tankLevelList.setLatitude(map.get("latitude"));
		tankLevelList.setLongitude(map.get("longitude"));
		tankLevelList.setAlarmLevel(map.get("alarmLevel"));
		tankLevelList.setRemark(map.get("remark"));
		
		tankLevelList.setMakeCompany(map.get("makeCompany"));
		tankLevelList.setTankSerialNumber(map.get("tankSerialNumber"));
		tankLevelList.setMakeSerialNumber(map.get("makeSerialNumber"));
		tankLevelList.setTankVolume(map.get("tankVolume"));
		tankLevelList.setMakeDate(map.get("makeDate"));
		tankLevelList.setTankReceive(map.get("tankReceive"));
		tankLevelList.setInstallDate(map.get("installDate"));
		tankLevelList.setInspectDate(map.get("inspectDate"));
		tankLevelList.setInspectExpectDate(map.get("inspectExpectDate"));
		tankLevelList.setMonthCount(map.get("monthCount"));
		tankLevelList.setDayCount(map.get("dayCount"));
		
		tankLevelList.setLevel9(map.get("level9"));
		tankLevelList.setLevel8(map.get("level8"));
		tankLevelList.setLevel7(map.get("level7"));
		tankLevelList.setLevel6(map.get("level6"));
		tankLevelList.setLevel5(map.get("level5"));
		tankLevelList.setLevel4(map.get("level4"));
		tankLevelList.setLevel3(map.get("level3"));
		tankLevelList.setLevel2(map.get("level2"));
		tankLevelList.setLevel1(map.get("level1"));
		tankLevelList.setLevel0(map.get("level0"));
		
		tankLevelList.setTransmitterSerialNumber(map.get("transmitterSerialNumber"));
		tankLevelList.setTransmitterTypeName(map.get("transmitterTypeName"));
		tankLevelList.setTransmitterBatteryName(map.get("transmitterBatteryName"));
		tankLevelList.setTransmitterTel(map.get("transmitterTel"));
		tankLevelList.setTransmitterRent(map.get("transmitterRent"));
		
		tankLevelList.setLastReceiveDate(map.get("lastReceiveDate"));
		tankLevelList.setLastReceiveTime(map.get("lastReceiveTime"));
		tankLevelList.setLastLevel(map.get("lastLevel"));
		tankLevelList.setReceiveEvent(map.get("receiveEvent"));
		tankLevelList.setReceiveEventName(map.get("receiveEventName"));
		tankLevelList.setBatteryPercent(map.get("batteryPercent"));
		tankLevelList.setReceiveBatteryVolt(map.get("receiveBatteryVolt"));
		
		tankLevelList.setLevelState(map.get("levelState"));
		tankLevelList.setReceiveDateOver(map.get("receiveDateOver"));
		tankLevelList.setUniformLevel(map.get("uniformLevel"));
		tankLevelList.setLowBattery(map.get("lowBattery"));
		
		return tankLevelList;
	}
	
	protected static HashMap<String, String> convertTankLevelList(TankLevelList tankLevelList){
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", tankLevelList.getClientNumber());
	    map.put("customerCode", tankLevelList.getCustomerCode());
	    map.put("tankCode", tankLevelList.getTankCode());
	    map.put("transmitterCode", tankLevelList.getTransmitterCode());
	    
	    map.put("customerName", tankLevelList.getCustomerName());
	    map.put("customerTel", tankLevelList.getCustomerTel());
	    map.put("customerHp", tankLevelList.getCustomerHp());
	    map.put("sawonCode", tankLevelList.getSawonCode());
	    map.put("sawonName", tankLevelList.getSawonName());
	    map.put("areaTypeCode", tankLevelList.getAreaTypeCode());
	    map.put("areaTypeName", tankLevelList.getAreaTypeName());
	    map.put("zipCode", tankLevelList.getZipCode());
	    map.put("address", tankLevelList.getAddress());
	    map.put("latitude", tankLevelList.getLatitude());
	    map.put("longitude", tankLevelList.getLongitude());
	    map.put("alarmLevel", tankLevelList.getAlarmLevel());
	    map.put("remark", tankLevelList.getRemark());
	    
	    map.put("makeCompany", tankLevelList.getMakeCompany());
	    map.put("tankSerialNumber", tankLevelList.getTankSerialNumber());
	    map.put("makeSerialNumber", tankLevelList.getMakeSerialNumber());
	    map.put("tankVolume", tankLevelList.getTankVolume());
	    map.put("makeDate", tankLevelList.getMakeDate());
	    map.put("tankReceive", tankLevelList.getTankReceive());
	    map.put("installDate", tankLevelList.getInstallDate());
	    map.put("inspectDate", tankLevelList.getInspectDate());
	    map.put("inspectExpectDate", tankLevelList.getInspectExpectDate());
	    map.put("monthCount", tankLevelList.getMonthCount());
	    map.put("dayCount", tankLevelList.getDayCount());
	    
	    map.put("level9", tankLevelList.getLevel9());
	    map.put("level8", tankLevelList.getLevel8());
	    map.put("level7", tankLevelList.getLevel7());
	    map.put("level6", tankLevelList.getLevel6());
	    map.put("level5", tankLevelList.getLevel5());
	    map.put("level4", tankLevelList.getLevel4());
	    map.put("level3", tankLevelList.getLevel3());
	    map.put("level2", tankLevelList.getLevel2());
	    map.put("level1", tankLevelList.getLevel1());
	    map.put("level0", tankLevelList.getLevel0());
	    
	    map.put("transmitterSerialNumber", tankLevelList.getTransmitterSerialNumber());
	    map.put("transmitterTypeName", tankLevelList.getTransmitterTypeName());
	    map.put("transmitterBatteryName", tankLevelList.getTransmitterBatteryName());
	    map.put("transmitterTel", tankLevelList.getTransmitterTel());
	    map.put("transmitterRent", tankLevelList.getTransmitterRent());
	    
	    map.put("lastReceiveDate", tankLevelList.getLastReceiveDate());
	    map.put("lastReceiveTime", tankLevelList.getLastReceiveTime());	    
	    map.put("lastLevel", tankLevelList.getLastLevel());
	    map.put("receiveEvent", tankLevelList.getReceiveEvent());
	    map.put("receiveEventName", tankLevelList.getReceiveEventName());
	    map.put("batteryPercent", tankLevelList.getBatteryPercent());
	    map.put("receiveBatteryVolt", tankLevelList.getReceiveBatteryVolt());
	    
	    map.put("levelState", tankLevelList.getLevelState());
	    map.put("receiveDateOver", tankLevelList.getReceiveDateOver());
	    map.put("uniformLevel", tankLevelList.getUniformLevel());
	    map.put("lowBattery", tankLevelList.getLowBattery());
		
		return map;
	}
	
	/**
	 * 업체코드, 사원코드, 지역코드, 키워드로 검색한 탱크잔량 목록을 반환
	 * @param clientNumber
	 * @return myCompanys
	 */
	public MyCompanyMap getMyCompany(String clientNumber){
		String serverIp = BizTankLevelList.DEFAULT_TANK_LEVEL_LIST_SQL_CONFIG;
		String catalogName = BizTankLevelList.DEFAULT_TANK_LEVEL_LIST_CATATLOG_NAME;
		
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("clientNumber", clientNumber);

		return selectMyCompany(serverIp, catalogName, condition);
	}
	
	/**
	 * 탱크잔량 조회
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param condition 검색 조건
	 * @return MyCompanyMap 형식의 탱크잔량 목록 반환
	 */
	public MyCompanyMap selectMyCompany(String serverIp, String catalogName, Map<String, String> condition){
		MyCompanyMap myCompanys = new MyCompanyMap();
		condition.put("catalogName", catalogName);
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXEYE_MY_COMPANY_SELECT_ID, condition);
		for( HashMap<String, String> map :  list) {
			MyCompany myCompany = convertMyCompany(map);
			myCompanys.setMyCompany(myCompany.getKeyValue(), myCompany);
		}
		return myCompanys;
	}
	/**
	 * HashMap을 MyCompany으로 변환
	 * @param map
	 * @return MyCompany
	 */
	protected static MyCompany convertMyCompany(HashMap<String, String> map){
		MyCompany myCompany = new MyCompany();
		
		myCompany.setClientNumber(map.get("clientNumber"));
		myCompany.setCompanyName(map.get("companyName"));
		myCompany.setZipCode(map.get("zipCode"));	
		myCompany.setAddress(map.get("address"));
		myCompany.setLatitude(map.get("latitude"));
		myCompany.setLongitude(map.get("longitude"));
		
		return myCompany;
	}
	
	protected static HashMap<String, String> convertMyCompany(MyCompany myCompany){
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", myCompany.getClientNumber());
	    map.put("customerName", myCompany.getCompanyName());
	    map.put("zipCode", myCompany.getZipCode());
	    map.put("address", myCompany.getAddress());
	    map.put("latitude", myCompany.getLatitude());
	    map.put("longitude", myCompany.getLongitude());
		
		return map;
	}
	
	/**
	 * 비즈니스 로직 테스트용
	 * @param args
	 */
	public static void main(String[] args){
//		BizTankLevelList bizTankLevelList = BizTankLevelList.getInstance();
		
//		JSONObject jsonObject = JSONObject.fromObject(new HashMap<String, String>);
		

		
/* SELECT */
//		String clientNumber = "0255";
//		String sawonCode = "";
//		String areaTypeCode = "";
//		String keyword = "";
//		
//		String dayLevel9 = "20160920";
//		String dayLevel8 = "20160920";
//		String dayLevel7 = "20160920";
//		String dayLevel6 = "20160920";
//		String dayLevel5 = "20160920";
//		String dayLevel4 = "20160920";
//		String dayLevel3 = "20160920";
//		String dayLevel2 = "20160920";
//		String dayLevel1 = "20160920";
//		String dayLevel0 = "20160920";
//		
//		TankLevelListMap tankLevelLists = BizTankLevelList.getInstance().getTankLevelLists(
//				clientNumber, sawonCode, areaTypeCode, keyword, 
//				dayLevel9, dayLevel8, dayLevel7, dayLevel6, dayLevel5, dayLevel4, dayLevel3, dayLevel2, dayLevel1, dayLevel0);		
//		System.out.println(tankLevelLists.toXML());
	}
}
