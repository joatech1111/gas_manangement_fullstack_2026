package com.joainfo.gasmaxeye.biz;

import java.util.HashMap;

import com.joainfo.common.util.jdbc.JdbcUtil;
import com.joainfo.gasmaxeye.bean.CustomerMap;

/**
 * BizCustomerMap
 * 거래처 지도 비즈니스 로직 처리 객체
 * @author 서경엔씨에스
 * @version 1.0
 */
public class BizCustomerMap {

	/**
	 * 거래처 지도정보 업데이트 쿼리의 ID
	 */
	public final String GASMAXEYE_CUSTOMER_MAP_XY_UPDATE_ID = "GASMAXEYE.CustomerMapXY.Update";
	
	/**
	 * 거래처 지도정보 디폴트 DB 설정
	 */
	public final static String DEFAULT_CUSTOMER_MAP_XY_SQL_CONFIG = "gasmaxeye_map";
	
	/**
	 * 거래처 지도정보 디폴트 DB 카탈로그 명
	 */
	public final static String DEFAULT_CUSTOMER_MAP_XY_CATATLOG_NAME = "GasMax_EYE";

	/**
	 * BizCustomerMap 인스턴스
	 */
	private static BizCustomerMap bizCustomerMap;
	
	/**
	 * 디폴트 생성자
	 */
	public BizCustomerMap(){
	}
	
	/**
	 * Singleton으로 BizCustomerMap 인스턴스 생성
	 * @return bizCustomerMap
	 */
	public static BizCustomerMap getInstance(){
		if (bizCustomerMap == null){
			bizCustomerMap = new BizCustomerMap();
		}
		return bizCustomerMap;
	}
	
	/**
	 * @param clientNumber
	 * @param customerCode
	 * @param latitudeX
	 * @param longitudeY
	 * @return
	 */
	public int setCustomerMapXY(String clientNumber, String customerCode, String latitudeX, String longitudeY){
		HashMap<String, String> condition = new HashMap<String, String>();
		
		condition.put("clientNumber", clientNumber);
		condition.put("customerCode", customerCode);
		condition.put("latitudeX", latitudeX);
		condition.put("longitudeY", longitudeY);

		return updateCustomerMapXY(condition);
	}
	
	/**
	 * @param condition
	 * @return
	 */
	protected int updateCustomerMapXY(HashMap<String, String> condition){
		return JdbcUtil.getInstance(DEFAULT_CUSTOMER_MAP_XY_SQL_CONFIG).executeProcedure(GASMAXEYE_CUSTOMER_MAP_XY_UPDATE_ID, condition);
	}
	
	/**
	 * HashMap을 CustomerMap으로 변환
	 * @param map
	 * @return CustomerMap
	 */
	protected static CustomerMap convertCustomerMap(HashMap<String, String> map){
		CustomerMap customerMap = new CustomerMap();
		customerMap.setClientNumber(map.get("clientNumber"));
		customerMap.setCustomerCode(map.get("customerCode"));
		customerMap.setLatitudeX(map.get("latitudeX"));
		customerMap.setLongitudeY(map.get("longitudeY"));
		
		return customerMap;
	}
	
	protected static HashMap<String, String> convertAppUser(CustomerMap customerMap){
		HashMap<String, String> map = new HashMap<String, String>();
		
		map.put("clientNumber", customerMap.getClientNumber());
		map.put("customerCode", customerMap.getCustomerCode());
		map.put("latitudeX", customerMap.getLatitudeX());
		map.put("longitudeY", customerMap.getLongitudeY());
		
		return map;
	}
	
	/**
	 * 비즈니스 로직 테스트용
	 * @param args
	 */
	public static void main(String[] args){
//		BizCustomerMap bizCustomerMap = BizCustomerMap.getInstance();
	}
}
