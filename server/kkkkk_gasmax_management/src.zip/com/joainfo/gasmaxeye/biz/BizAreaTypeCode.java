package com.joainfo.gasmaxeye.biz;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.joainfo.common.util.jdbc.JdbcUtil;
import com.joainfo.gasmaxeye.bean.AreaTypeCode;
import com.joainfo.gasmaxeye.bean.list.AreaTypeCodeMap;

/**
 * BizAreaTypeCode
 * 지역코드 비즈니스 로직 처리 객체
 * @author 백원태
 * @version 1.0
 */
public class BizAreaTypeCode {


	/**
	 * 지역코드 Select 쿼리의 ID
	 */
	public final String GASMAXEYE_AREA_TYPE_CODE_SELECT_ID = "GASMAXEYE.AreaTypeCode.Select";
	
	/**
	 * BizAreaTypeCode 인스턴스
	 */
	private static BizAreaTypeCode bizAreaTypeCode;
	
	/**
	 * 디폴트 생성자
	 */
	public BizAreaTypeCode(){
	}
	
	/**
	 * Singleton으로 BizAreaTypeCode 인스턴스 생성
	 * @return bizAreaTypeCode
	 */
	public static BizAreaTypeCode getInstance(){
		if (bizAreaTypeCode == null){
			bizAreaTypeCode = new BizAreaTypeCode();
		}
		return bizAreaTypeCode;
	}
	
	/**
	 * 키워드로 검색한 지역코드 목록을 반환
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param clientNumber
	 * @return areaTypeCodes
	 */
	public AreaTypeCodeMap getAreaTypeCodes(String serverIp, String catalogName, String clientNumber){
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("clientNumber", clientNumber);
		return selectAreaTypeCodes(serverIp, catalogName, condition);
	}
	
	/**
	 * 지역코드 조회
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param condition 검색 조건
	 * @return AreaTypeCodeMap 형식의 지역코드 목록 반환
	 */
	public AreaTypeCodeMap selectAreaTypeCodes(String serverIp, String catalogName, Map<String, String> condition){
		AreaTypeCodeMap areaTypeCodes = new AreaTypeCodeMap();
		condition.put("catalogName", catalogName);
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXEYE_AREA_TYPE_CODE_SELECT_ID, condition);
		for( HashMap<String, String> map :  list) {
			AreaTypeCode areaTypeCode = convertAreaTypeCode(map);
			areaTypeCodes.setAreaTypeCode(areaTypeCode.getKeyValue(), areaTypeCode);
		}
		return areaTypeCodes;
	}
	/**
	 * HashMap을 AreaTypeCode으로 변환
	 * @param map
	 * @return AreaTypeCode
	 */
	protected static AreaTypeCode convertAreaTypeCode(HashMap<String, String> map){
		AreaTypeCode areaTypeCode = new AreaTypeCode();
		
		areaTypeCode.setClientNumber(map.get("clientNumber"));
		areaTypeCode.setAreaTypeCode(map.get("areaTypeCode"));
		areaTypeCode.setAreaTypeName(map.get("areaTypeName"));
		
		return areaTypeCode;
	}
	
	protected static HashMap<String, String> convertAreaTypeCode(AreaTypeCode areaTypeCode){
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", areaTypeCode.getClientNumber());
	    map.put("areaTypeCode", areaTypeCode.getAreaTypeCode());
	    map.put("areaTypeName", areaTypeCode.getAreaTypeName());
		
		return map;
	}
	
	/**
	 * 비즈니스 로직 테스트용
	 * @param args
	 */
	public static void main(String[] args){
//		BizAreaTypeCode bizAreaTypeCode = BizAreaTypeCode.getInstance();
		
//		JSONObject jsonObject = JSONObject.fromObject(new HashMap<String, String>);
		

		
/* SELECT */
		String serverIp = "joainfo.dyndns.org";
		String catalogName = "GasMax_EYE";
		String clientNumber = "0157";
		AreaTypeCodeMap areaTypeCodes = BizAreaTypeCode.getInstance().getAreaTypeCodes(serverIp, catalogName, clientNumber);		
		System.out.println(areaTypeCodes.toXML());

/* INSERT OR UPDATE*/
//		AreaTypeCode areaTypeCode = new AreaTypeCode();
//		areaTypeCode.setAreaTypeCodeCode("TEST1");
//		areaTypeCode.setAreaTypeCodeName("TEST AreaTypeCode1");
//		areaTypeCode.setUseYesNo("Y");
//		BizAreaTypeCode.getInstance().applyAreaTypeCode(areaTypeCode);
		
/* DELETE */
//		BizAreaTypeCode.getInstance().deleteAreaTypeCode("TEST");
		
/* DELETE LIST */
//		List<String> list = new java.util.ArrayList<String>();
//		list.add("TEST1");
//		list.add("TEST2");
//		BizAreaTypeCode.getInstance().deleteAreaTypeCodes(list);

/* SELECT */
//		BizAreaTypeCode.getInstance().initCacheAreaTypeCodes();
//		System.out.println(cacheAreaTypeCodes.toXML());
//		

//		System.out.println(cacheAreaTypeCodes.toXML());
	}
}
