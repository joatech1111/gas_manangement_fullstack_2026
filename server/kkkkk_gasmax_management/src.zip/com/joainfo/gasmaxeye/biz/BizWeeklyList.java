package com.joainfo.gasmaxeye.biz;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.joainfo.common.util.jdbc.JdbcUtil;
import com.joainfo.gasmaxeye.bean.WeeklyList;
import com.joainfo.gasmaxeye.bean.list.WeeklyListMap;

/**
 * BizWeeklyList
 * 주간수신내역 비즈니스 로직 처리 객체
 * @author 백원태
 * @version 1.0
 */
public class BizWeeklyList {


	/**
	 * 주간수신내역 Select 쿼리의 ID
	 */
	public final String GASMAXEYE_WEEKLY_LIST_SELECT_ID = "GASMAXEYE.WeeklyList.Select";
	
	/**
	 * BizWeeklyList 인스턴스
	 */
	private static BizWeeklyList bizWeeklyList;
	
	/**
	 * 디폴트 생성자
	 */
	public BizWeeklyList(){
	}
	
	/**
	 * Singleton으로 BizWeeklyList 인스턴스 생성
	 * @return bizWeeklyList
	 */
	public static BizWeeklyList getInstance(){
		if (bizWeeklyList == null){
			bizWeeklyList = new BizWeeklyList();
		}
		return bizWeeklyList;
	}
	
	/**
	 * 키워드로 검색한 주간수신내역 목록을 반환
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param keyword
	 * @param employeeCode
	 * @param areaTypeCode
	 * @param dayLevel6
	 * @param dayLevel5
	 * @param dayLevel4
	 * @param dayLevel3
	 * @param dayLevel2
	 * @param dayLevel1
	 * @param dayLevel0
	 * @param orderBy
	 * @return weeklyLists
	 */
	public WeeklyListMap getWeeklyLists(String serverIp, String catalogName, String searchType, String clientNumber, String keyword, String employeeCode, String areaTypeCode, String dayLevel6, String dayLevel5, String dayLevel4, String dayLevel3, String dayLevel2, String dayLevel1, String dayLevel0, String orderBy){
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("clientNumber", clientNumber);
		String functionName = "N".equals(searchType)?"fn_WEEK_RCV_LIST_ALL_2016":"fn_WEEK_RCV_LIST_2016";
		condition.put("functionName", functionName);
		condition.put("keyword", keyword);
		condition.put("employeeCode", employeeCode);
		condition.put("areaTypeCode", areaTypeCode);
		condition.put("dayLevel6", dayLevel6);
		condition.put("dayLevel5", dayLevel5);
		condition.put("dayLevel4", dayLevel4);
		condition.put("dayLevel3", dayLevel3);
		condition.put("dayLevel2", dayLevel2);
		condition.put("dayLevel1", dayLevel1);
		condition.put("dayLevel0", dayLevel0);
		if ("ALARM".equals(orderBy)) {
			condition.put("ALARM", "Y");
		} else if ("CHECK_YN".equals(orderBy)){
			condition.put("CHECK_YN", "Y");
		} else {
			condition.put("orderBy", orderBy);
		}
		return selectWeeklyLists(serverIp, catalogName, condition);
	}
	
	/**
	 * 주간수신내역 조회
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param condition 검색 조건
	 * @return WeeklyListMap 형식의 주간수신내역 목록 반환
	 */
	public WeeklyListMap selectWeeklyLists(String serverIp, String catalogName, Map<String, String> condition){
		WeeklyListMap weeklyLists = new WeeklyListMap();
		condition.put("catalogName", catalogName);
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXEYE_WEEKLY_LIST_SELECT_ID, condition);
		for( HashMap<String, String> map :  list) {
			WeeklyList weeklyList = convertWeeklyList(map);
			weeklyLists.setWeeklyList(weeklyList.getKeyValue(), weeklyList);
		}
		return weeklyLists;
	}
	/**
	 * HashMap을 WeeklyList으로 변환
	 * @param map
	 * @return WeeklyList
	 */
	protected static WeeklyList convertWeeklyList(HashMap<String, String> map){
		WeeklyList weeklyList = new WeeklyList();
		
		weeklyList.setClientNumber(map.get("clientNumber"));
		weeklyList.setTankCode(map.get("tankCode"));
		weeklyList.setCustomerCode(map.get("customerCode"));
		weeklyList.setTransmitterCode(map.get("transmitterCode"));
		weeklyList.setTankCapacity(map.get("tankCapacity"));
		weeklyList.setCustomerName(map.get("customerName"));
		weeklyList.setInstallationDate(map.get("installationDate"));
		weeklyList.setPhoneNumber(map.get("phoneNumber"));
		weeklyList.setMobileNumber(map.get("mobileNumber"));
		weeklyList.setAddress(map.get("address"));
		weeklyList.setLevel6(map.get("level6"));
		weeklyList.setLevel5(map.get("level5"));
		weeklyList.setLevel4(map.get("level4"));
		weeklyList.setLevel3(map.get("level3"));
		weeklyList.setLevel2(map.get("level2"));
		weeklyList.setLevel1(map.get("level1"));
		weeklyList.setLevel0(map.get("level0"));
		weeklyList.setLastReceiveDate(map.get("lastReceiveDate"));
		weeklyList.setLastLevel(map.get("lastLevel"));
		weeklyList.setRemark(map.get("remark"));
		
		return weeklyList;
	}
	
	protected static HashMap<String, String> convertWeeklyList(WeeklyList weeklyList){
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", weeklyList.getClientNumber());
	    map.put("tankCode", weeklyList.getTankCode());
	    map.put("customerCode", weeklyList.getCustomerCode());
	    map.put("transmitterCode", weeklyList.getTransmitterCode());
	    map.put("tankCapacity", weeklyList.getTankCapacity());
	    map.put("customerName", weeklyList.getCustomerName());
	    map.put("installationDate", weeklyList.getInstallationDate());
	    map.put("phoneNumber", weeklyList.getPhoneNumber());
	    map.put("mobileNumber", weeklyList.getMobileNumber());
	    map.put("address", weeklyList.getAddress());
	    map.put("level6", weeklyList.getLevel6());
	    map.put("level5", weeklyList.getLevel5());
	    map.put("level4", weeklyList.getLevel4());
	    map.put("level3", weeklyList.getLevel3());
	    map.put("level2", weeklyList.getLevel2());
	    map.put("level1", weeklyList.getLevel1());
	    map.put("level0", weeklyList.getLevel0());
	    map.put("lastReceiveDate", weeklyList.getLastReceiveDate());
	    map.put("lastLevel", weeklyList.getLastLevel());
	    map.put("remark", weeklyList.getRemark());
		
		return map;
	}
	
	/**
	 * 비즈니스 로직 테스트용
	 * @param args
	 */
	public static void main(String[] args){
//		BizWeeklyList bizWeeklyList = BizWeeklyList.getInstance();
		
//		JSONObject jsonObject = JSONObject.fromObject(new HashMap<String, String>);
		

		
/* SELECT */
//		WeeklyListMap weeklyLists = BizWeeklyList.getInstance().getWeeklyLists();		
//		System.out.println(weeklyLists.toXML());

/* INSERT OR UPDATE*/
//		WeeklyList weeklyList = new WeeklyList();
//		weeklyList.setWeeklyListCode("TEST1");
//		weeklyList.setWeeklyListName("TEST WeeklyList1");
//		weeklyList.setUseYesNo("Y");
//		BizWeeklyList.getInstance().applyWeeklyList(weeklyList);
		
/* DELETE */
//		BizWeeklyList.getInstance().deleteWeeklyList("TEST");
		
/* DELETE LIST */
//		List<String> list = new java.util.ArrayList<String>();
//		list.add("TEST1");
//		list.add("TEST2");
//		BizWeeklyList.getInstance().deleteWeeklyLists(list);

/* SELECT */
//		BizWeeklyList.getInstance().initCacheWeeklyLists();
//		System.out.println(cacheWeeklyLists.toXML());
//		

//		System.out.println(cacheWeeklyLists.toXML());
	}
}
