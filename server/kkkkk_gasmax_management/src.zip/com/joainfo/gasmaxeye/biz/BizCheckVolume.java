package com.joainfo.gasmaxeye.biz;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.joainfo.common.util.jdbc.JdbcUtil;
import com.joainfo.gasmaxeye.bean.CheckVolume;
import com.joainfo.gasmaxeye.bean.list.CheckVolumeMap;

/**
 * BizCheckVolume
 * 체적검침 비즈니스 로직 처리 객체
 * @author 백원태
 * @version 1.0
 */
public class BizCheckVolume {


	/**
	 * 체적검침 Select 쿼리의 ID
	 */
	public final String GASMAXEYE_CHECK_VOLUME_SELECT_ID = "GASMAXEYE.CheckVolume.Select";
	
	/**
	 * BizCheckVolume 인스턴스
	 */
	private static BizCheckVolume bizCheckVolume;
	
	/**
	 * 디폴트 생성자
	 */
	public BizCheckVolume(){
	}
	
	/**
	 * Singleton으로 BizCheckVolume 인스턴스 생성
	 * @return bizCheckVolume
	 */
	public static BizCheckVolume getInstance(){
		if (bizCheckVolume == null){
			bizCheckVolume = new BizCheckVolume();
		}
		return bizCheckVolume;
	}
	
	/**
	 * 키워드로 검색한 체적검침 목록을 반환
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param keyword
	 * @param employeeCode
	 * @param areaTypeCode
	 * @param dayLevel6
	 * @param dayLevel5
	 * @param dayLevel4
	 * @param dayLevel3
	 * @param dayLevel2
	 * @param dayLevel1
	 * @param dayLevel0
	 * @param orderBy
	 * @return checkVolumes
	 */
	public CheckVolumeMap getCheckVolumes(String serverIp, String catalogName, String searchType, String clientNumber, String keyword, String employeeCode, String areaTypeCode, String dayLevel6, String dayLevel5, String dayLevel4, String dayLevel3, String dayLevel2, String dayLevel1, String dayLevel0, String orderBy){
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("clientNumber", clientNumber);
		String functionName = "N".equals(searchType)?"fn_WEEK_RCV_LIST_ALL_Meter":"fn_WEEK_RCV_LIST_Meter";
		condition.put("functionName", functionName);
		condition.put("keyword", keyword);
		condition.put("employeeCode", employeeCode);
		condition.put("areaTypeCode", areaTypeCode);
		condition.put("dayLevel6", dayLevel6);
		condition.put("dayLevel5", dayLevel5);
		condition.put("dayLevel4", dayLevel4);
		condition.put("dayLevel3", dayLevel3);
		condition.put("dayLevel2", dayLevel2);
		condition.put("dayLevel1", dayLevel1);
		condition.put("dayLevel0", dayLevel0);
		condition.put("orderBy", orderBy);
		return selectCheckVolumes(serverIp, catalogName, condition);
	}
	
	/**
	 * 체적검침 조회
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param condition 검색 조건
	 * @return CheckVolumeMap 형식의 체적검침 목록 반환
	 */
	public CheckVolumeMap selectCheckVolumes(String serverIp, String catalogName, Map<String, String> condition){
		CheckVolumeMap checkVolumes = new CheckVolumeMap();
		condition.put("catalogName", catalogName);
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXEYE_CHECK_VOLUME_SELECT_ID, condition);
		for( HashMap<String, String> map :  list) {
			CheckVolume checkVolume = convertCheckVolume(map);
			checkVolumes.setCheckVolume(checkVolume.getKeyValue(), checkVolume);
		}
		return checkVolumes;
	}
	/**
	 * HashMap을 CheckVolume으로 변환
	 * @param map
	 * @return CheckVolume
	 */
	protected static CheckVolume convertCheckVolume(HashMap<String, String> map){
		CheckVolume checkVolume = new CheckVolume();
		
		checkVolume.setClientNumber(map.get("clientNumber"));
		checkVolume.setCustomerCode(map.get("customerCode"));
		checkVolume.setTransmitterCode(map.get("transmitterCode"));
		checkVolume.setCustomerName(map.get("customerName"));
		checkVolume.setInstallationDate(map.get("installationDate"));
		checkVolume.setPhoneNumber(map.get("phoneNumber"));
		checkVolume.setMobileNumber(map.get("mobileNumber"));
		checkVolume.setAddress(map.get("address"));
		checkVolume.setRemark(map.get("remark"));
		checkVolume.setLevel6(map.get("level6"));
		checkVolume.setLevel5(map.get("level5"));
		checkVolume.setLevel4(map.get("level4"));
		checkVolume.setLevel3(map.get("level3"));
		checkVolume.setLevel2(map.get("level2"));
		checkVolume.setLevel1(map.get("level1"));
		checkVolume.setLevel0(map.get("level0"));
		
		return checkVolume;
	}
	
	protected static HashMap<String, String> convertCheckVolume(CheckVolume checkVolume){
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", checkVolume.getClientNumber());
	    map.put("customerCode", checkVolume.getCustomerCode());
	    map.put("transmitterCode", checkVolume.getTransmitterCode());
	    map.put("customerName", checkVolume.getCustomerName());
	    map.put("installationDate", checkVolume.getInstallationDate());
	    map.put("phoneNumber", checkVolume.getPhoneNumber());
	    map.put("mobileNumber", checkVolume.getMobileNumber());
	    map.put("address", checkVolume.getAddress());
	    map.put("remark", checkVolume.getRemark());
	    map.put("level6", checkVolume.getLevel6());
	    map.put("level5", checkVolume.getLevel5());
	    map.put("level4", checkVolume.getLevel4());
	    map.put("level3", checkVolume.getLevel3());
	    map.put("level2", checkVolume.getLevel2());
	    map.put("level1", checkVolume.getLevel1());
	    map.put("level0", checkVolume.getLevel0());
		
		return map;
	}
	
	/**
	 * 비즈니스 로직 테스트용
	 * @param args
	 */
	public static void main(String[] args){
//		BizCheckVolume bizCheckVolume = BizCheckVolume.getInstance();
		
//		JSONObject jsonObject = JSONObject.fromObject(new HashMap<String, String>);
		

		
/* SELECT */
//		CheckVolumeMap checkVolumes = BizCheckVolume.getInstance().getCheckVolumes();		
//		System.out.println(checkVolumes.toXML());

/* INSERT OR UPDATE*/
//		CheckVolume checkVolume = new CheckVolume();
//		checkVolume.setCheckVolumeCode("TEST1");
//		checkVolume.setCheckVolumeName("TEST CheckVolume1");
//		checkVolume.setUseYesNo("Y");
//		BizCheckVolume.getInstance().applyCheckVolume(checkVolume);
		
/* DELETE */
//		BizCheckVolume.getInstance().deleteCheckVolume("TEST");
		
/* DELETE LIST */
//		List<String> list = new java.util.ArrayList<String>();
//		list.add("TEST1");
//		list.add("TEST2");
//		BizCheckVolume.getInstance().deleteCheckVolumes(list);

/* SELECT */
//		BizCheckVolume.getInstance().initCacheCheckVolumes();
//		System.out.println(cacheCheckVolumes.toXML());
//		

//		System.out.println(cacheCheckVolumes.toXML());
	}
}
