package com.joainfo.gasmaxplus.biz;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.joainfo.common.util.jdbc.JdbcUtil;
import com.joainfo.gasmaxplus.bean.TankLevelCount;
import com.joainfo.gasmaxplus.bean.list.TankLevelCountMap;

/**
 * TankLevelCount
 * 탱크레벨 카운트 비즈니스 로직 처리 객체
 * @author 네오브랜딩
 * @version 1.0
 */
public class BizTankLevelCount {


	/**
	 * 주간수신내역 Select 쿼리의 ID
	 */
	public final String GASMAXPLUS_TANK_LEVEL_COUNT_SELECT_ID = "GASMAXPLUS.TankLevelCount.Select";
	
	/**
	 * TankLevelCount 인스턴스
	 */
	private static BizTankLevelCount bizTankLevelCount;
	
	/**
	 * 디폴트 생성자
	 */
	public BizTankLevelCount(){
	}
	
	/**
	 * Singleton으로 TankLevelCount 인스턴스 생성
	 * @return bizTankLevelCount
	 */
	public static BizTankLevelCount getInstance(){
		if (bizTankLevelCount == null){
			bizTankLevelCount = new BizTankLevelCount();
		}
		return bizTankLevelCount;
	}
	
	/**
	 * 키워드로 검색한 탱크레벨카운트 목록을 반환
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param keyword
	 * @param employeeCode
	 * @param areaTypeCode
	 * @param dayLevel9
	 * @param dayLevel8
	 * @param dayLevel7
	 * @param dayLevel6
	 * @param dayLevel5
	 * @param dayLevel4
	 * @param dayLevel3
	 * @param dayLevel2
	 * @param dayLevel1
	 * @param dayLevel0
	 * @return tankLevelCounts
	 */
	public TankLevelCountMap getTankLevelCounts(String serverIp, String catalogName, String searchType, String clientNumber, String employeeCode, String areaTypeCode, String dayLevel9, String dayLevel8, String dayLevel7, String dayLevel6, String dayLevel5, String dayLevel4, String dayLevel3, String dayLevel2, String dayLevel1, String dayLevel0){
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("clientNumber", clientNumber);
		String functionName = "N".equals(searchType)?"FN_Tank_Level_CNT_ALL":"FN_Tank_Level_CNT";
		condition.put("functionName", functionName);
		condition.put("employeeCode", employeeCode);
		condition.put("areaTypeCode", areaTypeCode);
		condition.put("dayLevel9", dayLevel9);
		condition.put("dayLevel8", dayLevel8);
		condition.put("dayLevel7", dayLevel7);
		condition.put("dayLevel6", dayLevel6);
		condition.put("dayLevel5", dayLevel5);
		condition.put("dayLevel4", dayLevel4);
		condition.put("dayLevel3", dayLevel3);
		condition.put("dayLevel2", dayLevel2);
		condition.put("dayLevel1", dayLevel1);
		condition.put("dayLevel0", dayLevel0);
		
		return selectTankLevelCounts(serverIp, catalogName, condition);
	}
	
	/**
	 * 탱크레벨카운트 조회
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param condition 검색 조건
	 * @return TankLevelCountMap 형식의 주간수신내역 목록 반환
	 */
	public TankLevelCountMap selectTankLevelCounts(String serverIp, String catalogName, Map<String, String> condition){
		TankLevelCountMap tankLevelCounts = new TankLevelCountMap();
		condition.put("catalogName", catalogName);
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXPLUS_TANK_LEVEL_COUNT_SELECT_ID, condition);
		for( HashMap<String, String> map :  list) {
			TankLevelCount tankLevelCount = convertTankLevelCount(map);
			tankLevelCounts.setTankLevelCount(tankLevelCount.getKeyValue(), tankLevelCount);
		}
		return tankLevelCounts;
	}
	/**
	 * HashMap을 TankLevelCount으로 변환
	 * @param map
	 * @return TankLevelCount
	 */
	protected static TankLevelCount convertTankLevelCount(HashMap<String, String> map){
		TankLevelCount tankLevelCount = new TankLevelCount();
		
		tankLevelCount.setClientNumber(map.get("clientNumber"));
		tankLevelCount.setLevelStateAll(map.get("levelStateAll"));
		tankLevelCount.setLevelState0(map.get("levelState0"));
		tankLevelCount.setLevelState1(map.get("levelState1"));
		tankLevelCount.setLevelState2(map.get("levelState2"));
		tankLevelCount.setLevelState3(map.get("levelState3"));
		tankLevelCount.setReceiveDateOver(map.get("receiveDateOver"));
		tankLevelCount.setUniformLevel(map.get("uniformLevel"));
		tankLevelCount.setLowBattery(map.get("lowBattery"));
		
		return tankLevelCount;
	}
	
	protected static HashMap<String, String> convertTankLevelCount(TankLevelCount tankLevelCount){
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", tankLevelCount.getClientNumber());
	    map.put("levelStateAll", tankLevelCount.getLevelStateAll());
	    map.put("levelState0", tankLevelCount.getLevelState0());
	    map.put("levelState1", tankLevelCount.getLevelState1());
	    map.put("levelState2", tankLevelCount.getLevelState2());
	    map.put("levelState3", tankLevelCount.getLevelState3());
	    map.put("receiveDateOver", tankLevelCount.getReceiveDateOver());
	    map.put("uniformLevel", tankLevelCount.getUniformLevel());
	    map.put("lowBattery", tankLevelCount.getLowBattery());
		
		return map;
	}
	
	/**
	 * 비즈니스 로직 테스트용
	 * @param args
	 */
	public static void main(String[] args){
//		TankLevelCount TankLevelCount = TankLevelCount.getInstance();
		
//		JSONObject jsonObject = JSONObject.fromObject(new HashMap<String, String>);
		

		
/* SELECT */
//		TankLevelCountMap TankLevelCounts = TankLevelCount.getInstance().getTankLevelCounts();		
//		System.out.println(TankLevelCounts.toXML());

/* INSERT OR UPDATE*/
//		TankLevelCount TankLevelCount = new TankLevelCount();
//		TankLevelCount.setTankLevelCountCode("TEST1");
//		TankLevelCount.setTankLevelCountName("TEST TankLevelCount1");
//		TankLevelCount.setUseYesNo("Y");
//		TankLevelCount.getInstance().applyTankLevelCount(TankLevelCount);
		
/* DELETE */
//		TankLevelCount.getInstance().deleteTankLevelCount("TEST");
		
/* DELETE LIST */
//		List<String> list = new java.util.ArrayList<String>();
//		list.add("TEST1");
//		list.add("TEST2");
//		TankLevelCount.getInstance().deleteTankLevelCounts(list);

/* SELECT */
//		TankLevelCount.getInstance().initCacheTankLevelCounts();
//		System.out.println(cacheTankLevelCounts.toXML());
//		

//		System.out.println(cacheTankLevelCounts.toXML());
	}
}
