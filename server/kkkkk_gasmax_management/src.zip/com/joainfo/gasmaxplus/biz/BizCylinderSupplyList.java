package com.joainfo.gasmaxplus.biz;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.joainfo.common.util.jdbc.JdbcUtil;
import com.joainfo.gasmaxplus.bean.CylinderSupplyList;
import com.joainfo.gasmaxplus.bean.list.CylinderSupplyListMap;

/**
 * BizCylinderPlanInfo
 * 예상공급사용량 비즈니스 로직 처리 객체
 */
public class BizCylinderSupplyList {

	/**
	 * 예상공급사용량 Select 쿼리의 ID
	 */
	public final String GASMAXPLUS_CYLINDER_SUPPLY_LIST_SELECT_ID = "GASMAXPLUS.CylinderSupplyList.Select";
	

	/**
	 * BizCylinderPlanInfo 인스턴스
	 */
	private static BizCylinderSupplyList bizCylinderSupplyList;
	
	/**
	 * 디폴트 생성자
	 */
	public BizCylinderSupplyList(){
	}
	
	/**
	 * Singleton으로 BizCylinderPlanInfo 인스턴스 생성
	 * @return bizCylinder
	 */
	public static BizCylinderSupplyList getInstance(){
		if (bizCylinderSupplyList == null){
			bizCylinderSupplyList = new BizCylinderSupplyList();
		}
		return bizCylinderSupplyList;
	}
	
	/**
	 * 공급 현황 리스트 조회
	 */
	public CylinderSupplyListMap getCylinderSupplyList(String serverIp, String catalogName, String clientNumber, String employeeCode, String areaTypeCode, String keyword, String date, String appUser ){
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("clientNumber", clientNumber);
		String functionName = "FN_Plan_Meter_SAVE_LIST_2020";
		condition.put("functionName", functionName);
		condition.put("swCode", employeeCode);
		condition.put("cAreaCode", areaTypeCode);
		condition.put("keyword", keyword);
		condition.put("date", date);
		condition.put("appUser", appUser);
		
		return selectCylinderSupplyLists(serverIp, catalogName, condition);
	}
	
	/**
	 */
	public CylinderSupplyListMap selectCylinderSupplyLists(String serverIp, String catalogName, Map<String, String> condition){
		CylinderSupplyListMap cylinderSupplyLists = new CylinderSupplyListMap();
		condition.put("catalogName", catalogName);
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXPLUS_CYLINDER_SUPPLY_LIST_SELECT_ID, condition);
		for( HashMap<String, String> map :  list) {
			CylinderSupplyList cylinderSupplyList = convertCylinderSupplyList(map);
			cylinderSupplyLists.setCylinderSupplyList(cylinderSupplyList.getKeyValue(), cylinderSupplyList);
			
			
		}
		return cylinderSupplyLists;
	}

	/**
	 * HashMap을 WeeklyList으로 변환
	 * @param map
	 * @return WeeklyList
	 */
	protected static CylinderSupplyList convertCylinderSupplyList(HashMap<String, String> map){
		CylinderSupplyList cylinderSupplyList = new CylinderSupplyList();
		
		cylinderSupplyList.setClientNumber(map.get("clientNumber"));
		cylinderSupplyList.setCustomerCode(map.get("customerCode"));
		cylinderSupplyList.setcDate(map.get("cDate"));
		cylinderSupplyList.setcTime(map.get("cTime"));
		cylinderSupplyList.setTransmCd(map.get("transmCd"));
		cylinderSupplyList.setCustMCode(map.get("custMCode"));
		cylinderSupplyList.setCustJCode(map.get("custJCode"));
		cylinderSupplyList.setJmDiv(map.get("jmDiv"));
		cylinderSupplyList.setCustomerName(map.get("customerName"));
		cylinderSupplyList.setcVol(map.get("cVol"));
		cylinderSupplyList.setcQty(map.get("cQty"));
		cylinderSupplyList.setcVolQty(map.get("cVolQty"));
		cylinderSupplyList.setrCountDt(map.get("rCountDt"));
		cylinderSupplyList.setrCountSum(map.get("rCountSum"));
		cylinderSupplyList.setSetCount(map.get("setCount"));
		cylinderSupplyList.setWkId(map.get("wkId"));
		
		return cylinderSupplyList;
	}
	
	/**
	 * 비즈니스 로직 테스트용
	 * @param args
	 */
	public static void main(String[] args){
//		BizCylinder bizCylinder = BizCylinder.getInstance();
		
//		JSONObject jsonObject = JSONObject.fromObject(new HashMap<String, String>);
		

		
/* SELECT */
//		CylinderMap cylinders = BizCylinder.getInstance().getCylinders();		
//		System.out.println(cylinders.toXML());

/* INSERT OR UPDATE*/
//		Cylinder cylinder = new Cylinder();
//		cylinder.setCylinderCode("TEST1");
//		cylinder.setCylinderName("TEST Cylinder1");
//		cylinder.setUseYesNo("Y");
//		BizCylinder.getInstance().applyCylinder(cylinder);
		
/* DELETE */
//		BizCylinder.getInstance().deleteCylinder("TEST");
		
/* DELETE LIST */
//		List<String> list = new java.util.ArrayList<String>();
//		list.add("TEST1");
//		list.add("TEST2");
//		BizCylinder.getInstance().deleteCylinders(list);

/* SELECT */
//		BizCylinder.getInstance().initCacheCylinders();
//		System.out.println(cacheCylinders.toXML());
//		

//		System.out.println(cacheCylinders.toXML());
	}
}
