package com.joainfo.gasmaxplus.biz;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.joainfo.common.util.jdbc.JdbcUtil;
import com.joainfo.gasmaxplus.bean.AreaTypeCode;
import com.joainfo.gasmaxplus.bean.BulkBuy;
import com.joainfo.gasmaxplus.bean.BulkCar;
import com.joainfo.gasmaxplus.bean.BulkCharge;
import com.joainfo.gasmaxplus.bean.BulkChargeState;
import com.joainfo.gasmaxplus.bean.BulkCustomer;
import com.joainfo.gasmaxplus.bean.BulkGpsLine;
import com.joainfo.gasmaxplus.bean.BulkGuageState;
import com.joainfo.gasmaxplus.bean.BulkLastGps;
import com.joainfo.gasmaxplus.bean.BulkRun;
import com.joainfo.gasmaxplus.bean.BulkSetting;
import com.joainfo.gasmaxplus.bean.BulkSupplier;
import com.joainfo.gasmaxplus.bean.EmployeeCode;
import com.joainfo.gasmaxplus.bean.TankCustomer;
import com.joainfo.gasmaxplus.bean.list.AreaTypeCodeMap;
import com.joainfo.gasmaxplus.bean.list.BulkBuyMap;
import com.joainfo.gasmaxplus.bean.list.BulkCarMap;
import com.joainfo.gasmaxplus.bean.list.BulkChargeMap;
import com.joainfo.gasmaxplus.bean.list.BulkChargeStateMap;
import com.joainfo.gasmaxplus.bean.list.BulkCustomerMap;
import com.joainfo.gasmaxplus.bean.list.BulkGpsLineMap;
import com.joainfo.gasmaxplus.bean.list.BulkGuageStateMap;
import com.joainfo.gasmaxplus.bean.list.BulkLastGpsMap;
import com.joainfo.gasmaxplus.bean.list.BulkRunMap;
import com.joainfo.gasmaxplus.bean.list.BulkSettingMap;
import com.joainfo.gasmaxplus.bean.list.BulkSupplierMap;
import com.joainfo.gasmaxplus.bean.list.EmployeeCodeMap;
import com.joainfo.gasmaxplus.bean.list.TankCustomerMap;

/**
 * BizManageBulk
 * 충전관리 비즈니스 로직 처리 객체
 * @author 서경엔씨에스
 * @version 1.0
 */
public class BizManageBulk {

	public final String MANAGEBULK_BULK_CAR_SELECT_ID = "GASMAXPLUS.ManageBulk.BulkCar.Select";
	public final String MANAGEBULK_BULK_SAWON_SELECT_ID = "GASMAXPLUS.ManageBulk.Sawon.Select";
	public final String MANAGEBULK_BULK_AREACODE_SELECT_ID = "GASMAXPLUS.ManageBulk.AreaTypeCode.Select";
	
	public final String MANAGEBULK_BULK_SETTING_SELECT_ID = "GASMAXPLUS.ManageBulk.Setting.Select";
	public final String MANAGEBULK_BULK_SETTING_BULK_CAR_UPDATE_ID = "GASMAXPLUS.ManageBulk.BulkCar.Update";
	public final String MANAGEBULK_BULK_SETTING_BULK_RUN_UPDATE_ID = "GASMAXPLUS.ManageBulk.BulkRun.Update";
	
	public final String MANAGEBULK_BULK_RUN_SELECT_ID = "GASMAXPLUS.ManageBulk.BulkRun.Select";
	public final String MANAGEBULK_BULK_RUN_UPDATE_ID = "GASMAXPLUS.ManageBulk.BulkRun.Update";
	
	public final String MANAGEBULK_BULK_GUAGE_STATE_SELECT_ID = "GASMAXPLUS.ManageBulk.BulkGaugeState.Select";
	public final String MANAGEBULK_BULK_PREV_GUAGE_SELECT_ID = "GASMAXPLUS.ManageBulk.BulkPrevGuage.Select";
	
	public final String MANAGEBULK_BULK_CUSTOMER_BY_GPS_SELECT_ID = "GASMAXPLUS.ManageBulk.CustomerByGPS.Select";
	public final String MANAGEBULK_BULK_CUSTOMER_BY_KEYWORD_SELECT_ID = "GASMAXPLUS.ManageBulk.CustomerByKeyword.Select";
	public final String MANAGEBULK_BULK_CUSTOMER_INSERT_ID = "GASMAXPLUS.ManageBulk.Customer.INSERT";
	
	public final String MANAGEBULK_BULK_CHARGE_STATE_SELECT_ID = "GASMAXPLUS.ManageBulk.BulkChargeState.Select";
	
	public final String MANAGEBULK_BULK_CHARGE_SELECT_ID = "GASMAXPLUS.ManageBulk.BulkCharge.Select";
	public final String MANAGEBULK_BULK_CHARGE_INSERT_ID = "GASMAXPLUS.ManageBulk.BulkCharge.INSERT";
	
	public final String MANAGEBULK_BULK_SUPPLIER_SELECT_ID = "GASMAXPLUS.ManageBulk.BulkSupplier.Select";
	
	public final String MANAGEBULK_BULK_BUY_SELECT_ID = "GASMAXPLUS.ManageBulk.BulkBuy.Select";
	public final String MANAGEBULK_BULK_BUY_INSERT_ID = "GASMAXPLUS.ManageBulk.BulkBuy.Insert";
	
	public final String MANAGEBULK_BULK_GPS_LINE_SELECT_ID = "GASMAXPLUS.ManageBulk.BulkGpsLine.Select";
	public final String MANAGEBULK_BULK_LAST_GPS_SELECT_ID = "GASMAXPLUS.ManageBulk.BulkLastGps.Select";
	
	public final String MANAGEBULK_TANK_CUSTOMER_SELECT_ID = "GASMAXPLUS.ManageBulk.TankCustInfo.Select";
	
	/**
	 * 벌크로리 디폴트 DB 설정
	 */
	public final static String DEFAULT_MANAGE_BULK_SQL_CONFIG = "gasmaxplus_map";
	
	/**
	 * 벌크로리 디폴트 DB 카탈로그 명
	 */
	public final static String DEFAULT_MANAGE_BULK_CATATLOG_NAME = "GasMax_EYE";
	
	/**
	 * BizManageBulk 인스턴스
	 */
	private static BizManageBulk mInstance;
	
	/**
	 * 디폴트 생성자
	 */
	public BizManageBulk() {
	}
	
	/**
	 * Singleton으로 BizManageBulk 인스턴스 생성
	 * @return BizManageBulk
	 */
	public static BizManageBulk getInstance() {
		if (mInstance == null) {
			mInstance = new BizManageBulk();
		}
		return mInstance;
	}
	
	/**
	 * 충전관리 설정정보를 반환
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param clientNumber
	 * @param employeeCode
	 * @return values
	 */
	public BulkSettingMap getBulkSettings(String serverIp, String catalogName, String clientNumber, String appUserMobileNumber) {
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		condition.put("clientNumber", clientNumber);
		condition.put("appUserMobileNumber", appUserMobileNumber);

		return selectBulkSettings(serverIp, condition);
	}
	public BulkSetting getBulkSetting(String serverIp, String catalogName, String clientNumber, String appUserMobileNumber) {
		BulkSettingMap list = getBulkSettings(serverIp, catalogName, clientNumber, appUserMobileNumber);
		
		BulkSetting result = null;
		
		for(Map.Entry<String, BulkSetting> entry : list.getValues().entrySet()) {
			result = entry.getValue();
			break;
		}
		
		return result;
	}
	
	/**
	 * 충전관리 설정 조회
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param condition 검색 조건
	 * @return Map 형식의 충전관리 설정 목록 반환
	 */
	private BulkSettingMap selectBulkSettings(String serverIp, Map<String, String> condition) {
		BulkSettingMap results = new BulkSettingMap();
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(MANAGEBULK_BULK_SETTING_SELECT_ID, condition);
		for(HashMap<String, String> map : list) {
			BulkSetting bulkSetting = convertBulkSetting(map);
			results.setValue(bulkSetting.getKeyValue(), bulkSetting);
		}
		return results;
	}
	
	/**
	 * HashMap을 value으로 변환
	 * @param map
	 * @return value
	 */
	protected static BulkSetting convertBulkSetting(HashMap<String, String> map) {
		BulkSetting bean = new BulkSetting();
		
		bean.setClientNumber(map.get("clientNumber"));
		bean.setAppUser(map.get("appUser"));
		bean.setRegDate(map.get("regDate"));
		bean.setCarCode(map.get("carCode"));
		bean.setCarName(map.get("carName"));
		bean.setEmployeeCode(map.get("employeeCode"));
		bean.setEmployeeName(map.get("employeeName"));
		bean.setCarMaxLoadage(map.get("carMaxLoadage"));
		bean.setCarMaxLoadingRate(map.get("carMaxLoadingRate"));
		bean.setConvertRate(map.get("convertRate"));
		bean.setConvertRound(map.get("convertRound"));
		
		return bean;
	}
	
	protected static HashMap<String, String> convertMap(BulkSetting bean) {
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", bean.getClientNumber());
	    map.put("appUser", bean.getAppUser());
	    map.put("regDate", bean.getRegDate());
	    map.put("carCode", bean.getCarCode());
	    map.put("carName", bean.getCarName());
	    map.put("employeeCode", bean.getEmployeeCode());
	    map.put("employeeName", bean.getEmployeeName());
	    map.put("carMaxLoadage", bean.getCarMaxLoadage());
	    map.put("carMaxLoadingRate", bean.getCarMaxLoadingRate());
	    map.put("convertRate", bean.getConvertRate());
	    map.put("convertRound", bean.getConvertRound());
		
		return map;
	}
	
	/**
	 * 충전관리 벌크정보를 반환
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param clientNumber
	 * @return values
	 */
	public BulkCarMap getBulkCars(String serverIp, String catalogName, String clientNumber) {
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		condition.put("clientNumber", clientNumber);

		return selectBulkCars(serverIp, condition);
	}
	public BulkCarMap getBulkCars(String clientNumber) {
		return getBulkCars(DEFAULT_MANAGE_BULK_SQL_CONFIG, DEFAULT_MANAGE_BULK_CATATLOG_NAME, clientNumber);
	}
	
	/**
	 * 충전관리 벌크 조회
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param condition 검색 조건
	 * @return Map 형식의 충전관리 설정 목록 반환
	 */
	private BulkCarMap selectBulkCars(String serverIp, Map<String, String> condition) {
		BulkCarMap results = new BulkCarMap();
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(MANAGEBULK_BULK_CAR_SELECT_ID, condition);
		for(HashMap<String, String> map : list) {
			BulkCar entry = convertBulkCar(map);
			results.setValue(entry.getKeyValue(), entry);
		}
		return results;
	}
	/**
	 * HashMap을 value으로 변환
	 * @param map
	 * @return value
	 */
	protected static BulkCar convertBulkCar(HashMap<String, String> map) {
		BulkCar bean = new BulkCar();
		
		bean.setClientNumber(map.get("clientNumber"));
		bean.setCarCode(map.get("carCode"));
		bean.setCarName(map.get("carName"));
		bean.setEmployeeCode(map.get("employeeCode"));
		bean.setEmployeeName(map.get("employeeName"));
		
		return bean;
	}
	
	protected static HashMap<String, String> convertMap(BulkCar bean) {
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", bean.getClientNumber());
	    map.put("carCode", bean.getCarCode());
	    map.put("carName", bean.getCarName());
	    map.put("employeeCode", bean.getEmployeeCode());
	    map.put("employeeName", bean.getEmployeeName());
		
		return map;
	}
	
	/**
	 * 키워드로 검색한 사원코드 목록을 반환
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param clientNumber
	 * @return employeeCodes
	 */
	public EmployeeCodeMap getEmployeeCodes(String serverIp, String catalogName, String clientNumber) {
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		condition.put("clientNumber", clientNumber);
		
		return selectEmployeeCodes(serverIp, condition);
	}
	public EmployeeCodeMap getEmployeeCodes(String clientNumber) {		
		return getEmployeeCodes(DEFAULT_MANAGE_BULK_SQL_CONFIG, DEFAULT_MANAGE_BULK_CATATLOG_NAME, clientNumber);
	}
	
	/**
	 * 사원코드 조회
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param condition 검색 조건
	 * @return EmployeeCodeMap 형식의 사원코드 목록 반환
	 */
	private EmployeeCodeMap selectEmployeeCodes(String serverIp, Map<String, String> condition) {
		EmployeeCodeMap results = new EmployeeCodeMap();
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(MANAGEBULK_BULK_SAWON_SELECT_ID, condition);
		for( HashMap<String, String> map : list) {
			EmployeeCode entry = convertEmployeeCode(map);
			results.setEmployeeCode(entry.getKeyValue(), entry);
		}
		return results;
	}
	/**
	 * HashMap을 EmployeeCode으로 변환
	 * @param map
	 * @return EmployeeCode
	 */
	protected static EmployeeCode convertEmployeeCode(HashMap<String, String> map) {
		EmployeeCode bean = new EmployeeCode();
		
		bean.setClientNumber(map.get("clientNumber"));
		bean.setEmployeeCode(map.get("employeeCode"));
		bean.setEmployeeName(map.get("employeeName"));
		
		return bean;
	}
	
	protected static HashMap<String, String> convertMap(EmployeeCode bean) {
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", bean.getClientNumber());
	    map.put("employeeCode", bean.getEmployeeCode());
	    map.put("employeeName", bean.getEmployeeName());
		
		return map;
	}
	
	/**
	 * 충전관리 운행정보를 반환
	 */
	public BulkRunMap getBulkRuns(String serverIp, String catalogName, String clientNumber, String carCode, String findDate) {
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		condition.put("clientNumber", clientNumber);
		condition.put("carCode", carCode);
		condition.put("findDate", findDate);

		return selectBulkRuns(serverIp, condition);
	}
	public BulkRun getBulkRun(String serverIp, String catalogName, String clientNumber, String carCode, String findDate) {
		BulkRunMap bulkRuns = getBulkRuns(serverIp, catalogName, clientNumber, carCode, findDate);
		
		BulkRun result = null;
		
		for(Map.Entry<String, BulkRun> entry : bulkRuns.getValues().entrySet()) {
			result = entry.getValue();
			break;
		}
		
		return result;
	}
	
	/**
	 * 충전관리 운행정보 조회
	 */
	private BulkRunMap selectBulkRuns(String serverIp, Map<String, String> condition) {
		BulkRunMap results = new BulkRunMap();
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(MANAGEBULK_BULK_RUN_SELECT_ID, condition);
		for(HashMap<String, String> map : list) {
			BulkRun entry = convertBulkRun(map);
			results.setValue(entry.getKeyValue(), entry);
		}
		return results;
	}
	
	/**
	 * HashMap을 value으로 변환
	 */
	protected static BulkRun convertBulkRun(HashMap<String, String> map) {
		BulkRun bean = new BulkRun();
		
		bean.setClientNumber(map.get("clientNumber"));
		bean.setCarCode(map.get("carCode"));
		bean.setStartRunDate(map.get("startRunDate"));
		bean.setStartCarMileage(map.get("startCarMileage"));
		bean.setStartCarVolumePer(map.get("startCarVolumePer"));
		bean.setStartCarVolumeL(map.get("startCarVolumeL"));
		bean.setStartCarVolumeKg(map.get("startCarVolumeKg"));
		bean.setStartRegDate(map.get("startRegDate"));
		bean.setEndRunDate(map.get("endRunDate"));
		bean.setEndCarMileage(map.get("endCarMileage"));
		bean.setEndCarVolumePer(map.get("endCarVolumePer"));
		bean.setEndCarVolumeL(map.get("endCarVolumeL"));
		bean.setEndCarVolumeKg(map.get("endCarVolumeKg"));
		bean.setEndRegDate(map.get("endRegDate"));
		
		return bean;
	}
	
	protected static HashMap<String, String> convertMap(BulkRun bean) {
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", bean.getClientNumber());
	    map.put("carCode", bean.getCarCode());
	    map.put("startRunDate", bean.getStartRunDate());
	    map.put("startCarMileage", bean.getStartCarMileage());
	    map.put("startCarVolumePer", bean.getStartCarVolumePer());
	    map.put("startCarVolumeL", bean.getStartCarVolumeL());
	    map.put("startCarVolumeKg", bean.getStartCarVolumeKg());
	    map.put("startRegDate", bean.getStartRegDate());
	    map.put("endRunDate", bean.getEndRunDate());
	    map.put("endCarMileage", bean.getEndCarMileage());
	    map.put("endCarVolumePer", bean.getEndCarVolumePer());
	    map.put("endCarVolumeL", bean.getEndCarVolumeL());
	    map.put("endCarVolumeKg", bean.getEndCarVolumeKg());
	    map.put("endRegDate", bean.getEndRegDate());
		
		return map;
	}
	
	/**
	 * 충전관리 벌크로리 재고정보를 반환
	 */
	public BulkGuageStateMap getBulkGuageStates(String serverIp, String catalogName, String clientNumber, String carCode, String findDate) {
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		condition.put("clientNumber", clientNumber);
		condition.put("carCode", carCode);
		condition.put("findDate", findDate);

		return selectBulkGuageStates(serverIp, condition);
	}
	
	/**
	 * 충전관리 벌크로리 재고정보 조회
	 */
	private BulkGuageStateMap selectBulkGuageStates(String serverIp, Map<String, String> condition) {
		BulkGuageStateMap results = new BulkGuageStateMap();
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(MANAGEBULK_BULK_GUAGE_STATE_SELECT_ID, condition);
		for(HashMap<String, String> map : list) {
			BulkGuageState entry = convertBulkGuageState(map);
			results.setValue(entry.getKeyValue(), entry);
		}
		return results;
	}
	/**
	 * HashMap을 value으로 변환
	 */
	protected static BulkGuageState convertBulkGuageState(HashMap<String, String> map) {
		BulkGuageState bean = new BulkGuageState();
		
		bean.setClientNumber(map.get("clientNumber"));
		bean.setCarCode(map.get("carCode"));
		bean.setFindDate(map.get("findDate"));
		bean.setPrevGuage(map.get("prevGuage"));
		bean.setWarehousing(map.get("warehousing"));
		bean.setDelivery(map.get("delivery"));
		bean.setGuage(map.get("guage"));
		
		return bean;
	}
	
	protected static HashMap<String, String> convertMap(BulkGuageState bean) {
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", bean.getClientNumber());
	    map.put("carCode", bean.getCarCode());
	    map.put("findDate", bean.getFindDate());
	    map.put("prevGuage", bean.getPrevGuage());
	    map.put("warehousing", bean.getWarehousing());
	    map.put("delivery", bean.getDelivery());
	    map.put("guage", bean.getGuage());
		
		return map;
	}
	
	/**
	 * 충전관리 이전 벌크로리 재고정보를 반환
	 */
	public String getBulkPrevVolume(String serverIp, String catalogName, String clientNumber, String carCode, String findDate, String findTime) {
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		condition.put("clientNumber", clientNumber);
		condition.put("carCode", carCode);
		condition.put("findDate", findDate);
		condition.put("findTime", findTime);

		return selectBulkPrevVolume(serverIp, condition);
	}
	
	/**
	 * 충전관리 이전 벌크로리 재고정보 조회
	 */
	private String selectBulkPrevVolume(String serverIp, Map<String, String> condition) {
		String result = null;
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(MANAGEBULK_BULK_PREV_GUAGE_SELECT_ID, condition);
		for(HashMap<String, String> map : list) {
			result = map.get("prevVolume");
		}
		return result;
	}
	
	/**
	 * 충전관리 벌크로리 재고정보를 반환
	 */
	public BulkCustomerMap getBulkCustomersByGPS(String serverIp, String catalogName, String clientNumber, String employeeCode, String areaCode, String gpsX, String gpsY, String findDate, String appUser) {
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		condition.put("clientNumber", clientNumber);
		condition.put("employeeCode", employeeCode);
		condition.put("areaCode", areaCode);
		condition.put("gpsX", gpsX);
		condition.put("gpsY", gpsY);
		condition.put("findDate", findDate);
		condition.put("appUser", appUser);

		return selectBulkCustomersByGPS(serverIp, condition);
	}
	
	/**
	 * 충전관리 벌크로리 재고정보 조회
	 */
	private BulkCustomerMap selectBulkCustomersByGPS(String serverIp, Map<String, String> condition) {
		BulkCustomerMap results = new BulkCustomerMap();
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(MANAGEBULK_BULK_CUSTOMER_BY_GPS_SELECT_ID, condition);
		for(HashMap<String, String> map : list) {
			BulkCustomer entry = convertBulkCustomer(map);
			results.setValue(entry.getKeyValue(), entry);
		}
		return results;
	}
	
	/**
	 * 충전관리 벌크로리 재고정보를 반환
	 */
	public BulkCustomerMap getBulkCustomersByKeyword(String serverIp, String catalogName, String clientNumber, 
			String employeeCode, String areaCode, String keyword, String findDate, String appUserMobileNumber) {
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		condition.put("clientNumber", clientNumber);
		condition.put("employeeCode", employeeCode);
		condition.put("areaCode", areaCode);
		condition.put("keyword", keyword);
		condition.put("findDate", findDate);
		condition.put("appUserMobileNumber", appUserMobileNumber);

		return selectBulkCustomersByKeyword(serverIp, condition);
	}
	
	/**
	 * 충전관리 벌크로리 재고정보 조회
	 */
	private BulkCustomerMap selectBulkCustomersByKeyword(String serverIp, Map<String, String> condition) {
		BulkCustomerMap results = new BulkCustomerMap();
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(MANAGEBULK_BULK_CUSTOMER_BY_KEYWORD_SELECT_ID, condition);
		for(HashMap<String, String> map : list) {
			BulkCustomer entry = convertBulkCustomer(map);
			results.setValue(entry.getKeyValue(), entry);
		}
		return results;
	}
	/**
	 * HashMap을 value으로 변환
	 */
	protected static BulkCustomer convertBulkCustomer(HashMap<String, String> map) {
		BulkCustomer bean = new BulkCustomer();
		
		bean.setClientNumber(map.get("clientNumber"));
		bean.setCustomerCode(map.get("customerCode"));
		bean.setCustomerName(map.get("customerName"));
		bean.setCustomerTel(map.get("customerTel"));
		bean.setCustomerHp(map.get("customerHp"));
		bean.setCustomerAddr(map.get("customerAddr"));
		bean.setRemark(map.get("remarks"));
		bean.setTankVolume(map.get("tankVolume"));
		bean.setTransmitterCode(map.get("transmitterCode"));
		bean.setTankLevel(map.get("tankLevel"));
		bean.setEventName(map.get("eventName"));
		bean.setTankLevelState(map.get("tankLevelState"));
		bean.setReceiveDate(map.get("receiveDate"));
		bean.setChargeType(map.get("chargeType"));
		
		return bean;
	}
	
	protected static HashMap<String, String> convertMap(BulkCustomer bean) {
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", bean.getClientNumber());
	    map.put("customerCode", bean.getCustomerCode());
	    map.put("customerName", bean.getCustomerName());
	    map.put("customerTel", bean.getCustomerTel());
	    map.put("customerHp", bean.getCustomerHp());
	    map.put("customerAddr", bean.getCustomerAddr());
	    map.put("remarks", bean.getRemark());
	    map.put("tankVolume", bean.getTankVolume());
	    map.put("transmitterCode", bean.getTransmitterCode());
	    map.put("tankLevel", bean.getTankLevel());
	    map.put("eventName", bean.getEventName());
	    map.put("tankLevelState", bean.getTankLevelState());
	    map.put("receiveDate", bean.getReceiveDate());
	    map.put("chargeType", bean.getChargeType());
		
		return map;
	}
	
	/**
	 * 충전관리 충전정보를 반환
	 */
	public BulkChargeMap getBulkCharges(String serverIp, String catalogName, String clientNumber, String carCode, String findDate, String findTime) {
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		condition.put("clientNumber", clientNumber);
		condition.put("carCode", carCode);
		condition.put("findDate", findDate);
		condition.put("findTime", findTime);

		return selectBulkCharges(serverIp, condition);
	}
	public BulkCharge getBulkCharge(String serverIp, String catalogName, String clientNumber, String carCode, String findDate, String findTime) {
		BulkChargeMap lists = getBulkCharges(serverIp, catalogName, clientNumber, carCode, findDate, findTime);
		
		BulkCharge result = null;
		
		for(Map.Entry<String, BulkCharge> entry : lists.getValues().entrySet()) {
			result = entry.getValue();
			break;
		}
		
		return result;
	}
	
	/**
	 * 충전관리 충전정보 조회
	 */
	private BulkChargeMap selectBulkCharges(String serverIp, Map<String, String> condition) {
		BulkChargeMap results = new BulkChargeMap();
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(MANAGEBULK_BULK_CHARGE_SELECT_ID, condition);
		for(HashMap<String, String> map : list) {
			BulkCharge entry = convertBulkCharge(map);
			results.setValue(entry.getKeyValue(), entry);
		}
		return results;
	}
	/**
	 * HashMap을 value으로 변환
	 */
	protected static BulkCharge convertBulkCharge(HashMap<String, String> map) {
		BulkCharge bean = new BulkCharge();
		
		bean.setClientNumber(map.get("clientNumber"));
		bean.setCarCode(map.get("carCode"));
		bean.setChargeDate(map.get("chargeDate"));
		bean.setChargeTime(map.get("chargeTime"));
		bean.setCarName(map.get("carName"));
		bean.setTransmitterCode(map.get("transmitterCode"));
		bean.setChargeType(map.get("chargeType"));
		bean.setCustomerCode(map.get("customerCode"));
		bean.setCustomerName(map.get("customerName"));
		bean.setEmployeeCode(map.get("employeeCode"));
		bean.setEmployeeName(map.get("employeeName"));
		bean.setChargeVolumeL(map.get("chargeVolumeL"));
		bean.setChargeVolumeKg(map.get("chargeVolumeKg"));
		bean.setTotalChargeVolumeL(map.get("totalChargeVolumeL"));
		bean.setChargeCount(map.get("chargeCount"));
		bean.setTemperature(map.get("temperature"));
		bean.setUnitPrice(map.get("unitPrice"));
		bean.setPrice(map.get("price"));
		bean.setMemo(map.get("memo"));
		
		return bean;
	}
	
	protected static HashMap<String, String> convertMap(BulkCharge bean) {
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", bean.getClientNumber());
	    map.put("carCode", bean.getCarCode());
	    map.put("chargeDate", bean.getChargeDate());
	    map.put("chargeTime", bean.getChargeTime());
	    map.put("carName", bean.getCarName());
	    map.put("transmitterCode", bean.getTransmitterCode());
	    map.put("chargeType", bean.getChargeType());
	    map.put("customerCode", bean.getCustomerCode());
	    map.put("customerName", bean.getCustomerName());
	    map.put("employeeCode", bean.getEmployeeCode());
	    map.put("employeeName", bean.getEmployeeName());
	    map.put("chargeVolumeL", bean.getChargeVolumeL());
	    map.put("chargeVolumeKg", bean.getChargeVolumeKg());
	    map.put("totalChargeVolumeL", bean.getTotalChargeVolumeL());
	    map.put("chargeCount", bean.getChargeCount());
	    map.put("temperature", bean.getTemperature());
	    map.put("unitPrice", bean.getUnitPrice());
	    map.put("price", bean.getPrice());
	    map.put("memo", bean.getMemo());
		
		return map;
	}
	
	/**
	 * 충전관리 충전정보를 반환
	 */
	public BulkChargeStateMap getBulkChargeStates(String serverIp, String catalogName, String clientNumber, String findDate, String carCode, String keyword) {
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		condition.put("clientNumber", clientNumber);
		condition.put("findDate", findDate);
		condition.put("carCode", carCode);
		condition.put("keyword", keyword);

		return selectBulkChargeStates(serverIp, condition);
	}
	public BulkChargeStateMap getBulkChargeStates(String clientNumber, String findDate, String carCode, String keyword) {
		return getBulkChargeStates(DEFAULT_MANAGE_BULK_SQL_CONFIG, DEFAULT_MANAGE_BULK_CATATLOG_NAME, clientNumber, findDate, carCode, keyword);
	}
	
	/**
	 * 충전관리 충전정보 조회
	 */
	private BulkChargeStateMap selectBulkChargeStates(String serverIp, Map<String, String> condition) {
		BulkChargeStateMap results = new BulkChargeStateMap();
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(MANAGEBULK_BULK_CHARGE_STATE_SELECT_ID, condition);
		for(HashMap<String, String> map : list) {
			BulkChargeState entry = convertBulkChargeState(map);
			results.setValue(entry.getKeyValue(), entry);
		}
		return results;
	}
	/**
	 * HashMap을 value으로 변환
	 */
	protected static BulkChargeState convertBulkChargeState(HashMap<String, String> map) {
		BulkChargeState bean = new BulkChargeState();
		
		bean.setClientNumber(map.get("clientNumber"));
		bean.setCarCode(map.get("carCode"));
		bean.setChargeSeqNo(map.get("chargeSeqNo"));
		bean.setChargeDate(map.get("chargeDate"));
		bean.setChargeTime(map.get("chargeTime"));
		bean.setChargeType(map.get("chargeType"));
		bean.setTransmitterCode(map.get("transmitterCode"));
		bean.setCustomerCode(map.get("customerCode"));
		bean.setCustomerName(map.get("customerName"));
		bean.setChargeVolumeL(map.get("chargeVolumeL"));
		bean.setChargeVolumeKg(map.get("chargeVolumeKg"));
		bean.setTankVolume(map.get("tankVolume"));
		bean.setGpsX(map.get("gpsX"));
		bean.setGpsY(map.get("gpsY"));
		
		return bean;
	}
	
	protected static HashMap<String, String> convertMap(BulkChargeState bean) {
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", bean.getClientNumber());
	    map.put("carCode", bean.getCarCode());
	    map.put("chargeSeqNo", bean.getCarCode());
	    map.put("chargeDate", bean.getChargeDate());
	    map.put("chargeTime", bean.getChargeTime());
	    map.put("chargeType", bean.getChargeType());
	    map.put("transmitterCode", bean.getTransmitterCode());
	    map.put("customerCode", bean.getCustomerCode());
	    map.put("customerName", bean.getCustomerName());
	    map.put("chargeVolumeL", bean.getChargeVolumeL());
	    map.put("chargeVolumeKg", bean.getChargeVolumeKg());
	    map.put("tankVolume", bean.getTankVolume());
	    map.put("gpsX", bean.getGpsX());
	    map.put("gpsY", bean.getGpsY());
		
		return map;
	}
	
	/**
	 * 충전관리 매입처 정보를 반환
	 */
	public BulkSupplierMap getBulkSuppliers(String serverIp, String catalogName, String clientNumber, String supplierType) {
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		condition.put("clientNumber", clientNumber);
		condition.put("supplierType", supplierType);

		return selectBulkSuppliers(serverIp, condition);
	}
	
	/**
	 * 충전관리 충전정보 조회
	 */
	private BulkSupplierMap selectBulkSuppliers(String serverIp, Map<String, String> condition) {
		BulkSupplierMap results = new BulkSupplierMap();
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(MANAGEBULK_BULK_SUPPLIER_SELECT_ID, condition);
		for(HashMap<String, String> map : list) {
			BulkSupplier entry = convertBulkSupplier(map);
			results.setValue(entry.getKeyValue(), entry);
		}
		return results;
	}
	/**
	 * HashMap을 value으로 변환
	 */
	protected static BulkSupplier convertBulkSupplier(HashMap<String, String> map) {
		BulkSupplier bean = new BulkSupplier();
		
		bean.setClientNumber(map.get("clientNumber"));
		bean.setSupplierType(map.get("supplierType"));
		bean.setSupplierCode(map.get("supplierCode"));
		bean.setSupplierName(map.get("supplierName"));
		
		return bean;
	}
	
	protected static HashMap<String, String> convertMap(BulkSupplier bean) {
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", bean.getClientNumber());
	    map.put("supplierType", bean.getSupplierType());
	    map.put("supplierCode", bean.getSupplierCode());
	    map.put("supplierName", bean.getSupplierName());
		
		return map;
	}
	
	/**
	 * 충전관리 충전정보를 반환
	 */
	public BulkBuyMap getBulkBuys(String serverIp, String catalogName, String clientNumber, String carCode, String buyDate) {
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		condition.put("clientNumber", clientNumber);
		condition.put("carCode", carCode);
		condition.put("buyDate", buyDate);

		return selectBulkBuys(serverIp, condition);
	}
	
	/**
	 * 충전관리 충전정보 조회
	 */
	private BulkBuyMap selectBulkBuys(String serverIp, Map<String, String> condition) {
		BulkBuyMap results = new BulkBuyMap();
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(MANAGEBULK_BULK_BUY_SELECT_ID, condition);
		for(HashMap<String, String> map : list) {
			BulkBuy entry = convertBulkBuy(map);
			results.setValue(entry.getKeyValue(), entry);
		}
		
		return results;
	}
	/**
	 * HashMap을 value으로 변환
	 */
	protected static BulkBuy convertBulkBuy(HashMap<String, String> map) {
		BulkBuy bean = new BulkBuy();
		
		bean.setClientNumber(map.get("clientNumber"));
		bean.setCarCode(map.get("carCode"));
		bean.setBuyType(map.get("buyType"));
		bean.setBuyDate(map.get("buyDate"));
		bean.setSeqNo(map.get("seqNo"));
		bean.setCustomerCode(map.get("customerCode"));
		bean.setCustomerName(map.get("customerName"));
		bean.setEmployeeCode(map.get("employeeCode"));
		bean.setEmployeeName(map.get("employeeName"));
		bean.setBeforeVolumeKg(map.get("beforeVolumeKg"));
		bean.setChargeVolumeL(map.get("chargeVolumeL"));
		bean.setChargeVolumeKg(map.get("chargeVolumeKg"));
		bean.setAfterVolumeKg(map.get("afterVolumeKg"));
		bean.setUnitPrice(map.get("unitPrice"));
		bean.setPrice(map.get("price"));
		bean.setMemo(map.get("memo"));
		
		return bean;
	}
	
	protected static HashMap<String, String> convertMap(BulkBuy bean) {
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", bean.getClientNumber());
	    map.put("carCode", bean.getCarCode());
	    map.put("buyType", bean.getBuyType());
	    map.put("buyDate", bean.getBuyDate());
	    map.put("seqNo", bean.getSeqNo());
	    map.put("customerCode", bean.getCustomerCode());
	    map.put("customerName", bean.getCustomerName());
	    map.put("employeeCode", bean.getEmployeeCode());
	    map.put("employeeName", bean.getEmployeeName());
	    map.put("beforeVolumeKg", bean.getBeforeVolumeKg());
	    map.put("chargeVolumeL", bean.getChargeVolumeL());
	    map.put("chargeVolumeKg", bean.getChargeVolumeKg());
	    map.put("afterVolumeKg", bean.getAfterVolumeKg());
	    map.put("unitPrice", bean.getUnitPrice());
	    map.put("price", bean.getPrice());
	    map.put("memo", bean.getMemo());
		
		return map;
	}
	
	public String setBulkCar(String serverIp, String catalogName, String clientNumber, String appUserMobileNumber, 
			String setType, String setDate, String carCode, String carName, String employeeCode, String employeeName) {
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		
		condition.put("clientNumber", clientNumber);
		condition.put("setDate", setDate);
		condition.put("setType", setType);
		condition.put("carCode", carCode);
		condition.put("carName", carName);
		condition.put("employeeCode", employeeCode);
		condition.put("employeeName", employeeName);
		condition.put("appUserMobileNumber", appUserMobileNumber);

		return updateBulkCar(serverIp, condition);
	}
	
	public String setBulkRun(String serverIp, String catalogName, String clientNumber, String appUserMobileNumber, 
			String setType, String setDate, String carCode, String carName, String employeeCode, String employeeName, 
			String carMileage, String carVolumePer, String carVolumeL, String carVolumeKg ){
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		
		condition.put("clientNumber", clientNumber);
		condition.put("setDate", setDate);
		condition.put("setType", setType);
		condition.put("carCode", carCode);
		condition.put("carName", carName);
		condition.put("employeeCode", employeeCode);
		condition.put("employeeName", employeeName);
		condition.put("carMileage", carMileage);
		condition.put("carVolumePer", carVolumePer);
		condition.put("carVolumeL", carVolumeL);
		condition.put("carVolumeKg", carVolumeKg);
		condition.put("appUserMobileNumber", appUserMobileNumber);

		return updateBulkRun(serverIp, condition);
	}

	/**
	 * @param condition
	 * @return
	 */
	protected String updateBulkCar(String serverIp, HashMap<String, String> condition) {
			return JdbcUtil.getInstance(serverIp).executeProcedure(MANAGEBULK_BULK_SETTING_BULK_CAR_UPDATE_ID, condition, "outputErrorCode");
	}
	
	/**
	 * @param condition
	 * @return
	 */
	protected String updateBulkRun(String serverIp, HashMap<String, String> condition) {
			return JdbcUtil.getInstance(serverIp).executeProcedure(MANAGEBULK_BULK_SETTING_BULK_RUN_UPDATE_ID, condition, "outputErrorCode");
	}
	
	/**
	 * 충전관리 충전정보를 반환
	 */
	public BulkGpsLineMap getBulkGpsLines(String serverIp, String catalogName, String clientNumber, String carCode, String findDate) {
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		condition.put("clientNumber", clientNumber);
		condition.put("carCode", carCode);
		condition.put("findDate", findDate);

		return selectBulkGpsLines(serverIp, condition);
	}
	public BulkGpsLineMap getBulkGpsLines(String clientNumber, String carCode, String findDate) {
		return getBulkGpsLines(DEFAULT_MANAGE_BULK_SQL_CONFIG, DEFAULT_MANAGE_BULK_CATATLOG_NAME, clientNumber, carCode, findDate);
	}
	
	/**
	 * 충전관리 충전정보 조회
	 */
	private BulkGpsLineMap selectBulkGpsLines(String serverIp, Map<String, String> condition) {
		BulkGpsLineMap results = new BulkGpsLineMap();
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(MANAGEBULK_BULK_GPS_LINE_SELECT_ID, condition);
		for(HashMap<String, String> map : list) {
			BulkGpsLine entry = convertBulkGpsLine(map);
			results.setValue(entry.getKeyValue(), entry);
		}
		
		return results;
	}
	/**
	 * HashMap을 value으로 변환
	 */
	protected static BulkGpsLine convertBulkGpsLine(HashMap<String, String> map) {
		BulkGpsLine bean = new BulkGpsLine();
		
		bean.setClientNumber(map.get("clientNumber"));
		bean.setCarCode(map.get("carCode"));
		bean.setCarName(map.get("carName"));
		bean.setCarType(map.get("carType"));
		bean.setReceiveDate(map.get("receiveDate"));
		bean.setReceiveTime(map.get("receiveTime"));
		bean.setGpsX(map.get("gpsX"));
		bean.setGpsY(map.get("gpsY"));
		bean.setGpsEvent(map.get("gpsEvent"));
		
		return bean;
	}
	
	protected static HashMap<String, String> convertMap(BulkGpsLine bean) {
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", bean.getClientNumber());
	    map.put("carCode", bean.getCarCode());
	    map.put("carName", bean.getCarName());
	    map.put("carType", bean.getCarType());
	    map.put("receiveDate", bean.getReceiveDate());
	    map.put("receiveTime", bean.getReceiveTime());
	    map.put("gpsX", bean.getGpsX());
	    map.put("gpsY", bean.getGpsY());
	    map.put("gpsEvent", bean.getGpsEvent());
		
		return map;
	}
	
	public String setBulkBuy(String serverIp, String catalogName, String clientNumber, String appUserMobileNumber, 
			String buyDate, String buyType, String carCode, String seqNo, String customerCode, String customerName, 
			String employeeCode, String employeeName, String beforeVolumeKg, String chargeVolumeL, String chargeVolumeKg, String afterVolumeKg,
			String unitPrice, String price, String memo, String latitude, String longitude){
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		
		condition.put("clientNumber", clientNumber);
		condition.put("buyDate", buyDate);
		condition.put("buyType", buyType);
		condition.put("carCode", carCode);
		condition.put("seqNo", seqNo);
		condition.put("customerCode", customerCode);
		condition.put("customerName", customerName);
		condition.put("employeeCode", employeeCode);
		condition.put("employeeName", employeeName);
		condition.put("beforeVolumeKg", beforeVolumeKg);
		condition.put("chargeVolumeL", chargeVolumeL);
		condition.put("chargeVolumeKg", chargeVolumeKg);
		condition.put("afterVolumeKg", afterVolumeKg);
		condition.put("unitPrice", unitPrice);
		condition.put("price", price);
		condition.put("memo", memo);
		condition.put("latitude", latitude);
		condition.put("longitude", longitude);
		condition.put("appUserMobileNumber", appUserMobileNumber);

		return insertBulkBuy(serverIp, condition);
	}

	/**
	 * @param condition
	 * @return
	 */
	protected String insertBulkBuy(String serverIp, HashMap<String, String> condition) {
			return JdbcUtil.getInstance(serverIp).executeProcedure(MANAGEBULK_BULK_BUY_INSERT_ID, condition, "outputErrorCode");
	}
	
	/**
	 * 키워드로 검색한 지역코드 목록을 반환
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param clientNumber
	 * @return areaTypeCodes
	 */
	public AreaTypeCodeMap getAreaTypeCodes(String serverIp, String catalogName, String clientNumber){
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		condition.put("clientNumber", clientNumber);
		
		return selectAreaTypeCodes(serverIp, condition);
	}
	
	public AreaTypeCodeMap selectAreaTypeCodes(String serverIp, Map<String, String> condition){
		AreaTypeCodeMap areaTypeCodes = new AreaTypeCodeMap();
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(MANAGEBULK_BULK_AREACODE_SELECT_ID, condition);
		for( HashMap<String, String> map :  list) {
			AreaTypeCode areaTypeCode = convertAreaTypeCode(map);
			areaTypeCodes.setAreaTypeCode(areaTypeCode.getKeyValue(), areaTypeCode);
		}
		return areaTypeCodes;
	}

	protected static AreaTypeCode convertAreaTypeCode(HashMap<String, String> map){
		AreaTypeCode areaTypeCode = new AreaTypeCode();
		
		areaTypeCode.setClientNumber(map.get("clientNumber"));
		areaTypeCode.setAreaTypeCode(map.get("areaTypeCode"));
		areaTypeCode.setAreaTypeName(map.get("areaTypeName"));
		
		return areaTypeCode;
	}
	
	protected static HashMap<String, String> convertAreaTypeCode(AreaTypeCode areaTypeCode){
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", areaTypeCode.getClientNumber());
	    map.put("areaTypeCode", areaTypeCode.getAreaTypeCode());
	    map.put("areaTypeName", areaTypeCode.getAreaTypeName());
		
		return map;
	}
	
	public Map<String, String> setBulkCustomer(String serverIp, String catalogName, String clientNumber, String appUserMobileNumber, 
			String insertType, String customerCode, String customerName, String remarks,
			String customerZipCode, String customerNameAddr1, String customerNameAddr2, 
			String gpsX, String gpsY, String employeeCode, String areaTypeCode) {
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		condition.put("clientNumber", clientNumber);
		
		condition.put("insertType", insertType);
		condition.put("customerCode", customerCode);
		condition.put("customerName", customerName);
		condition.put("remarks", remarks);
		condition.put("customerZipCode", customerZipCode);
		condition.put("customerNameAddr1", customerNameAddr1);
		condition.put("customerNameAddr2", customerNameAddr2);
		condition.put("gpsX", gpsX);
		condition.put("gpsY", gpsY);
		condition.put("employeeCode", employeeCode);
		condition.put("areaTypeCode", areaTypeCode);
		condition.put("appUserMobileNumber", appUserMobileNumber);

		return insertBulkCustomer(serverIp, condition);
	}

	/**
	 * @param condition
	 * @return
	 */
	protected Map<String, String> insertBulkCustomer(String serverIp, HashMap<String, String> condition) {
			return JdbcUtil.getInstance(serverIp).executeProcedureResult(MANAGEBULK_BULK_CUSTOMER_INSERT_ID, condition);
	}
	
	public String setBulkCharge(String serverIp, String catalogName, String clientNumber, String appUserMobileNumber, 
			String insertType, String chargeDate, String chargeType, String chargeSeqNo, String carCode, 
			String customerCode, String customerName, String employeeCode, String employeeName,
			String chargeVolumeL, String chargeVolumeKg, String memo, String gpsX, String gpsY) {
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		condition.put("clientNumber", clientNumber);
		
		condition.put("insertType", insertType);
		condition.put("chargeDate", chargeDate);
		condition.put("chargeType", chargeType);
		condition.put("chargeSeqNo", chargeSeqNo);
		condition.put("carCode", carCode);
		condition.put("customerCode", customerCode);
		condition.put("customerName", customerName);
		condition.put("employeeCode", employeeCode);
		condition.put("employeeName", employeeName);
		condition.put("chargeVolumeL", chargeVolumeL);
		condition.put("chargeVolumeKg", chargeVolumeKg);
		condition.put("memo", memo);
		condition.put("gpsX", gpsX);
		condition.put("gpsY", gpsY);
		condition.put("appUserMobileNumber", appUserMobileNumber);

		return insertBulkCharge(serverIp, condition);
	}

	/**
	 * @param condition
	 * @return
	 */
	protected String insertBulkCharge(String serverIp, HashMap<String, String> condition) {
			return JdbcUtil.getInstance(serverIp).executeProcedure(MANAGEBULK_BULK_CHARGE_INSERT_ID, condition, "outputErrorCode");
	}
	
	/**
	 * 충전관리 충전정보를 반환
	 */
	public BulkLastGpsMap getBulkLastGps(String serverIp, String catalogName, String clientNumber, String carCode, String findDate) {
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		condition.put("clientNumber", clientNumber);
		condition.put("carCode", carCode);
		condition.put("findDate", findDate);

		return selectBulkLastGps(serverIp, condition);
	}
	public BulkLastGpsMap getBulkLastGps(String clientNumber, String carCode, String findDate) {
		return getBulkLastGps(DEFAULT_MANAGE_BULK_SQL_CONFIG, DEFAULT_MANAGE_BULK_CATATLOG_NAME, clientNumber, carCode, findDate);
	}
	
	/**
	 * 충전관리 충전정보 조회
	 */
	private BulkLastGpsMap selectBulkLastGps(String serverIp, Map<String, String> condition) {
		BulkLastGpsMap results = new BulkLastGpsMap();
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(MANAGEBULK_BULK_LAST_GPS_SELECT_ID, condition);
		for(HashMap<String, String> map : list) {
			BulkLastGps entry = convertBulkLastGps(map);
			results.setValue(entry.getKeyValue(), entry);
		}
		
		return results;
	}
	/**
	 * HashMap을 value으로 변환
	 */
	protected static BulkLastGps convertBulkLastGps(HashMap<String, String> map) {
		BulkLastGps bean = new BulkLastGps();
		
		bean.setClientNumber(map.get("clientNumber"));
		bean.setCarCode(map.get("carCode"));
		bean.setCarName(map.get("carName"));
		bean.setCarType(map.get("carType"));
		bean.setReceiveDate(map.get("receiveDate"));
		bean.setReceiveTime(map.get("receiveTime"));
		bean.setGpsX(map.get("gpsX"));
		bean.setGpsY(map.get("gpsY"));
		bean.setGpsEvent(map.get("gpsEvent"));
		
		return bean;
	}
	
	protected static HashMap<String, String> convertMap(BulkLastGps bean) {
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", bean.getClientNumber());
	    map.put("carCode", bean.getCarCode());
	    map.put("carName", bean.getCarName());
	    map.put("carType", bean.getCarType());
	    map.put("receiveDate", bean.getReceiveDate());
	    map.put("receiveTime", bean.getReceiveTime());
	    map.put("gpsX", bean.getGpsX());
	    map.put("gpsY", bean.getGpsY());
	    map.put("gpsEvent", bean.getGpsEvent());
		
		return map;
	}
	
	
	
	
	
	
	/**
	 * 거래처 정보 가져오기
	 */
	public TankCustomerMap getTankCustomer(String serverIp, String catalogName, String clientNumber, String customerCode) {
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		condition.put("clientNumber", clientNumber);
		condition.put("customerCode", customerCode);

		return selectTankCustomer(serverIp, condition);
	}
	private TankCustomerMap selectTankCustomer(String serverIp, Map<String, String> condition) {
		TankCustomerMap results = new TankCustomerMap();
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(MANAGEBULK_TANK_CUSTOMER_SELECT_ID, condition);
		for(HashMap<String, String> map : list) {
			TankCustomer entry = convertTankCustomer(map);
			results.setValue(entry.getKeyValue(), entry);
		}
		return results;
	}
	protected static TankCustomer convertTankCustomer(HashMap<String, String> map) {
		TankCustomer bean = new TankCustomer();
		
		bean.setClientNumber(map.get("clientNumber"));
		bean.setCustomerCode(map.get("customerCode"));
		bean.setCustomerName(map.get("customerName"));
		bean.setRemark(map.get("remark"));
		bean.setCustomerTel(map.get("customerTel"));
		bean.setCustomerHp(map.get("customerHp"));
		bean.setCustomerZipCode(map.get("customerZipCode"));
		bean.setCustomerAddr1(map.get("customerAddr1"));
		bean.setCustomerAddr2(map.get("customerAddr2"));
		bean.setGpsX(map.get("gpsX"));
		bean.setGpsY(map.get("gpsY"));
		bean.setEmployeeCode(map.get("employeeCode"));
		bean.setEmployeeName(map.get("employeeName"));
		bean.setAreaTypeCode(map.get("areaTypeCode"));
		bean.setAreaTypeName(map.get("areaTypeName"));
		bean.setTransmitterCode(map.get("transmitterCode"));
		bean.setTankVolume(map.get("tankVolume"));
		bean.setChargeType(map.get("chargeType"));
		
		return bean;
	}
	protected static HashMap<String, String> convertMap(TankCustomer bean) {
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", bean.getClientNumber());
	    map.put("customerCode", bean.getCustomerCode());
	    map.put("customerName", bean.getCustomerName());
	    map.put("remark", bean.getRemark());
	    map.put("customerTel", bean.getCustomerTel());
	    map.put("customerHp", bean.getCustomerHp());
	    map.put("customerZipCode", bean.getCustomerZipCode());
	    map.put("customerAddr1", bean.getCustomerAddr1());
	    map.put("customerAddr2", bean.getCustomerAddr2());
	    map.put("gpsX", bean.getGpsX());
	    map.put("gpsY", bean.getGpsY());
	    map.put("employeeCode", bean.getEmployeeCode());
	    map.put("employeeName", bean.getEmployeeName());
	    map.put("areaTypeCode", bean.getAreaTypeCode());
	    map.put("areaTypeName", bean.getAreaTypeName());
	    map.put("transmitterCode", bean.getTransmitterCode());
	    map.put("tankVolume", bean.getTankVolume());
	    map.put("chargeType", bean.getChargeType());
		
		return map;
	}
	
	
	
	/**
	 * 비즈니스 로직 테스트용
	 * @param args
	 */
	public static void main(String[] args) {

	}
}
