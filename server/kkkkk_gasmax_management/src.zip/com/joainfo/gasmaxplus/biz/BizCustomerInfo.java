package com.joainfo.gasmaxplus.biz;

import java.util.HashMap;

import com.joainfo.common.util.jdbc.JdbcUtil;
import com.joainfo.gasmaxplus.bean.CustomerInfo;

/**
 * BizCustomerInfo
 * 앱 거래처 수정 비즈니스 로직 처리 객체
 * @author 네오브랜딩
 * @version 1.0
 */
public class BizCustomerInfo {

	/**
	 * 앱 거래처 수정 코드 Update 쿼리의 ID
	 */
	public final String GASMAXPLUS_CUSTOMER_INFO_UPDATE_ID = "GASMAXPLUS.CustomerInfo.Update";
	
	/**
	 * BizCustomerInfo 인스턴스
	 */
	private static BizCustomerInfo bizCustomerInfo;
	
	/**
	 * 디폴트 생성자
	 */
	public BizCustomerInfo(){
	}
	
	/**
	 * Singleton으로 BizCustomerInfo 인스턴스 생성
	 * @return bizCustomerInfo
	 */
	public static BizCustomerInfo getInstance(){
		if (bizCustomerInfo == null){
			bizCustomerInfo = new BizCustomerInfo();
		}
		return bizCustomerInfo;
	}
	
	/**
	 * 앱 사용자 코드 반환
	 * @param catalogName
	 * @param key
	 * @return customerInfo
	 */
	/*
	public CustomerInfo getCustomerInfo(String catalogName, String key){
	    CustomerInfoMap customerInfos = getCustomerInfos(catalogName);
		return customerInfos==null?null:customerInfos.getCustomerInfo(key);
	}
	
	/**
	 * 캐시로부터 앱 거래처 코드 목록을 반환
	 * @param catalogName
	 * @return customerInfos
	 */
	/*
	public CustomerInfoMap getCustomerInfos(String catalogName){
		return selectCustomerInfos(catalogName);
	}
	
	/**
	 * 거래처 정보 수정
	 * @param clientNumber
	 * @param customerCode
	 * @param customerDiv
	 * @param customerName
	 * @param meterLevel
	 * @param remark
	 * @return
	 */
	public int setCustomerInfo(String serverIp, String catalogName, String clientNumber, String customerCode, String customerDiv, String customerName, String meterLavel, String remark){
		HashMap<String, String> condition = new HashMap<String, String>();
		
		condition.put("clientNumber", clientNumber);
		condition.put("customerCode", customerCode);
		condition.put("customerDiv", customerDiv);
		condition.put("customerName", customerName);
		condition.put("meterLavel", meterLavel);
		condition.put("remark", remark);

		return updateCustomerInfo(serverIp, catalogName, condition);
	}
	
	/**
	 * @param condition
	 * @return
	 */
	protected int updateCustomerInfo(String serverIp, String catalogName, HashMap<String, String> condition){
			return JdbcUtil.getInstance(serverIp).updateQuery(GASMAXPLUS_CUSTOMER_INFO_UPDATE_ID, condition);
	}
	
	/**
	 * HashMap을 CustomerInfo으로 변환
	 * @param map
	 * @return CustomerInfo
	 */
	protected static CustomerInfo convertCustomerInfo(HashMap<String, String> map){
		CustomerInfo customerInfo = new CustomerInfo();
		customerInfo.setClientNumber(map.get("clientNumber"));
		customerInfo.setCustomerCode(map.get("customerCode"));
		customerInfo.setCustomerDiv(map.get("customerDiv"));
		customerInfo.setCustomerName(map.get("customerName"));
		customerInfo.setMeterLavel(map.get("meterLavel"));
		customerInfo.setRemark(map.get("remark"));
		
		return customerInfo;
	}
	
	protected static HashMap<String, String> convertCustomerInfo(CustomerInfo customerInfo){
		HashMap<String, String> map = new HashMap<String, String>();
		
		map.put("clientNumber", customerInfo.getClientNumber());
		map.put("customerCode", customerInfo.getCustomerCode());
		map.put("customerDiv", customerInfo.getCustomerDiv());
		map.put("customerName", customerInfo.getCustomerName());
		map.put("meterLavel", customerInfo.getMeterLavel());
		map.put("remark", customerInfo.getRemark());
		
		return map;
	}
	
	/**
	 * 비즈니스 로직 테스트용
	 * @param args
	 */
	public static void main(String[] args){
		//BizCustomerInfo bizCustomerInfo = BizCustomerInfo.getInstance();
		//System.out.println(bizCustomerInfo.getCustomerInfos().toXML());
		
//		JSONObject jsonObject = JSONObject.fromObject(new HashMap<String, String>);
		

		
/* SELECT */
//		AppUserMap appUsers = BizAppUser.getInstance().getAppUsers();		
//		System.out.println(appUsers.toXML());

/* INSERT OR UPDATE*/
//		AppUser appUser = new AppUser();
//		appUser.setAppUserCode("TEST1");
//		appUser.setAppUserName("TEST AppUser1");
//		appUser.setUseYesNo("Y");
//		BizAppUser.getInstance().applyAppUser(appUser);
		
/* DELETE */
//		BizAppUser.getInstance().deleteAppUser("TEST");
		
/* DELETE LIST */
//		List<String> list = new java.util.ArrayList<String>();
//		list.add("TEST1");
//		list.add("TEST2");
//		BizAppUser.getInstance().deleteAppUsers(list);

/* SELECT */
//		BizAppUser.getInstance().initCacheAppUsers();
//		System.out.println(cacheAppUsers.toXML());
//		

//		System.out.println(cacheAppUsers.toXML());
	}
}
