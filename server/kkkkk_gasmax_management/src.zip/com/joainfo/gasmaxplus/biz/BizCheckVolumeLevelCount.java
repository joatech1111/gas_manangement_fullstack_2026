package com.joainfo.gasmaxplus.biz;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.joainfo.common.util.jdbc.JdbcUtil;
import com.joainfo.gasmaxplus.bean.CheckVolumeLevelCount;
import com.joainfo.gasmaxplus.bean.list.CheckVolumeLevelCountMap;

/**
 * CheckVolumeLevelCount
 * 원격검침레벨 카운트 비즈니스 로직 처리 객체
 * @author 네오브랜딩
 * @version 1.0
 */
public class BizCheckVolumeLevelCount {


	/**
	 * 주간수신내역 Select 쿼리의 ID
	 */
	public final String GASMAXPLUS_CHECK_VOLUME_LEVEL_COUNT_SELECT_ID = "GASMAXPLUS.CheckVolumeLevelCount.Select";
	
	/**
	 * CheckVolumeLevelCount 인스턴스
	 */
	private static BizCheckVolumeLevelCount bizCheckVolumeLevelCount;
	
	/**
	 * 디폴트 생성자
	 */
	public BizCheckVolumeLevelCount(){
	}
	
	/**
	 * Singleton으로 CheckVolumeLevelCount 인스턴스 생성
	 * @return bizCheckVolumeLevelCount
	 */
	public static BizCheckVolumeLevelCount getInstance(){
		if (bizCheckVolumeLevelCount == null){
			bizCheckVolumeLevelCount = new BizCheckVolumeLevelCount();
		}
		return bizCheckVolumeLevelCount;
	}
	
	/**
	 * 키워드로 검색한 검침레벨카운트 목록을 반환
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param employeeCode
	 * @param areaTypeCode
	 * @param dayLevel9
	 * @param dayLevel8
	 * @param dayLevel7
	 * @param dayLevel6
	 * @param dayLevel5
	 * @param dayLevel4
	 * @param dayLevel3
	 * @param dayLevel2
	 * @param dayLevel1
	 * @param dayLevel0
	 * @return checkVolumeLevelCounts
	 */
	public CheckVolumeLevelCountMap getCheckVolumeLevelCounts(String serverIp, String catalogName, String searchType, String clientNumber, String employeeCode, String areaTypeCode, String dayLevel9, String dayLevel8, String dayLevel7, String dayLevel6, String dayLevel5, String dayLevel4, String dayLevel3, String dayLevel2, String dayLevel1, String dayLevel0){
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("clientNumber", clientNumber);
		String functionName = "N".equals(searchType)?"FN_Meter_Value_CNT_ALL":"FN_Meter_Value_CNT";
		condition.put("functionName", functionName);
		condition.put("employeeCode", employeeCode);
		condition.put("areaTypeCode", areaTypeCode);
		condition.put("dayLevel9", dayLevel9);
		condition.put("dayLevel8", dayLevel8);
		condition.put("dayLevel7", dayLevel7);
		condition.put("dayLevel6", dayLevel6);
		condition.put("dayLevel5", dayLevel5);
		condition.put("dayLevel4", dayLevel4);
		condition.put("dayLevel3", dayLevel3);
		condition.put("dayLevel2", dayLevel2);
		condition.put("dayLevel1", dayLevel1);
		condition.put("dayLevel0", dayLevel0);
		
		return selectCheckVolumeLevelCounts(serverIp, catalogName, condition);
	}
	
	/**
	 * 검침레벨카운트 조회
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param condition 검색 조건
	 * @return CheckVolumeLevelCountMap 형식의 주간수신내역 목록 반환
	 */
	public CheckVolumeLevelCountMap selectCheckVolumeLevelCounts(String serverIp, String catalogName, Map<String, String> condition){
		CheckVolumeLevelCountMap checkVolumeLevelCounts = new CheckVolumeLevelCountMap();
		condition.put("catalogName", catalogName);
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXPLUS_CHECK_VOLUME_LEVEL_COUNT_SELECT_ID, condition);
		for( HashMap<String, String> map :  list) {
			CheckVolumeLevelCount checkVolumeLevelCount = convertCheckVolumeLevelCount(map);
			checkVolumeLevelCounts.setCheckVolumeLevelCount(checkVolumeLevelCount.getKeyValue(), checkVolumeLevelCount);
		}
		return checkVolumeLevelCounts;
	}
	/**
	 * HashMap을 CheckVolumeLevelCount으로 변환
	 * @param map
	 * @return CheckVolumeLevelCount
	 */
	protected static CheckVolumeLevelCount convertCheckVolumeLevelCount(HashMap<String, String> map){
		CheckVolumeLevelCount checkVolumeLevelCount = new CheckVolumeLevelCount();
		
		checkVolumeLevelCount.setClientNumber(map.get("clientNumber"));
		checkVolumeLevelCount.setLevelStateAll(map.get("levelStateAll"));
		checkVolumeLevelCount.setLevelStateOk(map.get("levelStateOk"));
		checkVolumeLevelCount.setReceiveDateOver(map.get("receiveDateOver"));
		checkVolumeLevelCount.setUniformLevel(map.get("uniformLevel"));
		checkVolumeLevelCount.setLowBattery(map.get("lowBattery"));
		
		return checkVolumeLevelCount;
	}
	
	protected static HashMap<String, String> convertCheckVolumeLevelCount(CheckVolumeLevelCount checkVolumeLevelCount){
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", checkVolumeLevelCount.getClientNumber());
	    map.put("levelStateAll", checkVolumeLevelCount.getLevelStateAll());
	    map.put("levelStateOk", checkVolumeLevelCount.getLevelStateOk());
	    map.put("receiveDateOver", checkVolumeLevelCount.getReceiveDateOver());
	    map.put("uniformLevel", checkVolumeLevelCount.getUniformLevel());
	    map.put("lowBattery", checkVolumeLevelCount.getLowBattery());
		
		return map;
	}
	
	/**
	 * 비즈니스 로직 테스트용
	 * @param args
	 */
	public static void main(String[] args){
//		CheckVolumeLevelCount CheckVolumeLevelCount = CheckVolumeLevelCount.getInstance();
		
//		JSONObject jsonObject = JSONObject.fromObject(new HashMap<String, String>);
		

		
/* SELECT */
//		CheckVolumeLevelCountMap CheckVolumeLevelCounts = CheckVolumeLevelCount.getInstance().getTankLevelCounts();		
//		System.out.println(CheckVolumeLevelCounts.toXML());

//		System.out.println(cacheTankLevelCounts.toXML());
	}
}
