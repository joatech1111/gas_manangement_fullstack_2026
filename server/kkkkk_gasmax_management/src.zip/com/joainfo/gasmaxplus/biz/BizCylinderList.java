package com.joainfo.gasmaxplus.biz;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.joainfo.common.util.jdbc.JdbcUtil;
import com.joainfo.gasmaxplus.bean.CylinderList;
import com.joainfo.gasmaxplus.bean.list.CylinderListMap;

/**
 * BizCyliner
 * 절체기 비즈니스 로직 처리 객체
 * @author 네오브랜딩
 * @version 1.0
 */
public class BizCylinderList {


	/**
	 * 절체기 Select 쿼리의 ID
	 */
	public final String GASMAXPLUS_CYLINDER_SELECT_ID = "GASMAXPLUS.Cylinder.Select";
	
	public final String GASMAXPLUS_CYLINDER_CYCLE_SELECT_ID = "GASMAXPLUS.CylinderCycle.Select";
	
	public final String GASMAXPLUS_CYLINDER_CYCLE_EVENT1_SELECT_ID = "GASMAXPLUS.CylinderCycleEvent1.Select";
	
	public final String GASMAXPLUS_CYLINDER_CYCLE_EVENT2_SELECT_ID = "GASMAXPLUS.CylinderCycleEvent2.Select";
	
	/**
	 * BizCylinder 인스턴스
	 */
	private static BizCylinderList bizCylinderList;
	
	/**
	 * 디폴트 생성자
	 */
	public BizCylinderList(){
	}
	
	/**
	 * Singleton으로 BizCylinder 인스턴스 생성
	 * @return bizCylinder
	 */
	public static BizCylinderList getInstance(){
		if (bizCylinderList == null){
			bizCylinderList = new BizCylinderList();
		}
		return bizCylinderList;
	}
	
	/**
	 * 키워드로 검색한 절체기 목록을 반환
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param keyword
	 * @param employeeCode
	 * @param areaTypeCode
	 * @param dayLevel9
	 * @param dayLevel8
	 * @param dayLevel7
	 * @param dayLevel6
	 * @param dayLevel5
	 * @param dayLevel4
	 * @param dayLevel3
	 * @param dayLevel2
	 * @param dayLevel1
	 * @param dayLevel0
	 * @param levelStates
	 * @param receiveDateOver
	 * @param uniformLevel
	 * @param lowBattery
	 * @param orderBy
	 * @return cylinders
	 */
	public CylinderListMap getCylinderLists(String serverIp, String catalogName, String searchType, String clientNumber, String keyword, String employeeCode, String areaTypeCode, String dayLevel9, String dayLevel8, String dayLevel7, String dayLevel6, String dayLevel5, String dayLevel4, String dayLevel3, String dayLevel2, String dayLevel1, String dayLevel0, String levelStates, String receiveDateOver, String aveOver, String lowBattery, String orderBy){
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("clientNumber", clientNumber);
		String functionName = "N".equals(searchType)?"FN_Cylinder_Value_2021_ALL":"FN_Cylinder_Value_2021";
		condition.put("functionName", functionName);
		condition.put("keyword", keyword);
		condition.put("employeeCode", employeeCode);
		condition.put("areaTypeCode", areaTypeCode);
		condition.put("dayLevel9", dayLevel9);
		condition.put("dayLevel8", dayLevel8);
		condition.put("dayLevel7", dayLevel7);
		condition.put("dayLevel6", dayLevel6);
		condition.put("dayLevel5", dayLevel5);
		condition.put("dayLevel4", dayLevel4);
		condition.put("dayLevel3", dayLevel3);
		condition.put("dayLevel2", dayLevel2);
		condition.put("dayLevel1", dayLevel1);
		condition.put("dayLevel0", dayLevel0);
		condition.put("levelStates", levelStates);
		condition.put("receiveDateOver", receiveDateOver);
		condition.put("aveOver", aveOver);
		condition.put("lowBattery", lowBattery);
		condition.put("orderBy", orderBy);

		return selectCylinderLists(serverIp, catalogName, condition);
	}
	
	
	/**
	 * 키워드로 검색한 절체기 목록을 반환
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param keyword
	 * @param employeeCode
	 * @param areaTypeCode
	 * @param dayLevel9
	 * @param dayLevel8
	 * @param dayLevel7
	 * @param dayLevel6
	 * @param dayLevel5
	 * @param dayLevel4
	 * @param dayLevel3
	 * @param dayLevel2
	 * @param dayLevel1
	 * @param dayLevel0
	 * @param levelStates
	 * @param receiveDateOver
	 * @param uniformLevel
	 * @param lowBattery
	 * @param orderBy
	 * @return cylinders
	 */
	public CylinderListMap getCylinderCycleLists(String serverIp, String catalogName, String searchType, String clientNumber, String keyword, String employeeCode, String areaTypeCode, String lastDate, String levelStates, String receiveDateOver, String aveOver, String lowBattery, String orderBy){
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("clientNumber", clientNumber);
		String functionName = "N".equals(searchType)?"FN_Cylinder_CYCLE":"FN_Cylinder_CYCLE";
		condition.put("functionName", functionName);
		condition.put("keyword", keyword);
		condition.put("employeeCode", employeeCode);
		condition.put("areaTypeCode", areaTypeCode);
		condition.put("lastDate", lastDate);
		condition.put("levelStates", levelStates);
		condition.put("receiveDateOver", receiveDateOver);
		condition.put("aveOver", aveOver);
		condition.put("lowBattery", lowBattery);
		condition.put("orderBy", orderBy);

		return selectCylinderCycleLists(serverIp, catalogName, condition, levelStates);
	}
	
	
	
	/**
	 * 절체기 조회
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param condition 검색 조건
	 * @return CylinderMap 형식의 절체기 목록 반환
	 */
	public CylinderListMap selectCylinderLists(String serverIp, String catalogName, Map<String, String> condition){
		CylinderListMap cylinderLists = new CylinderListMap();
		condition.put("catalogName", catalogName);
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXPLUS_CYLINDER_SELECT_ID, condition);
		for( HashMap<String, String> map :  list) {
			CylinderList cylinderList = convertCylinderList(map);
			cylinderLists.setCylinderList(cylinderList.getKeyValue(), cylinderList);
		}
		return cylinderLists;
	}
	
	public CylinderListMap selectCylinderCycleLists(String serverIp, String catalogName, Map<String, String> condition, String levelStates){
		CylinderListMap cylinderLists = new CylinderListMap();
		condition.put("catalogName", catalogName);

		if ("1".equals(levelStates)) {
			
			@SuppressWarnings("rawtypes")
			List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXPLUS_CYLINDER_CYCLE_EVENT1_SELECT_ID, condition);
			
			for( HashMap<String, String> map :  list) {
				CylinderList cylinderList = convertCylinderList(map);
				cylinderLists.setCylinderList(cylinderList.getKeyValue(), cylinderList);
			}
			
		}else if ("2".equals(levelStates)) {

			@SuppressWarnings("rawtypes")
			List<HashMap> list1 = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXPLUS_CYLINDER_CYCLE_EVENT2_SELECT_ID, condition);
			for( HashMap<String, String> map :  list1) {
				CylinderList cylinderList = convertCylinderList(map);
				cylinderLists.setCylinderList(cylinderList.getKeyValue(), cylinderList);
			}
			
		}else {
			
			@SuppressWarnings("rawtypes")
			List<HashMap> list2 = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXPLUS_CYLINDER_CYCLE_SELECT_ID, condition);
			for( HashMap<String, String> map :  list2) {
				CylinderList cylinderList = convertCylinderList(map);
				cylinderLists.setCylinderList(cylinderList.getKeyValue(), cylinderList);
			}
			
		}
		
		return cylinderLists;
	}
	
	
	
	/**
	 * HashMap을 Cylinder으로 변환
	 * @param map
	 * @return Cylinder
	 */
	protected static CylinderList convertCylinderList(HashMap<String, String> map){
		CylinderList cylinder = new CylinderList();
		
		cylinder.setClientNumber(map.get("clientNumber"));
		cylinder.setCustomerCode(map.get("customerCode"));
		cylinder.setTransmitterCode(map.get("transmitterCode"));
		cylinder.setCustomerName(map.get("customerName"));
		cylinder.setInstallationDate(map.get("installationDate"));
		cylinder.setPhoneNumber(map.get("phoneNumber"));
		cylinder.setMobileNumber(map.get("mobileNumber"));
		cylinder.setAddress(map.get("address"));
		cylinder.setItemName(map.get("itemName"));
		cylinder.setItemQty(map.get("itemQty"));
		cylinder.setRemark(map.get("remark"));
		cylinder.setLevel9(map.get("level9"));
		cylinder.setLevel8(map.get("level8"));
		cylinder.setLevel7(map.get("level7"));
		cylinder.setLevel6(map.get("level6"));
		cylinder.setLevel5(map.get("level5"));
		cylinder.setLevel4(map.get("level4"));
		cylinder.setLevel3(map.get("level3"));
		cylinder.setLevel2(map.get("level2"));
		cylinder.setLevel1(map.get("level1"));
		cylinder.setLevel0(map.get("level0"));
		cylinder.setLastLevel(map.get("lastLevel"));
		cylinder.setVolQty(map.get("volQty"));
		cylinder.setGumGage(map.get("gumGage"));
		cylinder.setGumGageColer(map.get("gumGageColer"));
		cylinder.setLastRMeter(map.get("lastRMeter"));
		cylinder.setCustNameColer(map.get("custNameColer"));
		
		return cylinder;
	}
	
	protected static HashMap<String, String> convertCylinderList(CylinderList cylinder){
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", cylinder.getClientNumber());
	    map.put("customerCode", cylinder.getCustomerCode());
	    map.put("transmitterCode", cylinder.getTransmitterCode());
	    map.put("customerName", cylinder.getCustomerName());
	    map.put("installationDate", cylinder.getInstallationDate());
	    map.put("phoneNumber", cylinder.getPhoneNumber());
	    map.put("mobileNumber", cylinder.getMobileNumber());
	    map.put("address", cylinder.getAddress());
	    map.put("itemName", cylinder.getItemName());
	    map.put("itemQty", cylinder.getItemQty());
	    map.put("remark", cylinder.getRemark());
	    map.put("level9", cylinder.getLevel9());
	    map.put("level8", cylinder.getLevel8());
	    map.put("level7", cylinder.getLevel7());
	    map.put("level6", cylinder.getLevel6());
	    map.put("level5", cylinder.getLevel5());
	    map.put("level4", cylinder.getLevel4());
	    map.put("level3", cylinder.getLevel3());
	    map.put("level2", cylinder.getLevel2());
	    map.put("level1", cylinder.getLevel1());
	    map.put("level0", cylinder.getLevel0());
	    map.put("lastLevel", cylinder.getLastLevel());
	    map.put("volQty", cylinder.getVolQty());
	    map.put("gumGage", cylinder.getGumGage());
	    map.put("gumGageColer", cylinder.getGumGageColer());
	    map.put("lastRMeter", cylinder.getLastRMeter());
	    map.put("custNameColer", cylinder.getCustNameColer());
	    
		return map;
	}
	
	/**
	 * 비즈니스 로직 테스트용
	 * @param args
	 */
	public static void main(String[] args){
//		BizCylinder bizCylinder = BizCylinder.getInstance();
		
//		JSONObject jsonObject = JSONObject.fromObject(new HashMap<String, String>);
		

		
/* SELECT */
//		CylinderMap cylinders = BizCylinder.getInstance().getCylinders();		
//		System.out.println(cylinders.toXML());

/* INSERT OR UPDATE*/
//		Cylinder cylinder = new Cylinder();
//		cylinder.setCylinderCode("TEST1");
//		cylinder.setCylinderName("TEST Cylinder1");
//		cylinder.setUseYesNo("Y");
//		BizCylinder.getInstance().applyCylinder(cylinder);
		
/* DELETE */
//		BizCylinder.getInstance().deleteCylinder("TEST");
		
/* DELETE LIST */
//		List<String> list = new java.util.ArrayList<String>();
//		list.add("TEST1");
//		list.add("TEST2");
//		BizCylinder.getInstance().deleteCylinders(list);

/* SELECT */
//		BizCylinder.getInstance().initCacheCylinders();
//		System.out.println(cacheCylinders.toXML());
//		

//		System.out.println(cacheCylinders.toXML());
	}
}
