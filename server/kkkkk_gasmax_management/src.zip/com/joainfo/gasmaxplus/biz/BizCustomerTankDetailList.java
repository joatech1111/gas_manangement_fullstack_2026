package com.joainfo.gasmaxplus.biz;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.joainfo.common.util.jdbc.JdbcUtil;
import com.joainfo.gasmaxplus.bean.CustomerTankDetailList;
import com.joainfo.gasmaxplus.bean.list.CustomerTankDetailListMap;

/**
 * BizCustomerTankDetailList
 * 거래처 탱크잔량상세내역 비즈니스 로직 처리 객체
 * @author 백원태
 * @version 1.0
 */
public class BizCustomerTankDetailList {


	/**
	 * 거래처 탱크잔량상세내역 Select 쿼리의 ID
	 */
	public final String GASMAXPLUS_CUSTOMER_TANK_DETAIL_LIST_SELECT_ID = "GASMAXPLUS.CustomerTankDetailList.Select";

	/**
	 * 거래처 탱크잔량상세내역 Select 쿼리의 ID
	 */
	public final String GASMAXPLUS_CUSTOMER_TANK_DETAIL_LIST_DATE_SELECT_ID = "GASMAXPLUS.CustomerTankDetailListDate.Select";
	
	/**
	 * BizCustomerTankDetailList 인스턴스
	 */
	private static BizCustomerTankDetailList bizCustomerTankDetailList;
	
	/**
	 * 디폴트 생성자
	 */
	public BizCustomerTankDetailList(){
	}
	
	/**
	 * Singleton으로 BizCustomerTankDetailList 인스턴스 생성
	 * @return bizCustomerTankDetailList
	 */
	public static BizCustomerTankDetailList getInstance(){
		if (bizCustomerTankDetailList == null){
			bizCustomerTankDetailList = new BizCustomerTankDetailList();
		}
		return bizCustomerTankDetailList;
	}
	
	/**
	 * 키워드로 검색한 거래처 탱크잔량상세내역 목록을 반환
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param clientNumber
	 * @param customerCode
	 * @param startDate
	 * @param endDate
	 * @return customerTankDetailLists
	 */
	public CustomerTankDetailListMap getCustomerTankDetailLists(String serverIp, String catalogName, String clientNumber, String customerCode, String startDate, String endDate, String gubun){
		HashMap<String, String> condition = new HashMap<String, String>();
		
		
		condition.put("clientNumber", clientNumber);
		condition.put("customerCode", customerCode);
		condition.put("startDate", startDate);
		condition.put("endDate", endDate);
		
		return selectCustomerTankDetailLists(serverIp, catalogName, condition,gubun);
	}
	
	/**
	 * 거래처 탱크잔량상세내역 조회
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param condition 검색 조건
	 * @return CustomerTankDetailListMap 형식의 거래처 탱크잔량상세내역 목록 반환
	 */
	@SuppressWarnings("unchecked")
	public CustomerTankDetailListMap selectCustomerTankDetailLists(String serverIp, String catalogName, Map<String, String> condition, String gubun){
		CustomerTankDetailListMap customerTankDetailLists = new CustomerTankDetailListMap();
		condition.put("catalogName", catalogName);

		if("DETAIL".equals(gubun)) {

			@SuppressWarnings("rawtypes")
			List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXPLUS_CUSTOMER_TANK_DETAIL_LIST_SELECT_ID, condition);

			for( HashMap<String, String> map :  list) {
				CustomerTankDetailList customerTankDetailList = convertCustomerTankDetailList(map);
				customerTankDetailLists.setCustomerTankDetailList(customerTankDetailList.getKeyValue(), customerTankDetailList);
			}
		
		}else {
			
			@SuppressWarnings("rawtypes")
			List<HashMap> list1 = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXPLUS_CUSTOMER_TANK_DETAIL_LIST_DATE_SELECT_ID, condition);

			for( HashMap<String, String> map :  list1) {
				CustomerTankDetailList customerTankDetailList = convertCustomerTankDetailList(map);
				customerTankDetailLists.setCustomerTankDetailList(customerTankDetailList.getKeyValue(), customerTankDetailList);
			}
		}
		
		return customerTankDetailLists;
	}
	
	/**
	 * HashMap을 CustomerTankDetailList으로 변환
	 * @param map
	 * @return CustomerTankDetailList
	 */
	protected static CustomerTankDetailList convertCustomerTankDetailList(HashMap<String, String> map){
		CustomerTankDetailList customerTankDetailList = new CustomerTankDetailList();
		
		customerTankDetailList.setClientNumber(map.get("clientNumber"));
		customerTankDetailList.setCustomerCode(map.get("customerCode"));
		customerTankDetailList.setTransmitterCode(map.get("transmitterCode"));
		customerTankDetailList.setReceiveDate(map.get("receiveDate"));
		customerTankDetailList.setReceiveTime(map.get("receiveTime"));
		customerTankDetailList.setLevel(map.get("level"));
		customerTankDetailList.setEventCode(map.get("eventCode"));
		customerTankDetailList.setEventName(map.get("eventName"));
		customerTankDetailList.setRemoteCount(map.get("remoteCount"));
		customerTankDetailList.setBatteryPercent(map.get("batteryPercent"));
		customerTankDetailList.setBatteryVolt(map.get("batteryVolt"));
		
		return customerTankDetailList;
	}
	
	protected static HashMap<String, String> convertCustomerTankDetailList(CustomerTankDetailList customerTankDetailList){
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", customerTankDetailList.getClientNumber());
	    map.put("customerCode", customerTankDetailList.getCustomerCode());
	    map.put("transmitterCode", customerTankDetailList.getTransmitterCode());
	    map.put("receiveDate", customerTankDetailList.getReceiveDate());
	    map.put("receiveTime", customerTankDetailList.getReceiveTime());
	    map.put("level", customerTankDetailList.getLevel());
	    map.put("eventCode", customerTankDetailList.getEventCode());
	    map.put("eventName", customerTankDetailList.getEventName());
	    map.put("remoteCount", customerTankDetailList.getRemoteCount());
	    map.put("batteryPercent", customerTankDetailList.getBatteryPercent());
	    map.put("batteryVolt", customerTankDetailList.getBatteryVolt());
		
		return map;
	}
	
	/**
	 * 비즈니스 로직 테스트용
	 * @param args
	 */
	public static void main(String[] args){
//		BizCustomerTankDetailList bizCustomerTankDetailList = BizCustomerTankDetailList.getInstance();
		
//		JSONObject jsonObject = JSONObject.fromObject(new HashMap<String, String>);
		

		
/* SELECT */
//		CustomerTankDetailListMap customerTankDetailLists = BizCustomerTankDetailList.getInstance().getCustomerTankDetailLists();		
//		System.out.println(customerTankDetailLists.toXML());

/* INSERT OR UPDATE*/
//		CustomerTankDetailList customerTankDetailList = new CustomerTankDetailList();
//		customerTankDetailList.setCustomerTankDetailListCode("TEST1");
//		customerTankDetailList.setCustomerTankDetailListName("TEST CustomerTankDetailList1");
//		customerTankDetailList.setUseYesNo("Y");
//		BizCustomerTankDetailList.getInstance().applyCustomerTankDetailList(customerTankDetailList);
		
/* DELETE */
//		BizCustomerTankDetailList.getInstance().deleteCustomerTankDetailList("TEST");
		
/* DELETE LIST */
//		List<String> list = new java.util.ArrayList<String>();
//		list.add("TEST1");
//		list.add("TEST2");
//		BizCustomerTankDetailList.getInstance().deleteCustomerTankDetailLists(list);

/* SELECT */
//		BizCustomerTankDetailList.getInstance().initCacheCustomerTankDetailLists();
//		System.out.println(cacheCustomerTankDetailLists.toXML());
//		

//		System.out.println(cacheCustomerTankDetailLists.toXML());
	}
}
