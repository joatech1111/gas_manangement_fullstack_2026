package com.joainfo.gasmaxplus.biz;

import java.util.HashMap;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.joainfo.common.util.jdbc.JdbcUtil;
import com.joainfo.gasmaxplus.bean.CustomerDetailInfo;

/**
 * BizWeeklyList 주간수신내역 비즈니스 로직 처리 객체
 * 
 * @author 백원태
 * @version 1.0
 */
public class BizCustomerDetailInfo {

	/**
	 * 거래처 상세정보 Select 쿼리의 ID
	 */
	public final String GASMAXPLUS_CUSTOMER_DETAIL_INFO_SELECT_ID = "GASMAXPLUS.CustomerDetailInfo.Select";

	/**
	 * 거래처 수정 Update 쿼리의 ID
	 */
	public final String GASMAXPLUS_CUSTOMER_DETAIL_INFO_UPDATE_ID = "GASMAXPLUS.CustomerDetailInfo.Update";

	/**
	 * CustomerDetailInfo 인스턴스
	 */
	private static BizCustomerDetailInfo bizCustomerDetailInfo;

	/**
	 * 디폴트 생성자
	 */
	public BizCustomerDetailInfo() {
	}

	/**
	 * Singleton으로 CustomerDetailInfo 인스턴스 생성
	 * 
	 * @return customerDetailInfo
	 */
	public static BizCustomerDetailInfo getInstance() {
		if (bizCustomerDetailInfo == null) {
			bizCustomerDetailInfo = new BizCustomerDetailInfo();
		}
		return bizCustomerDetailInfo;
	}

	/**
	 * 거래처 상세정보 조회
	 */
	public CustomerDetailInfo getCustomerDetailInfo(String serverIp, String catalogName, String clientNumber,
			String customerCode, String customerDiv) {
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("clientNumber", clientNumber);
		String functionName = "FN_CUST_SELECT_INFO_2022";
		condition.put("functionName", functionName);
		condition.put("customerCode", customerCode);
		condition.put("customerDiv", customerDiv);

		SimpleDateFormat sdf = null;
		sdf = new SimpleDateFormat("yyyyMMdd");
		Date currentDate = new Date();
		String lastDate = sdf.format(currentDate);
		condition.put("lastDate", lastDate);

		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXPLUS_CUSTOMER_DETAIL_INFO_SELECT_ID,
				condition);

		CustomerDetailInfo customerDetailInfo = new CustomerDetailInfo();
		for (HashMap<String, String> map : list) {
			customerDetailInfo = convertCustomerDetailInfo(map);
		}

		return customerDetailInfo;
	}

	/**
	 * HashMap을 WeeklyList으로 변환
	 * 
	 * @param map
	 * @return WeeklyList
	 */
	protected static CustomerDetailInfo convertCustomerDetailInfo(HashMap<String, String> map) {
		CustomerDetailInfo customerDetailInfo = new CustomerDetailInfo();

		customerDetailInfo.setClientNumber(map.get("clientNumber"));
		customerDetailInfo.setCustomerCode(map.get("customerCode"));
		customerDetailInfo.setCustomerName(map.get("customerName"));
		customerDetailInfo.setCustCount(map.get("custCount"));
		customerDetailInfo.setCustTel(map.get("custTel"));
		customerDetailInfo.setCustHp(map.get("custHp"));
		customerDetailInfo.setZipCd(map.get("zipCd"));
		customerDetailInfo.setAddr1(map.get("addr1"));
		customerDetailInfo.setAddr2(map.get("addr2"));
		customerDetailInfo.setGpsX(map.get("gpsX"));
		customerDetailInfo.setGpsY(map.get("gpsY"));
		customerDetailInfo.setSwCode(map.get("swCode"));
		customerDetailInfo.setSwName(map.get("swName"));
		customerDetailInfo.setcAreaCode(map.get("cAreaCode"));
		customerDetailInfo.setcAreaName(map.get("cAreaName"));
		customerDetailInfo.setTransmCd(map.get("transmCd"));
		customerDetailInfo.setcType(map.get("cType"));
		customerDetailInfo.setTankVol(map.get("tankVol"));
		customerDetailInfo.setcVol(map.get("cVol"));
		customerDetailInfo.setcQty(map.get("cQty"));
		customerDetailInfo.setRemark(map.get("remark"));
		customerDetailInfo.setLastRdate(map.get("lastRdate"));
		customerDetailInfo.setE2Date1(map.get("e2Date1"));
		customerDetailInfo.setE2AveDate(map.get("e2AveDate"));
		customerDetailInfo.setE2AveMeter(map.get("e2AveMeter"));
		customerDetailInfo.setGumGage(map.get("gumGage"));
		customerDetailInfo.setUseDay(map.get("useDay"));
		customerDetailInfo.setBefUsage(map.get("befUsage"));
		customerDetailInfo.setMonUsage(map.get("monUsage"));
		customerDetailInfo.setWeekUsage(map.get("weekUsage"));
		customerDetailInfo.setAvgMonth(map.get("avgMonth"));
		customerDetailInfo.setAvgDay(map.get("avgDay"));
		customerDetailInfo.setFinishLevelImg(map.get("finishLevelImg"));

		return customerDetailInfo;
	}

	/**
	 * 거래처 정보 수정
	 */
	public int setCustomerDetailInfo(String serverIp, String catalogName, String clientNumber, String customerCode,
			String customerDiv, String customerName, String meterLavel, String transmCd, String transmCdOrg,
			String zipCd, String addr1, String addr2, String gpsX, String gpsY, String swCode, String cType,
			String cVol, String cQty, String cAreaCode, String remark, String appUser) {
		HashMap<String, String> condition = new HashMap<String, String>();

		condition.put("clientNumber", clientNumber);
		condition.put("customerCode", customerCode);
		condition.put("customerDiv", customerDiv);

		condition.put("customerName", customerName);
		condition.put("meterLavel", meterLavel);
		condition.put("transmCd", transmCd);
		condition.put("transmCdOrg", transmCdOrg);
		condition.put("zipCd", zipCd);

		condition.put("addr1", addr1);
		condition.put("addr2", addr2);
		condition.put("gpsX", gpsX);
		condition.put("gpsY", gpsY);
		condition.put("swCode", swCode);

		condition.put("cType", cType);
		condition.put("cVol", cVol);
		condition.put("cQty", cQty);
		condition.put("cAreaCode", cAreaCode);
		condition.put("remark", remark);

		condition.put("appUser", appUser);
		
		

		return updateCustomerDetailInfo(serverIp, catalogName, condition);
	}

	/**
	 * @param condition
	 * @return
	 */
	protected int updateCustomerDetailInfo(String serverIp, String catalogName, HashMap<String, String> condition) {
		return JdbcUtil.getInstance(serverIp).updateQuery(GASMAXPLUS_CUSTOMER_DETAIL_INFO_UPDATE_ID, condition);
	}

	/**
	 * 비즈니스 로직 테스트용
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
//		BizWeeklyList bizWeeklyList = BizWeeklyList.getInstance();

//		JSONObject jsonObject = JSONObject.fromObject(new HashMap<String, String>);

		/* SELECT */
//		WeeklyListMap weeklyLists = BizWeeklyList.getInstance().getWeeklyLists();		
//		System.out.println(weeklyLists.toXML());

		/* INSERT OR UPDATE */
//		WeeklyList weeklyList = new WeeklyList();
//		weeklyList.setWeeklyListCode("TEST1");
//		weeklyList.setWeeklyListName("TEST WeeklyList1");
//		weeklyList.setUseYesNo("Y");
//		BizWeeklyList.getInstance().applyWeeklyList(weeklyList);

		/* DELETE */
//		BizWeeklyList.getInstance().deleteWeeklyList("TEST");

		/* DELETE LIST */
//		List<String> list = new java.util.ArrayList<String>();
//		list.add("TEST1");
//		list.add("TEST2");
//		BizWeeklyList.getInstance().deleteWeeklyLists(list);

		/* SELECT */
//		BizWeeklyList.getInstance().initCacheWeeklyLists();
//		System.out.println(cacheWeeklyLists.toXML());
//		

//		System.out.println(cacheWeeklyLists.toXML());
	}
}
