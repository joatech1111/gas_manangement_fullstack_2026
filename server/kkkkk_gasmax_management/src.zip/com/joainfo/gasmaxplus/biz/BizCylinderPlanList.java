package com.joainfo.gasmaxplus.biz;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.joainfo.common.util.jdbc.JdbcUtil;
import com.joainfo.gasmaxplus.bean.CylinderPlanList;
import com.joainfo.gasmaxplus.bean.list.CylinderPlanListMap;

/**
 * BizCylinderPlanInfo
 * 예상공급사용량 비즈니스 로직 처리 객체
 */
public class BizCylinderPlanList {

	/**
	 * 예상공급사용량 Select 쿼리의 ID
	 */
	public final String GASMAXPLUS_CYLINDER_PLAN_LIST_SELECT_ID = "GASMAXPLUS.CylinderPlanList.Select";
	

	/**
	 * BizCylinderPlanInfo 인스턴스
	 */
	private static BizCylinderPlanList bizCylinderPlanList;
	
	/**
	 * 디폴트 생성자
	 */
	public BizCylinderPlanList(){
	}
	
	/**
	 * Singleton으로 BizCylinderPlanInfo 인스턴스 생성
	 * @return bizCylinder
	 */
	public static BizCylinderPlanList getInstance(){
		if (bizCylinderPlanList == null){
			bizCylinderPlanList = new BizCylinderPlanList();
		}
		return bizCylinderPlanList;
	}
	
	/**
	 * 예상공급검침 리스트 조회
	 */
	public CylinderPlanListMap getCylinderPlanList(String serverIp, String catalogName, String clientNumber, String employeeCode, String areaTypeCode, String keyword, String date, String filterType, String rcvType, String orderBy ){
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("clientNumber", clientNumber);
		String functionName = "FN_Plan_Meter_Value_2020";
		condition.put("functionName", functionName);
		condition.put("swCode", employeeCode);
		condition.put("cAreaCode", areaTypeCode);
		condition.put("keyword", keyword);
		condition.put("date", date);
		condition.put("filterType", filterType);
		condition.put("rcvType", rcvType);
		condition.put("orderBy", orderBy);
		return selectCylinderPlanLists(serverIp, catalogName, condition);
	}
	
	/**
	 */
	public CylinderPlanListMap selectCylinderPlanLists(String serverIp, String catalogName, Map<String, String> condition){
		CylinderPlanListMap cylinderPlanLists = new CylinderPlanListMap();
		condition.put("catalogName", catalogName);
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXPLUS_CYLINDER_PLAN_LIST_SELECT_ID, condition);
		for( HashMap<String, String> map :  list) {
			CylinderPlanList cylinderPlanList = convertCylinderPlanList(map);
			cylinderPlanLists.setCylinderPlanList(cylinderPlanList.getKeyValue(), cylinderPlanList);
		}
		
		return cylinderPlanLists;
	}

	/**
	 * HashMap을 WeeklyList으로 변환
	 * @param map
	 * @return WeeklyList
	 */
	protected static CylinderPlanList convertCylinderPlanList(HashMap<String, String> map){
		CylinderPlanList cylinderPlanList = new CylinderPlanList();
		
		cylinderPlanList.setClientNumber(map.get("clientNumber"));
		cylinderPlanList.setCustomerCode(map.get("customerCode"));
		cylinderPlanList.setCustJCode(map.get("custJCode"));
		cylinderPlanList.setCustMCode(map.get("custMCode"));
		cylinderPlanList.setTransmCd(map.get("transmCd"));
		cylinderPlanList.setCustomerName(map.get("customerName"));
		cylinderPlanList.setcVol(map.get("cVol"));
		cylinderPlanList.setcQty(map.get("cQty"));
		cylinderPlanList.setcVolQty(map.get("cVolQty"));
		cylinderPlanList.setcDate(map.get("cDate"));
		cylinderPlanList.setJmDiv(map.get("jmDiv"));
		cylinderPlanList.setMeterF(map.get("meterF"));
		cylinderPlanList.setMeterT(map.get("meterT"));
		cylinderPlanList.setSetCount(map.get("setCount"));
		cylinderPlanList.setMeterOver(map.get("meterOver"));
		cylinderPlanList.setFilterType(map.get("filterType"));
		cylinderPlanList.setRcvType(map.get("rcvType"));
		cylinderPlanList.setjState(map.get("jState"));
		
		return cylinderPlanList;
	}
	
	/**
	 * 비즈니스 로직 테스트용
	 * @param args
	 */
	public static void main(String[] args){
//		BizCylinder bizCylinder = BizCylinder.getInstance();
		
//		JSONObject jsonObject = JSONObject.fromObject(new HashMap<String, String>);
		

		
/* SELECT */
//		CylinderMap cylinders = BizCylinder.getInstance().getCylinders();		
//		System.out.println(cylinders.toXML());

/* INSERT OR UPDATE*/
//		Cylinder cylinder = new Cylinder();
//		cylinder.setCylinderCode("TEST1");
//		cylinder.setCylinderName("TEST Cylinder1");
//		cylinder.setUseYesNo("Y");
//		BizCylinder.getInstance().applyCylinder(cylinder);
		
/* DELETE */
//		BizCylinder.getInstance().deleteCylinder("TEST");
		
/* DELETE LIST */
//		List<String> list = new java.util.ArrayList<String>();
//		list.add("TEST1");
//		list.add("TEST2");
//		BizCylinder.getInstance().deleteCylinders(list);

/* SELECT */
//		BizCylinder.getInstance().initCacheCylinders();
//		System.out.println(cacheCylinders.toXML());
//		

//		System.out.println(cacheCylinders.toXML());
	}
}
