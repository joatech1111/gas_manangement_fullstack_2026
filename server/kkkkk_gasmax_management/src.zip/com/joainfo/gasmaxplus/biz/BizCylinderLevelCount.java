package com.joainfo.gasmaxplus.biz;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.joainfo.common.util.jdbc.JdbcUtil;
import com.joainfo.gasmaxplus.bean.CylinderLevelCount;
import com.joainfo.gasmaxplus.bean.list.CylinderLevelCountMap;

/**
 * CylinderLevelCount
 * 원격검침레벨 카운트 비즈니스 로직 처리 객체
 * @author 네오브랜딩
 * @version 1.0
 */
public class BizCylinderLevelCount {


	/**
	 * 주간수신내역 Select 쿼리의 ID
	 */
	public final String GASMAXPLUS_CYLINDER_LEVEL_COUNT_SELECT_ID = "GASMAXPLUS.CylinderLevelCount.Select";

	public final String GASMAXPLUS_CYLINDER_CYCLE_COUNT_SELECT_ID = "GASMAXPLUS.CylinderCycleCount.Select";
	
	/**
	 * CylinderLevelCount 인스턴스
	 */
	private static BizCylinderLevelCount bizCylinderLevelCount;
	
	/**
	 * 디폴트 생성자
	 */
	public BizCylinderLevelCount(){
	}
	
	/**
	 * Singleton으로 CylindereLevelCount 인스턴스 생성
	 * @return bizCylindereLevelCount
	 */
	public static BizCylinderLevelCount getInstance(){
		if (bizCylinderLevelCount == null){
			bizCylinderLevelCount = new BizCylinderLevelCount();
		}
		return bizCylinderLevelCount;
	}
	
	/**
	 * 키워드로 검색한 검침레벨카운트 목록을 반환
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param employeeCode
	 * @param areaTypeCode
	 * @param dayLevel9
	 * @param dayLevel8
	 * @param dayLevel7
	 * @param dayLevel6
	 * @param dayLevel5
	 * @param dayLevel4
	 * @param dayLevel3
	 * @param dayLevel2
	 * @param dayLevel1
	 * @param dayLevel0
	 * @return checkVolumeLevelCounts
	 */
	public CylinderLevelCountMap getCylinderLevelCounts(String serverIp, String catalogName, String searchType, String clientNumber, String employeeCode, String areaTypeCode, String dayLevel9, String dayLevel8, String dayLevel7, String dayLevel6, String dayLevel5, String dayLevel4, String dayLevel3, String dayLevel2, String dayLevel1, String dayLevel0){
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("clientNumber", clientNumber);
		String functionName = "N".equals(searchType)?"FN_Cylinder_Value_CNT_ALL_2021":"FN_Cylinder_Value_CNT_2021";
		condition.put("functionName", functionName);
		condition.put("employeeCode", employeeCode);
		condition.put("areaTypeCode", areaTypeCode);
		condition.put("dayLevel9", dayLevel9);
		condition.put("dayLevel8", dayLevel8);
		condition.put("dayLevel7", dayLevel7);
		condition.put("dayLevel6", dayLevel6);
		condition.put("dayLevel5", dayLevel5);
		condition.put("dayLevel4", dayLevel4);
		condition.put("dayLevel3", dayLevel3);
		condition.put("dayLevel2", dayLevel2);
		condition.put("dayLevel1", dayLevel1);
		condition.put("dayLevel0", dayLevel0);

		return selectCylinderLevelCounts(serverIp, catalogName, condition);
	}
	
	/**
	 * 키워드로 검색한 검침레벨카운트 목록을 반환
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param employeeCode
	 * @param areaTypeCode
	 * @param dayLevel9
	 * @param dayLevel8
	 * @param dayLevel7
	 * @param dayLevel6
	 * @param dayLevel5
	 * @param dayLevel4
	 * @param dayLevel3
	 * @param dayLevel2
	 * @param dayLevel1
	 * @param dayLevel0
	 * @return checkVolumeLevelCounts
	 */
	public CylinderLevelCountMap getCylinderCycleCounts(String serverIp, String catalogName, String searchType, String clientNumber, String employeeCode, String areaTypeCode, String keyword, String lastDate){
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("clientNumber", clientNumber);
		String functionName = "N".equals(searchType)?"FN_Cylinder_CYCLE":"FN_Cylinder_CYCLE";
		condition.put("functionName", functionName);
		condition.put("employeeCode", employeeCode);
		condition.put("areaTypeCode", areaTypeCode);
		condition.put("keyword", keyword);
		condition.put("lastDate", lastDate);

		return selectCylinderCycleCounts(serverIp, catalogName, condition);
	}
	
	
	
	
	/**
	 * 절체기레벨카운트 조회
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param condition 검색 조건
	 * @return CylindereLevelCountMap 형식의 주간수신내역 목록 반환
	 */
	public CylinderLevelCountMap selectCylinderLevelCounts(String serverIp, String catalogName, Map<String, String> condition){
		CylinderLevelCountMap cylinderLevelCounts = new CylinderLevelCountMap();
		condition.put("catalogName", catalogName);
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXPLUS_CYLINDER_LEVEL_COUNT_SELECT_ID, condition);
		for( HashMap<String, String> map :  list) {
			CylinderLevelCount cylinderLevelCount = convertCylinderLevelCount(map);
			cylinderLevelCounts.setCylinderLevelCount(cylinderLevelCount.getKeyValue(), cylinderLevelCount);
		}
		return cylinderLevelCounts;
	}
	
	public CylinderLevelCountMap selectCylinderCycleCounts(String serverIp, String catalogName, Map<String, String> condition){
		CylinderLevelCountMap cylinderLevelCounts = new CylinderLevelCountMap();
		condition.put("catalogName", catalogName);

		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXPLUS_CYLINDER_CYCLE_COUNT_SELECT_ID, condition);
		for( HashMap<String, String> map :  list) {
			CylinderLevelCount cylinderLevelCount = convertCylinderLevelCount(map);
			cylinderLevelCounts.setCylinderLevelCount(cylinderLevelCount.getKeyValue(), cylinderLevelCount);
		}
		return cylinderLevelCounts;
	}
	
	
	/**
	 * HashMap을 CylinderLevelCount으로 변환
	 * @param map
	 * @return CylinderLevelCount
	 */
	protected static CylinderLevelCount convertCylinderLevelCount(HashMap<String, String> map){
		CylinderLevelCount cylinderLevelCount = new CylinderLevelCount();
		
		cylinderLevelCount.setClientNumber(map.get("clientNumber"));
		cylinderLevelCount.setLevelStateAll(map.get("levelStateAll"));
		cylinderLevelCount.setLevelStateFull(map.get("levelStateFull"));
		cylinderLevelCount.setLevelStateFail(map.get("levelStateFail"));
		cylinderLevelCount.setReceiveDateOver(map.get("receiveDateOver"));
		cylinderLevelCount.setUniformLevel(map.get("uniformLevel"));
		cylinderLevelCount.setLowBattery(map.get("lowBattery"));
		cylinderLevelCount.setAveOver(map.get("aveOver"));
		
		return cylinderLevelCount;
	}
	
	protected static HashMap<String, String> convertCylinderLevelCount(CylinderLevelCount cylinderLevelCount){
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", cylinderLevelCount.getClientNumber());
	    map.put("levelStateAll", cylinderLevelCount.getLevelStateAll());
	    map.put("levelStateFull", cylinderLevelCount.getLevelStateFull());
	    map.put("levelStateFail", cylinderLevelCount.getLevelStateFail());
	    map.put("receiveDateOver", cylinderLevelCount.getReceiveDateOver());
	    map.put("uniformLevel", cylinderLevelCount.getUniformLevel());
	    map.put("lowBattery", cylinderLevelCount.getLowBattery());
	    map.put("aveOver", cylinderLevelCount.getAveOver());
		
		return map;
	}
	
	/**
	 * 비즈니스 로직 테스트용
	 * @param args
	 */
	public static void main(String[] args){
//		CylinderLevelCount CylinderLevelCount = CylinderLevelCount.getInstance();
		
//		JSONObject jsonObject = JSONObject.fromObject(new HashMap<String, String>);
		

		
/* SELECT */
//		CylinderLevelCountMap CylinderLevelCounts = CylinderLevelCount.getInstance().getCylinderLevelCounts();		
//		System.out.println(CylinderLevelCounts.toXML());

//		System.out.println(cylinderLevelCounts.toXML());
	}
}
