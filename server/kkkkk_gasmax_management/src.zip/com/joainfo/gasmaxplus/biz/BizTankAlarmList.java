package com.joainfo.gasmaxplus.biz;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.joainfo.common.util.jdbc.JdbcUtil;
import com.joainfo.gasmaxplus.bean.TankAlarmList;
import com.joainfo.gasmaxplus.bean.list.TankAlarmListMap;

/**
 * BizTankAlarmList
 * 가스 누설 경보 알림리스트 비즈니스 로직 처리 객체
 * @version 1.0
 */
public class BizTankAlarmList {

	/**
	 * 거래처 탱크잔량상세내역 Select 쿼리의 ID
	 */
	public final String GASMAXPLUS_TANK_ALARM_LIST_SELECT_ID = "GASMAXPLUS.TankAlarmList.Select";
	
	/**
	 * BizTankAlarmList 인스턴스
	 */
	private static BizTankAlarmList bizTankAlarmList;
	
	/**
	 * 디폴트 생성자
	 */
	public BizTankAlarmList(){
	}
	
	/**
	 * Singleton으로 BizTankAlarmList 인스턴스 생성
	 * @return bizTankAlarmList
	 */
	public static BizTankAlarmList getInstance(){
		if (bizTankAlarmList == null){
			bizTankAlarmList = new BizTankAlarmList();
		}
		return bizTankAlarmList;
	}
	
	/**
	 * 키워드로 검색한 거래처 탱크잔량상세내역 목록을 반환
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param clientNumber
	 * @param customerCode
	 * @param startDate
	 * @param endDate
	 * @return TankAlarmListMap
	 */
	public TankAlarmListMap getTankAlarmLists(String serverIp, String catalogName, String clientNumber, String customerCode, String areaTypeCode, String searchDate){
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("clientNumber", clientNumber);
		condition.put("customerCode", customerCode);
		condition.put("areaTypeCode", areaTypeCode);
		condition.put("searchDate", searchDate);
		return selectTankAlarmLists(serverIp, catalogName, condition);
	}
	
	/**
	 * 거래처 탱크잔량상세내역 조회
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param condition 검색 조건
	 * @return TankAlarmListMap
	 */
	public TankAlarmListMap selectTankAlarmLists(String serverIp, String catalogName, Map<String, String> condition){
		TankAlarmListMap tankAlarmLists = new TankAlarmListMap();
		condition.put("catalogName", catalogName);
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXPLUS_TANK_ALARM_LIST_SELECT_ID, condition);
		for( HashMap<String, String> map :  list) {
			TankAlarmList tankAlarmList = convertTankAlarmList(map);
			tankAlarmLists.setTankAlarmList(tankAlarmList.getKeyValue(), tankAlarmList);
		}
		return tankAlarmLists;
	}
	/**
	 * HashMap을 TankAlarmList 변환
	 * @param map
	 * @return TankAlarmList
	 */
	protected static TankAlarmList convertTankAlarmList(HashMap<String, String> map){
		TankAlarmList tankAlarmList = new TankAlarmList();
		
		tankAlarmList.setClientNumber(map.get("clientNumber"));
		tankAlarmList.setCustomerCode(map.get("customerCode"));
		tankAlarmList.setCustomerName(map.get("customerName"));
		tankAlarmList.setTransmitterCode(map.get("transmitterCode"));
		tankAlarmList.setReceivedDate(map.get("receivedDate"));
		tankAlarmList.setReceivedTime(map.get("receivedTime"));
		tankAlarmList.setLevel(map.get("level"));
		tankAlarmList.setEventCode(map.get("eventCode"));
		tankAlarmList.setBatteryVolt(map.get("batteryVolt"));
		tankAlarmList.setAlarmFlag(map.get("alarmFlag"));
		
		return tankAlarmList;
	}
	
	protected static HashMap<String, String> convertTankAlarmList(TankAlarmList tankAlarmList){
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", tankAlarmList.getClientNumber());
	    map.put("customerCode", tankAlarmList.getCustomerCode());
	    map.put("customerName", tankAlarmList.getCustomerName());
	    map.put("transmitterCode", tankAlarmList.getTransmitterCode());
	    map.put("receivedDate", tankAlarmList.getReceivedDate());
	    map.put("receivedTime", tankAlarmList.getReceivedTime());
	    map.put("level", tankAlarmList.getLevel());
	    map.put("eventCode", tankAlarmList.getEventCode());
	    map.put("batteryVolt", tankAlarmList.getBatteryVolt());
	    map.put("alarmFlag", tankAlarmList.getAlarmFlag());
		
		return map;
	}
	
	/**
	 * 비즈니스 로직 테스트용
	 * @param args
	 */
	public static void main(String[] args){
	}
}
