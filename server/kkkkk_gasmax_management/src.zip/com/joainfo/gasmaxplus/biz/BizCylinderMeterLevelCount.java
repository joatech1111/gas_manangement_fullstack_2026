package com.joainfo.gasmaxplus.biz;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.joainfo.common.util.jdbc.JdbcUtil;
import com.joainfo.gasmaxplus.bean.CylinderMeterLevelCount;
import com.joainfo.gasmaxplus.bean.list.CylinderMeterLevelCountMap;

/**
 * CylinderLevelCount
 * 원격검침레벨 카운트 비즈니스 로직 처리 객체
 * @author 네오브랜딩
 * @version 1.0
 */
public class BizCylinderMeterLevelCount {


	/**
	 * 주간수신내역 Select 쿼리의 ID
	 */
	public final String GASMAXPLUS_CYLINDER_METER_LEVEL_COUNT_SELECT_ID = "GASMAXPLUS.CylinderMeterLevelCount.Select";
	
	/**
	 * CylinderLevelCount 인스턴스
	 */
	private static BizCylinderMeterLevelCount bizCylinderMeterLevelCount;
	
	/**
	 * 디폴트 생성자
	 */
	public BizCylinderMeterLevelCount(){
	}
	
	/**
	 * Singleton으로 CylindereLevelCount 인스턴스 생성
	 * @return bizCylindereLevelCount
	 */
	public static BizCylinderMeterLevelCount getInstance(){
		if (bizCylinderMeterLevelCount == null){
			bizCylinderMeterLevelCount = new BizCylinderMeterLevelCount();
		}
		return bizCylinderMeterLevelCount;
	}
	
	/**
	 * 키워드로 검색한 검침레벨카운트 목록을 반환
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param employeeCode
	 * @param areaTypeCode
	 * @param dayLevel9
	 * @param dayLevel8
	 * @param dayLevel7
	 * @param dayLevel6
	 * @param dayLevel5
	 * @param dayLevel4
	 * @param dayLevel3
	 * @param dayLevel2
	 * @param dayLevel1
	 * @param dayLevel0
	 * @return checkVolumeLevelCounts
	 */
	public CylinderMeterLevelCountMap getCylinderMeterLevelCounts(String serverIp, String catalogName, String clientNumber, String employeeCode, String areaTypeCode, String search, String date){
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("clientNumber", clientNumber);
		String functionName = "FN_Plan_Meter_Value_2020_CNT";
		condition.put("functionName", functionName);
		condition.put("swCode", employeeCode);
		condition.put("cAreaCode", areaTypeCode);
		condition.put("search", search);
		condition.put("date", date);
		
		return selectCylinderMeterLevelCounts(serverIp, catalogName, condition);
	}
	
	/**
	 * 절체기레벨카운트 조회
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param condition 검색 조건
	 * @return CylindereLevelCountMap 형식의 주간수신내역 목록 반환
	 */
	public CylinderMeterLevelCountMap selectCylinderMeterLevelCounts(String serverIp, String catalogName, Map<String, String> condition){
		CylinderMeterLevelCountMap cylinderMeterLevelCounts = new CylinderMeterLevelCountMap();
		condition.put("catalogName", catalogName);
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXPLUS_CYLINDER_METER_LEVEL_COUNT_SELECT_ID, condition);
		for( HashMap<String, String> map :  list) {
			CylinderMeterLevelCount cylinderMeterLevelCount = convertCylinderMeterLevelCount(map);
			cylinderMeterLevelCounts.setCylinderMeterLevelCount(cylinderMeterLevelCount.getKeyValue(), cylinderMeterLevelCount);
		}
		return cylinderMeterLevelCounts;
	}
	/**
	 * HashMap을 CylinderLevelCount으로 변환
	 * @param map
	 * @return CylinderLevelCount
	 */
	protected static CylinderMeterLevelCount convertCylinderMeterLevelCount(HashMap<String, String> map){
		CylinderMeterLevelCount cylinderMeterLevelCount = new CylinderMeterLevelCount();
		
		cylinderMeterLevelCount.setClientNumber(map.get("clientNumber"));
		cylinderMeterLevelCount.setRcvAllCnt(map.get("rcvAllCnt"));
		cylinderMeterLevelCount.setRcvFastCnt(map.get("rcvFastCnt"));
		cylinderMeterLevelCount.setRcvOverCnt(map.get("rcvOverCnt"));
		cylinderMeterLevelCount.setRcvSlowCnt(map.get("rcvSlowCnt"));
		cylinderMeterLevelCount.setRcvEtCnt(map.get("rcvEtCnt"));
		cylinderMeterLevelCount.setRcvNotCnt(map.get("rcvNotCnt"));
		
		return cylinderMeterLevelCount;
	}
	
	protected static HashMap<String, String> convertCylinderMeterLevelCount(CylinderMeterLevelCount cylinderMeterLevelCount){
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", cylinderMeterLevelCount.getClientNumber());
	    map.put("rcvAllCnt", cylinderMeterLevelCount.getRcvAllCnt());
	    map.put("rcvFastCnt", cylinderMeterLevelCount.getRcvFastCnt());
	    map.put("rcvOverCnt", cylinderMeterLevelCount.getRcvOverCnt());
	    map.put("rcvSlowCnt", cylinderMeterLevelCount.getRcvSlowCnt());
	    map.put("rcvEtCnt", cylinderMeterLevelCount.getRcvEtCnt());
	    map.put("rcvNotCnt", cylinderMeterLevelCount.getRcvNotCnt());
		
		return map;
	}
	
	/**
	 * 비즈니스 로직 테스트용
	 * @param args
	 */
	public static void main(String[] args){
//		CylinderLevelCount CylinderLevelCount = CylinderLevelCount.getInstance();
		
//		JSONObject jsonObject = JSONObject.fromObject(new HashMap<String, String>);
		

		
/* SELECT */
//		CylinderLevelCountMap CylinderLevelCounts = CylinderLevelCount.getInstance().getCylinderLevelCounts();		
//		System.out.println(CylinderLevelCounts.toXML());

//		System.out.println(cylinderLevelCounts.toXML());
	}
}
