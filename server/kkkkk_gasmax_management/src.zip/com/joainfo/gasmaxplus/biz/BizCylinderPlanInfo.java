package com.joainfo.gasmaxplus.biz;

import java.util.HashMap;
import java.util.List;

import com.joainfo.common.util.jdbc.JdbcUtil;
import com.joainfo.gasmaxplus.bean.CylinderPlanInfo;

/**
 * BizCylinderPlanInfo
 * 예상공급사용량 비즈니스 로직 처리 객체
 */
public class BizCylinderPlanInfo {

	/**
	 * 예상공급사용량 Select 쿼리의 ID
	 */
	public final String GASMAXPLUS_CYLINDER_PLAN_INFO_SELECT_ID = "GASMAXPLUS.CylinderPlanInfo.Select";
	
	/**
	 * 예상공급사용량 Update 쿼리의 ID
	 */
	public final String GASMAXPLUS_CYLINDER_PLAN_INFO_UPDATE_ID = "GASMAXPLUS.CylinderPlanInfoGPS.Update";

	/**
	 * BizCylinderPlanInfo 인스턴스
	 */
	private static BizCylinderPlanInfo bizCylinderPlanInfo;
	
	/**
	 * 디폴트 생성자
	 */
	public BizCylinderPlanInfo(){
	}
	
	/**
	 * Singleton으로 BizCylinderPlanInfo 인스턴스 생성
	 * @return bizCylinder
	 */
	public static BizCylinderPlanInfo getInstance(){
		if (bizCylinderPlanInfo == null){
			bizCylinderPlanInfo = new BizCylinderPlanInfo();
		}
		return bizCylinderPlanInfo;
	}
	
	/**
	 * 예상공급사용량 조회
	 */
	public CylinderPlanInfo getCylinderPlanInfo(String serverIp, String catalogName, String clientNumber, String customerCode, String customerDiv, String transmCd, String date ){
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("clientNumber", clientNumber);
		String functionName = "FN_Plan_Meter_Select_2020";
		condition.put("functionName", functionName);
		condition.put("customerCode", customerCode);
		condition.put("customerDiv", customerDiv);
		condition.put("transmCd", transmCd);
		condition.put("date", date);

		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXPLUS_CYLINDER_PLAN_INFO_SELECT_ID, condition);
		
		CylinderPlanInfo cylinderPlanInfo = new CylinderPlanInfo();
		for( HashMap<String, String> map :  list) {
			cylinderPlanInfo = convertCylinderPlanInfo(map);
		}
		
		return cylinderPlanInfo;
	}
	
	/**
	 * HashMap을 WeeklyList으로 변환
	 * @param map
	 * @return WeeklyList
	 */
	protected static CylinderPlanInfo convertCylinderPlanInfo(HashMap<String, String> map){
		CylinderPlanInfo cylinderPlanInfo = new CylinderPlanInfo();
		
		cylinderPlanInfo.setClientNumber(map.get("clientNumber"));
		cylinderPlanInfo.setCustomerCode(map.get("customerCode"));
		cylinderPlanInfo.setCustomerMCode(map.get("customerMCode"));
		cylinderPlanInfo.setCustomerJCode(map.get("customerJCode"));
		cylinderPlanInfo.setTransmCd(map.get("transmCd"));
		cylinderPlanInfo.setcVol(map.get("cVol"));
		cylinderPlanInfo.setcQty(map.get("cQty"));
		cylinderPlanInfo.setMeterQty(map.get("meterQty"));
		cylinderPlanInfo.setrCountDt(map.get("rCountDt"));
		cylinderPlanInfo.setrCountSum(map.get("rCountSum"));
		cylinderPlanInfo.setSetCount(map.get("setCount"));
		cylinderPlanInfo.setGetType(map.get("getType"));
		
		return cylinderPlanInfo;
	}
	
	/**
	 * 예상공급사용량 등록/수정/삭제
	 */
	public int setCylinderPlanInfo(String serverIp, String catalogName, String clientNumber, String customerCode, String transmCd
			, String setDate, String saveDiv, String custJCode, String custMCode, String jmDiv
			, String cVol, String cQty, String meterQty, String rCountDt, String rCountSum
			, String setCount, String appUserMobileNumber, String gpsX, String gpsY){
		HashMap<String, String> condition = new HashMap<String, String>();
		
		
		System.out.println("gpsX:" + gpsX + "," + "gpsY:" + gpsY);
		
		condition.put("clientNumber", clientNumber);
		condition.put("customerCode", customerCode);
		condition.put("transmCd", transmCd);
		
		condition.put("setDate", setDate);
		condition.put("saveDiv", saveDiv);
		condition.put("custJCode", custJCode);
		condition.put("custMCode", custMCode);
		condition.put("jmDiv", jmDiv);
		
		condition.put("cVol", cVol);
		condition.put("cQty", cQty);
		condition.put("meterQty", meterQty);
		condition.put("rCountDt", rCountDt);
		condition.put("rCountSum", rCountSum);
		
		condition.put("setCount", setCount);

		condition.put("gpsX", gpsX);
		condition.put("gpsY", gpsY);

		condition.put("appUser", appUserMobileNumber);

		
		
		return updateCustomerDetailInfo(serverIp, catalogName, condition);
	}

	/**
	 * @param condition
	 * @return
	 */
	protected int updateCustomerDetailInfo(String serverIp, String catalogName, HashMap<String, String> condition){
		return JdbcUtil.getInstance(serverIp).updateQuery(GASMAXPLUS_CYLINDER_PLAN_INFO_UPDATE_ID, condition);
	}
	
	/**
	 * 비즈니스 로직 테스트용
	 * @param args
	 */
	public static void main(String[] args){
//		BizCylinder bizCylinder = BizCylinder.getInstance();
		
//		JSONObject jsonObject = JSONObject.fromObject(new HashMap<String, String>);
		

		
/* SELECT */
//		CylinderMap cylinders = BizCylinder.getInstance().getCylinders();		
//		System.out.println(cylinders.toXML());

/* INSERT OR UPDATE*/
//		Cylinder cylinder = new Cylinder();
//		cylinder.setCylinderCode("TEST1");
//		cylinder.setCylinderName("TEST Cylinder1");
//		cylinder.setUseYesNo("Y");
//		BizCylinder.getInstance().applyCylinder(cylinder);
		
/* DELETE */
//		BizCylinder.getInstance().deleteCylinder("TEST");
		
/* DELETE LIST */
//		List<String> list = new java.util.ArrayList<String>();
//		list.add("TEST1");
//		list.add("TEST2");
//		BizCylinder.getInstance().deleteCylinders(list);

/* SELECT */
//		BizCylinder.getInstance().initCacheCylinders();
//		System.out.println(cacheCylinders.toXML());
//		

//		System.out.println(cacheCylinders.toXML());
	}
}
