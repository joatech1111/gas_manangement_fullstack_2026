package com.joainfo.gasmaxplus.biz;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.joainfo.common.util.jdbc.JdbcUtil;
import com.joainfo.gasmaxplus.bean.CheckVolumeDetailList;
import com.joainfo.gasmaxplus.bean.list.CheckVolumeDetailListMap;

/**
 * BizCheckVolumeDetailList
 * 체적검침상세내역 비즈니스 로직 처리 객체
 * @author 백원태
 * @version 1.0
 */
public class BizCheckVolumeDetailList {

	/**
	 * 체적검침상세내역 Select 쿼리의 ID
	 */
	public final String GASMAXPLUS_CHECK_VOLUME_DETAIL_LIST_SELECT_ID = "GASMAXPLUS.CheckVolumeDetailList.Select";
	
	public final String GASMAXPLUS_CHECK_VOLUME_DETAIL_LIST_DATE_SELECT_ID = "GASMAXPLUS.CheckVolumeDetailListDate.Select";
	
	/**
	 * BizCheckVolumeDetailList 인스턴스
	 */
	private static BizCheckVolumeDetailList bizCheckVolumeDetailList;
	
	/**
	 * 디폴트 생성자
	 */
	public BizCheckVolumeDetailList(){
	}
	
	/**
	 * Singleton으로 BizCheckVolumeDetailList 인스턴스 생성
	 * @return bizCheckVolumeDetailList
	 */
	public static BizCheckVolumeDetailList getInstance(){
		if (bizCheckVolumeDetailList == null){
			bizCheckVolumeDetailList = new BizCheckVolumeDetailList();
		}
		return bizCheckVolumeDetailList;
	}
	
	/**
	 * 키워드로 검색한 체적검침상세내역 목록을 반환
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param clientNumber
	 * @param customerCode
	 * @param startDate
	 * @param endDate
	 * @return checkVolumeDetailLists
	 */
	public CheckVolumeDetailListMap getCheckVolumeDetailLists(String serverIp, String catalogName, String clientNumber, String customerCode, String startDate, String endDate, String gubun){
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("clientNumber", clientNumber);
		condition.put("customerCode", customerCode);
		condition.put("startDate", startDate);
		condition.put("endDate", endDate);
		
		return selectCheckVolumeDetailLists(serverIp, catalogName, condition, gubun);
		
	}
	
	/**
	 * 체적검침상세내역 조회
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param condition 검색 조건
	 * @return CheckVolumeDetailListMap 형식의 체적검침상세내역 목록 반환
	 */
	public CheckVolumeDetailListMap selectCheckVolumeDetailLists(String serverIp, String catalogName, Map<String, String> condition, String gubun){
		CheckVolumeDetailListMap checkVolumeDetailLists = new CheckVolumeDetailListMap();
		condition.put("catalogName", catalogName);
		
		if("DETAIL".equals(gubun)) {

			@SuppressWarnings("rawtypes")
			List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXPLUS_CHECK_VOLUME_DETAIL_LIST_SELECT_ID, condition);
			for( HashMap<String, String> map :  list) {
				CheckVolumeDetailList checkVolumeDetailList = convertCheckVolumeDetailList(map);
				checkVolumeDetailLists.setCheckVolumeDetailList(checkVolumeDetailList.getKeyValue(), checkVolumeDetailList);
			}
			
		}else {

			@SuppressWarnings("rawtypes")
			List<HashMap> list1 = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXPLUS_CHECK_VOLUME_DETAIL_LIST_DATE_SELECT_ID, condition);
			for( HashMap<String, String> map :  list1) {
				CheckVolumeDetailList checkVolumeDetailList = convertCheckVolumeDetailList(map);
				checkVolumeDetailLists.setCheckVolumeDetailList(checkVolumeDetailList.getKeyValue(), checkVolumeDetailList);
			}
			
		}

		return checkVolumeDetailLists;
	}
	/**
	 * HashMap을 CheckVolumeDetailList으로 변환
	 * @param map
	 * @return CheckVolumeDetailList
	 */
	protected static CheckVolumeDetailList convertCheckVolumeDetailList(HashMap<String, String> map){
		CheckVolumeDetailList checkVolumeDetailList = new CheckVolumeDetailList();
		
		checkVolumeDetailList.setClientNumber(map.get("clientNumber"));
		checkVolumeDetailList.setCustomerCode(map.get("customerCode"));
		checkVolumeDetailList.setTransmitterCode(map.get("transmitterCode"));
		checkVolumeDetailList.setReceiveDate(map.get("receiveDate"));
		checkVolumeDetailList.setReceiveTime(map.get("receiveTime"));
		checkVolumeDetailList.setLevel(map.get("level"));
		checkVolumeDetailList.setEventCode(map.get("eventCode"));
		checkVolumeDetailList.setEventName(map.get("eventName"));
		checkVolumeDetailList.setBatteryVolt(map.get("batteryVolt"));
		
		return checkVolumeDetailList;
	}
	
	protected static HashMap<String, String> convertCheckVolumeDetailList(CheckVolumeDetailList checkVolumeDetailList){
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", checkVolumeDetailList.getClientNumber());
	    map.put("customerCode", checkVolumeDetailList.getCustomerCode());
	    map.put("transmitterCode", checkVolumeDetailList.getTransmitterCode());
	    map.put("receiveDate", checkVolumeDetailList.getReceiveDate());
	    map.put("receiveTime", checkVolumeDetailList.getReceiveTime());
	    map.put("level", checkVolumeDetailList.getLevel());
	    map.put("eventCode", checkVolumeDetailList.getEventCode());
	    map.put("eventName", checkVolumeDetailList.getEventName());
	    map.put("batteryVolt", checkVolumeDetailList.getBatteryVolt());
		
		return map;
	}
	
	/**
	 * 비즈니스 로직 테스트용
	 * @param args
	 */
	public static void main(String[] args){
//		BizCheckVolumeDetailList bizCheckVolumeDetailList = BizCheckVolumeDetailList.getInstance();
		
//		JSONObject jsonObject = JSONObject.fromObject(new HashMap<String, String>);
		

		
/* SELECT */
//		CheckVolumeDetailListMap checkVolumeDetailLists = BizCheckVolumeDetailList.getInstance().getCheckVolumeDetailLists();		
//		System.out.println(checkVolumeDetailLists.toXML());

/* INSERT OR UPDATE*/
//		CheckVolumeDetailList checkVolumeDetailList = new CheckVolumeDetailList();
//		checkVolumeDetailList.setCheckVolumeDetailListCode("TEST1");
//		checkVolumeDetailList.setCheckVolumeDetailListName("TEST CheckVolumeDetailList1");
//		checkVolumeDetailList.setUseYesNo("Y");
//		BizCheckVolumeDetailList.getInstance().applyCheckVolumeDetailList(checkVolumeDetailList);
		
/* DELETE */
//		BizCheckVolumeDetailList.getInstance().deleteCheckVolumeDetailList("TEST");
		
/* DELETE LIST */
//		List<String> list = new java.util.ArrayList<String>();
//		list.add("TEST1");
//		list.add("TEST2");
//		BizCheckVolumeDetailList.getInstance().deleteCheckVolumeDetailLists(list);

/* SELECT */
//		BizCheckVolumeDetailList.getInstance().initCacheCheckVolumeDetailLists();
//		System.out.println(cacheCheckVolumeDetailLists.toXML());
//		

//		System.out.println(cacheCheckVolumeDetailLists.toXML());
	}
}
