package com.joainfo.gasmaxplus.biz;

import java.util.HashMap;
import java.util.List;

import com.joainfo.common.util.jdbc.JdbcUtil;
import com.joainfo.gasmaxplus.bean.AppUser;
import com.joainfo.gasmaxplus.bean.list.AppUserMap;

/**
 * BizAppUser
 * 앱 사용자 코드 비즈니스 로직 처리 객체
 * @author 백원태
 * @version 1.0
 */
public class BizAppUser {

	/**
	 * 앱 사용자 코드 Select 쿼리의 ID
	 */
	public final String GASMAXPLUS_APP_USER_SELECT_ID = "GASMAXPLUS.AppUser.Select";

	/**
	 * 앱 다중 사용자 코드 Select 쿼리의 ID
	 */
	public final String GASMAXPLUS_MULTI_APP_USER_SELECT_ID = "GASMAXPLUS.MultiAppUser.Select";
	public final String GASMAXPLUS_NEW_APP_USER_SELECT_ID = "GASMAXPLUS.NewAppUser.Select";
	
	
	/**
	 * 앱 사용자 코드 Update 쿼리의 ID
	 */
	public final String GASMAXPLUS_APP_USER_UPDATE_LATEST_LOGIN_DATE_ID = "GASMAXPLUS.AppUser.UpdateLatestLoginDate";
	
	/**
	 * 앱 사용자 코드 Update 쿼리의 ID
	 */
	public final String GASMAXPLUS_APP_USER_UPDATE_ID = "GASMAXPLUS.AppUser.Update";
	
	/**
	 * 앱 사용자 코드 Insert 쿼리의 ID
	 */
	public final String GASMAXPLUS_APP_USER_INSERT_ID = "GASMAXPLUS.AppUser.Insert";

	/**
	 * BizAppUser 인스턴스
	 */
	private static BizAppUser bizAppUser;
	
	/**
	 * 앱 사용자 디폴트 DB 카탈로그 명
	 */
	public final static String DEFAULT_APP_USER_CATATLOG_NAME = "GasMax_App";
	
	/**
	 * 디폴트 생성자
	 */
	public BizAppUser(){
	}
	
	/**
	 * Singleton으로 BizAppUser 인스턴스 생성
	 * @return bizAppUser
	 */
	public static BizAppUser getInstance(){
		if (bizAppUser == null){
			bizAppUser = new BizAppUser();
		}
		return bizAppUser;
	}
	
	/**
	 * 앱 사용자 코드 반환
	 * @param catalogName
	 * @param key
	 * @return appUser
	 */
	public AppUser getAppUser(String catalogName, String areaSeq, String key){
		AppUserMap appUsers = getAppUsers(catalogName, areaSeq);
		return appUsers==null?null:appUsers.getAppUser(key);
	}
	
	/**
	 * 캐시로부터 앱 사용자 코드 목록을 반환
	 * @param catalogName
	 * @return appUsers
	 */
	public AppUserMap getAppUsers(String catalogName, String areaSeq){
		return selectAppUsers(catalogName, areaSeq);
	}

	/**
	 * 앱 다중 사용자 코드 반환
	 * @param catalogName
	 * @param key
	 * @return appUser
	 */
	public AppUser getMultiAppUser(String catalogName, String macNumber, String key){
		AppUserMap appUsers = getMultiAppUsers(catalogName, macNumber);
		return appUsers==null?null:appUsers.getAppUser(key);
	}
	
	/**
	 * 캐시로부터 앱 다중 사용자 코드 목록을 반환
	 * @param catalogName
	 * @return appUsers
	 */
	public AppUserMap getMultiAppUsers(String catalogName, String macNumber){
		return selectMultiAppUsers(catalogName, macNumber);
	}

	public AppUserMap getInsertAppUsers(String catalogName, String macNumber, String chk){
		return selectNewKeyAppUsers(catalogName, macNumber, chk);
	}
	
	/**
	 * 사용자 정보 수정
	 * @param macNumber
	 * @param areaSeq
	 * @param areaCode
	 * @param areaName
	 * @param userId
	 * @param password
	 * @param employeeCode
	 * @param employeeName
	 * @param areaTypeCode
	 * @param areaTypeName
	 * @param weeklyListSearchType
	 * @param sortCode
	 * @return
	 */
	public int setAppUser(String macNumber, String areaSeq, String areaCode, String areaName, String userId, String password, String employeeCode, String employeeName, String areaTypeCode, String areaTypeName, String weeklyListSearchType, String sortCode, String locMeter){
		return setAppUser(macNumber, areaSeq, areaCode, areaName, userId, password, employeeCode, employeeName, areaTypeCode, areaTypeName, weeklyListSearchType, sortCode, "N", locMeter);
	}

	
	/**
	 * 사용자 정보 수정
	 * @param macNumber
	 * @param areaSeq
	 * @param areaCode
	 * @param areaName
	 * @param userId
	 * @param password
	 * @param employeeCode
	 * @param employeeName
	 * @param areaTypeCode
	 * @param areaTypeName
	 * @param weeklyListSearchType
	 * @param sortCode
	 * @return
	 */
	public int setAppUser(String macNumber, String areaSeq, String areaCode, String areaName, String userId, String password, String employeeCode, String employeeName, String areaTypeCode, String areaTypeName, String weeklyListSearchType, String sortCode, String alarmGasLeakYN, String locMeter){
		HashMap<String, String> condition = new HashMap<String, String>();
		
		condition.put("macNumber", macNumber);
		condition.put("areaSeq", areaSeq);
		condition.put("areaCode", areaCode);
		condition.put("areaName", areaName);
		condition.put("userId", userId);
		condition.put("password", password);
		condition.put("employeeCode", employeeCode);
		condition.put("employeeName", employeeName);
		condition.put("areaTypeCode", areaTypeCode);
		condition.put("areaTypeName", areaTypeName);
		condition.put("weeklyListSearchType", weeklyListSearchType);
		condition.put("sortCode", sortCode);
		condition.put("alarmGasLeakYN", alarmGasLeakYN);		
		condition.put("locMeter", locMeter);

		return updateAppUser(condition);
	}
	
	/**
	 * @param macNumber
	 * @return
	 */
	public int setLatestLoginDate(String macNumber, String areaSeq, String appVersion){
		HashMap<String, String> condition = new HashMap<String, String>();
		
		condition.put("macNumber", macNumber);
		condition.put("areaSeq", areaSeq);
		condition.put("appVersion", appVersion);

		return updateLatestLoginDate(condition);
	}
	
	/**
	 * 앱 사용자 코드 조회
	 * @param catalogName
	 * @return AppUserMap 형식의 앱 사용자 코드 목록 반환
	 */
	protected AppUserMap selectAppUsers(String catalogName, String areaSeq){
		AppUserMap appUsers = new AppUserMap();
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		condition.put("areaSeq", areaSeq);
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(JdbcUtil.DEFAULT_SQL_CONFIG).selectQuery(GASMAXPLUS_APP_USER_SELECT_ID, condition);
		for( HashMap<String, String> map :  list) {
			AppUser appUser = convertAppUser(map);
			appUsers.setAppUser(appUser.getKeyValue(), appUser);
		}
		return appUsers;
	}

	/**
	 * 앱 다중 사용자 코드 조회
	 * @param catalogName
	 * @return AppUserMap 형식의 앱 사용자 코드 목록 반환
	 */
	protected AppUserMap selectMultiAppUsers(String catalogName, String macNumber){
		AppUserMap appUsers = new AppUserMap();
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		condition.put("macNumber", macNumber);
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(JdbcUtil.DEFAULT_SQL_CONFIG).selectQuery(GASMAXPLUS_MULTI_APP_USER_SELECT_ID, condition);
		for( HashMap<String, String> map :  list) {
			AppUser appUser = convertAppUser(map);
			appUsers.setAppUser(appUser.getMultiKeyValue(), appUser);
		}
		
		return appUsers;
	}

	
	/**
	 * 앱 다중 사용자 코드 조회
	 * @param catalogName
	 * @return AppUserMap 형식의 앱 사용자 코드 목록 반환
	 */
	protected AppUserMap selectNewKeyAppUsers(String catalogName, String macNumber, String chkTelphone){
		AppUserMap appUsers = new AppUserMap();
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("catalogName", catalogName);
		condition.put("macNumber", macNumber);
		condition.put("chkTelphone", chkTelphone);
		
		//JdbcUtil.getInstance(JdbcUtil.DEFAULT_SQL_CONFIG).executeProcedure(GASMAXPLUS_NEW_APP_USER_SELECT_ID, condition);
		
		@SuppressWarnings("rawtypes")
		List<HashMap> list = JdbcUtil.getInstance(JdbcUtil.DEFAULT_SQL_CONFIG).selectQuery(GASMAXPLUS_MULTI_APP_USER_SELECT_ID, condition);
		for( HashMap<String, String> map :  list) {
			AppUser appUser = convertAppUser(map);
			appUsers.setAppUser(appUser.getMultiKeyValue(), appUser);
		}
		
		return appUsers;
	}
	
	
	
	/**
	 * @param macNumber
	 * @param mobileNumber
	 * @param areaName
	 * @param userId
	 * @param password
	 * @return
	 */
	public int appendAppUser(String macNumber, String mobileNumber, String areaName, String userId, String password){
		HashMap<String, String> condition = new HashMap<String, String>();
		
		condition.put("macNumber", macNumber);
		condition.put("mobileNumber", mobileNumber);
		condition.put("areaName", areaName);
		condition.put("userId", userId);
		condition.put("password", password);

		return insertAppUser(condition);
	}
	
	/**
	 * @param condition
	 * @return
	 */
	protected int updateLatestLoginDate(HashMap<String, String> condition){
		return JdbcUtil.getInstance(JdbcUtil.DEFAULT_SQL_CONFIG).updateQuery(GASMAXPLUS_APP_USER_UPDATE_LATEST_LOGIN_DATE_ID, condition);
	}

	/**
	 * @param condition
	 * @return
	 */
	protected int updateAppUser(HashMap<String, String> condition){
			return JdbcUtil.getInstance(JdbcUtil.DEFAULT_SQL_CONFIG).updateQuery(GASMAXPLUS_APP_USER_UPDATE_ID, condition);
	}
	
	/**
	 * @param condition
	 * @return
	 */
	protected int insertAppUser(HashMap<String, String> condition){
		return JdbcUtil.getInstance(JdbcUtil.DEFAULT_SQL_CONFIG).executeProcedure(GASMAXPLUS_APP_USER_INSERT_ID, condition);
	}
	
	/**
	 * HashMap을 AppUser으로 변환
	 * @param map
	 * @return AppUser
	 */
	protected static AppUser convertAppUser(HashMap<String, String> map){
		AppUser appUser = new AppUser();
		
		appUser.setMacNumber(map.get("macNumber"));
		appUser.setAreaSeq(map.get("areaSeq"));
		appUser.setGrantState(map.get("grantState"));
		appUser.setPhoneModel(map.get("phoneModel"));
		appUser.setMobileNumber(map.get("mobileNumber"));
		appUser.setIpAddress(map.get("ipAddress"));
		appUser.setDbCatalogName(map.get("dbCatalogName"));
		appUser.setDbUserID(map.get("dbUserID"));
		appUser.setDbPassword(map.get("dbPassword"));
		appUser.setPort(map.get("port"));
		appUser.setAreaCode(map.get("areaCode"));
		appUser.setAreaName(map.get("areaName"));
		appUser.setUserId(map.get("userId"));
		appUser.setPassword(map.get("password"));
		appUser.setEmployeeCode(map.get("employeeCode"));
		appUser.setEmployeeName(map.get("employeeName"));
		appUser.setAreaTypeCode(map.get("areaTypeCode"));
		appUser.setAreaTypeName(map.get("areaTypeName"));
		appUser.setLicenseDate(map.get("licenseDate"));
		appUser.setJoinDate(map.get("joinDate"));
		appUser.setLastLoginDate(map.get("lastLoginDate"));
		appUser.setExpiryDate(map.get("expiryDate"));
		appUser.setMenuPermission(map.get("menuPermission"));
		appUser.setRemark(map.get("remark"));
		appUser.setWeeklyListSearchType(map.get("weeklyListSearchType"));
		appUser.setSortCode(map.get("sortCode"));
		appUser.setAlarmGasLeakYN(map.get("alarmGasLeakYN"));
		appUser.setLocMeter(map.get("locMeter"));
		
		return appUser;
	}
	
	protected static HashMap<String, String> convertAppUser(AppUser appUser){
		HashMap<String, String> map = new HashMap<String, String>();
		
		map.put("macNumber", appUser.getMacNumber());
		map.put("areaSeq", appUser.getAreaSeq());
		map.put("grantState", appUser.getGrantState());
		map.put("phoneModel", appUser.getPhoneModel());
		map.put("mobileNumber", appUser.getMobileNumber());
		map.put("ipAddress", appUser.getIpAddress());
		map.put("dbCatalogName", appUser.getDbCatalogName());
		map.put("dbUserID", appUser.getDbUserID());
		map.put("dbPassword", appUser.getDbPassword());
		map.put("port", appUser.getPort());
		map.put("areaCode", appUser.getAreaCode());
		map.put("areaName", appUser.getAreaName());
		map.put("userId", appUser.getUserId());
		map.put("password", appUser.getPassword());
		map.put("employeeCode", appUser.getEmployeeCode());
		map.put("employeeName", appUser.getEmployeeName());
		map.put("areaTypeCode", appUser.getAreaTypeCode());
		map.put("areaTypeName", appUser.getAreaTypeName());
		map.put("licenseDate", appUser.getLicenseDate());
		map.put("joinDate", appUser.getJoinDate());
		map.put("lastLoginDate", appUser.getLastLoginDate());
		map.put("expiryDate", appUser.getExpiryDate());
		map.put("menuPermission", appUser.getMenuPermission());
		map.put("remark", appUser.getRemark());
		map.put("weeklyListSearchType", appUser.getWeeklyListSearchType());
		map.put("sortCode", appUser.getSortCode());
		map.put("alarmGasLeakYN", appUser.getAlarmGasLeakYN());
		map.put("locMeter", appUser.getLocMeter());
		return map;
	}
	
	/**
	 * 비즈니스 로직 테스트용
	 * @param args
	 */
	public static void main(String[] args){
		BizAppUser bizAppUser = BizAppUser.getInstance();
		System.out.println(bizAppUser.getAppUsers("GasMax_App", "0").toXML());
		
//		JSONObject jsonObject = JSONObject.fromObject(new HashMap<String, String>);
		

		
/* SELECT */
//		AppUserMap appUsers = BizAppUser.getInstance().getAppUsers();		
//		System.out.println(appUsers.toXML());

/* INSERT OR UPDATE*/
//		AppUser appUser = new AppUser();
//		appUser.setAppUserCode("TEST1");
//		appUser.setAppUserName("TEST AppUser1");
//		appUser.setUseYesNo("Y");
//		BizAppUser.getInstance().applyAppUser(appUser);
		
/* DELETE */
//		BizAppUser.getInstance().deleteAppUser("TEST");
		
/* DELETE LIST */
//		List<String> list = new java.util.ArrayList<String>();
//		list.add("TEST1");
//		list.add("TEST2");
//		BizAppUser.getInstance().deleteAppUsers(list);

/* SELECT */
//		BizAppUser.getInstance().initCacheAppUsers();
//		System.out.println(cacheAppUsers.toXML());
//		

//		System.out.println(cacheAppUsers.toXML());
	}
}
