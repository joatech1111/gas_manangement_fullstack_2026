package com.joainfo.gasmaxplus.biz;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.joainfo.common.util.jdbc.JdbcUtil;
import com.joainfo.gasmaxplus.bean.CylinderDetailList;
import com.joainfo.gasmaxplus.bean.list.CylinderDetailListMap;

/**
 * BizCylinderDetailList
 * 절체기상세내역 비즈니스 로직 처리 객체
 * @author 백원태
 * @version 1.0
 */
public class BizCylinderDetailList {

	/**
	 * 절체기상세내역 Select 쿼리의 ID
	 */
	public final String GASMAXPLUS_CYLINDER_DETAIL_LIST_SELECT_ID = "GASMAXPLUS.CylinderDetailList.Select";

	public final String GASMAXPLUS_CYLINDER_DETAIL_LIST_DATE_SELECT_ID = "GASMAXPLUS.CylinderDetailListDate.Select";
	
	/**
	 * BizCylinderDetailList 인스턴스
	 */
	private static BizCylinderDetailList bizCylinderDetailList;
	
	/**
	 * 디폴트 생성자
	 */
	public BizCylinderDetailList(){
	}
	
	/**
	 * Singleton으로 BizCylinderDetailList 인스턴스 생성
	 * @return bizCylinderDetailList
	 */
	public static BizCylinderDetailList getInstance(){
		if (bizCylinderDetailList == null){
			bizCylinderDetailList = new BizCylinderDetailList();
		}
		return bizCylinderDetailList;
	}
	
	/**
	 * 키워드로 검색한 절체기상세내역 목록을 반환
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param clientNumber
	 * @param customerCode
	 * @param startDate
	 * @param endDate
	 * @return cylinderDetailLists
	 */
	public CylinderDetailListMap getCylinderDetailLists(String serverIp, String catalogName, String clientNumber, String customerCode, String startDate, String endDate, String gubun){
		HashMap<String, String> condition = new HashMap<String, String>();
		condition.put("clientNumber", clientNumber);
		condition.put("customerCode", customerCode);
		condition.put("startDate", startDate);
		condition.put("endDate", endDate);
		
		return selectCylinderDetailLists(serverIp, catalogName, condition, gubun);
	}
	
	/**
	 * 절체기상세내역 조회
	 * @param serverIp 서버 아이피 또는 도메인이름. 동일한 이름으로 DB 설정 파일이 존재해야 한다.
	 * @param catalogName DB 카탈로그 명
	 * @param condition 검색 조건
	 * @return CylinderDetailListMap 형식의 절체기상세내역 목록 반환
	 */
	public CylinderDetailListMap selectCylinderDetailLists(String serverIp, String catalogName, Map<String, String> condition, String gubun){
		CylinderDetailListMap cylinderDetailLists = new CylinderDetailListMap();
		condition.put("catalogName", catalogName);
		
		if("DETAIL".equals(gubun)) {
			@SuppressWarnings("rawtypes")
			List<HashMap> list = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXPLUS_CYLINDER_DETAIL_LIST_SELECT_ID, condition);
			for( HashMap<String, String> map :  list) {
				CylinderDetailList cylinderDetailList = convertCylinderDetailList(map);
				cylinderDetailLists.setCylinderDetailList(cylinderDetailList.getKeyValue(), cylinderDetailList);
			}
		}else {
			@SuppressWarnings("rawtypes")
			List<HashMap> list1 = JdbcUtil.getInstance(serverIp).selectQuery(GASMAXPLUS_CYLINDER_DETAIL_LIST_DATE_SELECT_ID, condition);
			for( HashMap<String, String> map :  list1) {
				CylinderDetailList cylinderDetailList = convertCylinderDetailList(map);
				cylinderDetailLists.setCylinderDetailList(cylinderDetailList.getKeyValue(), cylinderDetailList);
			}
			
		}
		
		return cylinderDetailLists;
	}
	/**
	 * HashMap을 CylinderDetailList으로 변환
	 * @param map
	 * @return CylinderDetailList
	 */
	protected static CylinderDetailList convertCylinderDetailList(HashMap<String, String> map){
		CylinderDetailList cylinderDetailList = new CylinderDetailList();
		
		cylinderDetailList.setClientNumber(map.get("clientNumber"));
		cylinderDetailList.setCustomerCode(map.get("customerCode"));
		cylinderDetailList.setTransmitterCode(map.get("transmitterCode"));
		cylinderDetailList.setReceiveDate(map.get("receiveDate"));
		cylinderDetailList.setReceiveTime(map.get("receiveTime"));
		cylinderDetailList.setLevel(map.get("level"));
		cylinderDetailList.setEventCode(map.get("eventCode"));
		cylinderDetailList.setEventName(map.get("eventName"));
		cylinderDetailList.setBatteryVolt(map.get("batteryVolt"));
		
		return cylinderDetailList;
	}
	
	protected static HashMap<String, String> convertCylinderDetailList(CylinderDetailList cylinderDetailList){
		HashMap<String, String> map = new HashMap<String, String>();
		
	    map.put("clientNumber", cylinderDetailList.getClientNumber());
	    map.put("customerCode", cylinderDetailList.getCustomerCode());
	    map.put("transmitterCode", cylinderDetailList.getTransmitterCode());
	    map.put("receiveDate", cylinderDetailList.getReceiveDate());
	    map.put("receiveTime", cylinderDetailList.getReceiveTime());
	    map.put("level", cylinderDetailList.getLevel());
	    map.put("eventCode", cylinderDetailList.getEventCode());
	    map.put("eventName", cylinderDetailList.getEventName());
	    map.put("batteryVolt", cylinderDetailList.getBatteryVolt());
		
		return map;
	}
	
	/**
	 * 비즈니스 로직 테스트용
	 * @param args
	 */
	public static void main(String[] args){
//		BizCylinderDetailList bizCylinderDetailList = BizCylinderDetailList.getInstance();
		
//		JSONObject jsonObject = JSONObject.fromObject(new HashMap<String, String>);
		

		
/* SELECT */
//		CylinderDetailListMap cylinderDetailLists = BizCylinderDetailList.getInstance().getCylinderDetailLists();		
//		System.out.println(cylinderDetailLists.toXML());

/* INSERT OR UPDATE*/
//		CylinderDetailList cylinderDetailList = new CylinderDetailList();
//		cylinderDetailList.setCylinderDetailListCode("TEST1");
//		cylinderDetailList.setCylinderDetailListName("TEST CylinderDetailList1");
//		cylinderDetailList.setUseYesNo("Y");
//		BizCylinderDetailList.getInstance().applyCylinderDetailList(cylinderDetailList);
		
/* DELETE */
//		BizCylinderDetailList.getInstance().deleteCylinderDetailList("TEST");
		
/* DELETE LIST */
//		List<String> list = new java.util.ArrayList<String>();
//		list.add("TEST1");
//		list.add("TEST2");
//		BizCylinderDetailList.getInstance().deleteCylinderDetailLists(list);

/* SELECT */
//		BizCylinderDetailList.getInstance().initCacheCylinderDetailLists();
//		System.out.println(cacheCylinderDetailLists.toXML());
//		

//		System.out.println(cacheCylinderDetailLists.toXML());
	}
}
