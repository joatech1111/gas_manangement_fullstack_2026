package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 주간수신 집계정보 모델
 * @author 네오브랜딩
 * @version 1.0
 */
public class CylinderMeterLevelCount {
	/**
	 * CMNGNO	
	 * 고객번호 - key
	 */
	 private String clientNumber;

	 /**
	 * RCV_ALL_CNT	
	 * 합계
	 */
	 private String rcvAllCnt;

	 /**
	 * RCV_FAST_CNT
	 * 긴급
	 */
	 private String rcvFastCnt;
	 
	/**
	 * RCV_OVER_CNT
	 * 경보
	 */	 
	 private String rcvOverCnt;
	 
	 /**
	 * RCV_SLOW_CNT	
	 * 미수신
	 */
	 private String rcvSlowCnt;
	 
	 /**
	  * RCV_ET_CNT	
	  * 기타
	  */
	 private String rcvEtCnt;
	 
	 /**
	 * RCV_NOT_CNT	
	 * 동일레벨
	 */
	 private String rcvNotCnt;
	 
	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap(){
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("C_MNG_NO", getClientNumber());
		
		return keys; 
	}

	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}	
	
	public String getClientNumber() {
		return clientNumber;
	}

	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	public String getRcvAllCnt() {
		return rcvAllCnt;
	}

	public void setRcvAllCnt(String rcvAllCnt) {
		this.rcvAllCnt = rcvAllCnt;
	}

	public String getRcvFastCnt() {
		return rcvFastCnt;
	}

	public void setRcvFastCnt(String rcvFastCnt) {
		this.rcvFastCnt = rcvFastCnt;
	}

	public String getRcvOverCnt() {
		return rcvOverCnt;
	}

	public void setRcvOverCnt(String rcvOverCnt) {
		this.rcvOverCnt = rcvOverCnt;
	}

	public String getRcvSlowCnt() {
		return rcvSlowCnt;
	}

	public void setRcvSlowCnt(String rcvSlowCnt) {
		this.rcvSlowCnt = rcvSlowCnt;
	}
	
	public String getRcvEtCnt() {
		return rcvEtCnt;
	}
	
	public void setRcvEtCnt(String rcvEtCnt) {
		this.rcvEtCnt = rcvEtCnt;
	}

	public String getRcvNotCnt() {
		return rcvNotCnt;
	}

	public void setRcvNotCnt(String rcvNotCnt) {
		this.rcvNotCnt = rcvNotCnt;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CylinderMeterLevelCount [key=" + this.getKeyValue()
				+ ", clientNumber=" + clientNumber
				+ ", rcvAllCnt=" + rcvAllCnt
				+ ", rcvFastCnt=" + rcvFastCnt
				+ ", rcvOverCnt="	+ rcvOverCnt
				+ ", rcvSlowCnt="	+ rcvSlowCnt
				+ ", rcvEtCnt="	+ rcvEtCnt
				+ ", rcvNotCnt=" + rcvNotCnt
				+ "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<CylinderMeterLevelCount><key>" + this.getKeyValue() + "</key><clientNumber>" 
				+ clientNumber + "</clientNumber><rcvAllCnt>"
				+ rcvAllCnt + "</rcvAllCnt><rcvFastCnt>"
				+ rcvFastCnt + "</rcvFastCnt><rcvOverCnt>"
				+ rcvOverCnt + "</rcvOverCnt><rcvSlowCnt>"
				+ rcvSlowCnt + "</rcvSlowCnt><rcvEtCnt>"
				+ rcvEtCnt + "</rcvEtCnt><rcvNotCnt>"
				+ rcvNotCnt + "</rcvNotCnt></CylinderMeterLevelCount>";
	}
	
	/**
	 * JSON 문자열 반환
	 * @return JSON
	 */
	public String toJSON() {
		return "{\"key\":\"" + this.getKeyValue()
				+ "\", \"rcvAllCnt\":\"" + rcvAllCnt
				+ "\", \"rcvFastCnt\":\""	+ rcvFastCnt
				+ "\", \"rcvOverCnt\":\""	+ rcvOverCnt
				+ "\", \"rcvSlowCnt\":\"" + rcvSlowCnt
				+ "\", \"rcvEtCnt\":\"" + rcvEtCnt
				+ "\", \"rcvNotCnt\":\"" + rcvNotCnt
				+ "\"}";
	}		
}
