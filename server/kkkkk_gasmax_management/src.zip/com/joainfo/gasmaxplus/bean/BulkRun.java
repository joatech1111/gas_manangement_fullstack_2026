package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 충전관리 운행 정보 모델
 * @author 서경엔씨에스
 * @version 1.0
 */
public class BulkRun {
	
	private String clientNumber;
	private String carCode;
	private String startRunDate;
	private String startCarMileage;
	private String startCarVolumePer;
	private String startCarVolumeL;
	private String startCarVolumeKg;
	private String startRegDate;
	private String endRunDate;
	private String endCarMileage;
	private String endCarVolumePer;
	private String endCarVolumeL;
	private String endCarVolumeKg;
	private String endRegDate;

	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap() {
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("MNG_NO", getClientNumber());
		keys.put("CAR_CODE", getCarCode());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}

	public String getClientNumber() {
		return clientNumber;
	}

	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	public String getCarCode() {
		return carCode;
	}

	public void setCarCode(String carCode) {
		this.carCode = carCode;
	}

	public String getStartRunDate() {
		return startRunDate;
	}

	public void setStartRunDate(String startRunDate) {
		this.startRunDate = startRunDate;
	}

	public String getStartCarMileage() {
		return startCarMileage;
	}

	public void setStartCarMileage(String startCarMileage) {
		this.startCarMileage = startCarMileage;
	}

	public String getStartCarVolumePer() {
		return startCarVolumePer;
	}

	public void setStartCarVolumePer(String startCarVolumePer) {
		this.startCarVolumePer = startCarVolumePer;
	}

	public String getStartCarVolumeL() {
		return startCarVolumeL;
	}

	public void setStartCarVolumeL(String startCarVolumeL) {
		this.startCarVolumeL = startCarVolumeL;
	}

	public String getStartCarVolumeKg() {
		return startCarVolumeKg;
	}

	public void setStartCarVolumeKg(String startCarVolumeKg) {
		this.startCarVolumeKg = startCarVolumeKg;
	}

	public String getStartRegDate() {
		return startRegDate;
	}

	public void setStartRegDate(String startRegDate) {
		this.startRegDate = startRegDate;
	}

	public String getEndRunDate() {
		return endRunDate;
	}

	public void setEndRunDate(String endRunDate) {
		this.endRunDate = endRunDate;
	}

	public String getEndCarMileage() {
		return endCarMileage;
	}

	public void setEndCarMileage(String endCarMileage) {
		this.endCarMileage = endCarMileage;
	}

	public String getEndCarVolumePer() {
		return endCarVolumePer;
	}

	public void setEndCarVolumePer(String endCarVolumePer) {
		this.endCarVolumePer = endCarVolumePer;
	}

	public String getEndCarVolumeL() {
		return endCarVolumeL;
	}

	public void setEndCarVolumeL(String endCarVolumeL) {
		this.endCarVolumeL = endCarVolumeL;
	}

	public String getEndCarVolumeKg() {
		return endCarVolumeKg;
	}

	public void setEndCarVolumeKg(String endCarVolumeKg) {
		this.endCarVolumeKg = endCarVolumeKg;
	}

	public String getEndRegDate() {
		return endRegDate;
	}

	public void setEndRegDate(String endRegDate) {
		this.endRegDate = endRegDate;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "BulkRun [key=" + this.getKeyValue() 
				+ ", clientNumber=" + clientNumber 
				+ ", carCode=" + carCode 
				+ ", startRunDate=" + startRunDate
				+ ", startCarMileage=" + startCarMileage
				+ ", startCarVolumePer=" + startCarVolumePer
				+ ", startCarVolumeL=" + startCarVolumeL
				+ ", startCarVolumeKg=" + startCarVolumeKg
				+ ", startRegDate=" + startRegDate
				+ ", endRunDate=" + endRunDate
				+ ", endCarMileage=" + endCarMileage
				+ ", endCarVolumePer=" + endCarVolumePer
				+ ", endCarVolumeL=" + endCarVolumeL
				+ ", endCarVolumeKg=" + endCarVolumeKg
				+ ", endRegDate=" + endRegDate + "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<BulkRun><key>" + this.getKeyValue() + "</key><clientNumber>"
				+ clientNumber
				+ "</clientNumber><carCode>"
				+ carCode
				+ "</carCode><startRunDate>"
				+ startRunDate
				+ "</startRunDate><startCarMileage>"
				+ startCarMileage
				+ "</startCarMileage><startCarVolumePer>"
				+ startCarVolumePer
				+ "</startCarVolumePer><startCarVolumeL>"
				+ startCarVolumeL
				+ "</startCarVolumeL><startCarVolumeKg>"
				+ startCarVolumeKg
				+ "</startCarVolumeKg><startRegDate>"
				+ startRegDate
				+ "</startRegDate><endRunDate>"
				+ endRunDate
				+ "</endRunDate><endCarMileage>"
				+ endCarMileage
				+ "</endCarMileage><endCarVolumePer>"
				+ endCarVolumePer
				+ "</endCarVolumePer><endCarVolumeL>"
				+ endCarVolumeL
				+ "</endCarVolumeL><endCarVolumeKg>"
				+ endCarVolumeKg
				+ "</endCarVolumeKg><endRegDate>"
				+ endRegDate
				+ "</endRegDate></BulkRun>";
	}
}
