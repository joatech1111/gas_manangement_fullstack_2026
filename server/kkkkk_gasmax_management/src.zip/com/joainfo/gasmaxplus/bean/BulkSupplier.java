package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 충전관리 매입처 정보 모델
 * @author 서경엔씨에스
 * @version 1.0
 */
public class BulkSupplier {
	
	private String clientNumber;
	private String supplierType;
	private String supplierCode;
	private String supplierName;

	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap() {
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("MNG_NO", getClientNumber());
		keys.put("BU_TYPE", getSupplierType());
		keys.put("BU_CODE", getSupplierCode());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}

	/**
	 * @return the clientNumber
	 */
	public String getClientNumber() {
		return clientNumber;
	}

	/**
	 * @param clientNumber the clientNumber to set
	 */
	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	/**
	 * @return the supplierType
	 */
	public String getSupplierType() {
		return supplierType;
	}

	/**
	 * @param supplierType the supplierType to set
	 */
	public void setSupplierType(String supplierType) {
		this.supplierType = supplierType;
	}

	/**
	 * @return the supplierCode
	 */
	public String getSupplierCode() {
		return supplierCode;
	}

	/**
	 * @param supplierCode the supplierCode to set
	 */
	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}

	/**
	 * @return the supplierName
	 */
	public String getSupplierName() {
		return supplierName;
	}

	/**
	 * @param supplierName the supplierName to set
	 */
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "BulkSupplier [key=" + this.getKeyValue() 
				+ ", clientNumber=" + clientNumber 
				+ ", supplierType=" + supplierType 
				+ ", supplierCode=" + supplierCode
				+ ", supplierName=" + supplierName + "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<BulkSupplier><key>" + this.getKeyValue() + "</key><clientNumber>"
				+ clientNumber
				+ "</clientNumber><supplierType>"
				+ supplierType
				+ "</supplierType><supplierCode>"
				+ supplierCode
				+ "</supplierCode><supplierName><![CDATA["
				+ supplierName
				+ "]]></supplierName></BulkSupplier>";
	}
}
