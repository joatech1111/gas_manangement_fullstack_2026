package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 지역 코드 정보 모델
 * @author 백원태
 * @version 1.0
 */
public class AreaTypeCode {

	/**
	 * C_MNG_NO    
	 * 고객번호
	 */
	 private String clientNumber;

	/**
	 * C_AREA_CODE 
	 * 지역코드
	 */
	 private String areaTypeCode;

	/**
	 * C_AREA_NAME 
	 * 지역명칭
	 */
	 private String areaTypeName;

	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap(){
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("MNG_NO", getClientNumber());
		keys.put("C_AREA_CODE", getAreaTypeCode());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}

	/**
	 * @return the clientNumber
	 */
	public String getClientNumber() {
		return clientNumber;
	}

	/**
	 * @param clientNumber the clientNumber to set
	 */
	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	/**
	 * @return the areaTypeCode
	 */
	public String getAreaTypeCode() {
		return areaTypeCode;
	}

	/**
	 * @param areaTypeCode the areaTypeCode to set
	 */
	public void setAreaTypeCode(String areaTypeCode) {
		this.areaTypeCode = areaTypeCode;
	}

	/**
	 * @return the areaTypeName
	 */
	public String getAreaTypeName() {
		return areaTypeName;
	}

	/**
	 * @param areaTypeName the areaTypeName to set
	 */
	public void setAreaTypeName(String areaTypeName) {
		this.areaTypeName = areaTypeName;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AreaTypeCode [key=" + this.getKeyValue() + ", clientNumber="
				+ clientNumber + ", areaTypeCode=" + areaTypeCode
				+ ", areaTypeName=" + areaTypeName + "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<AreaTypeCode><key>" + this.getKeyValue() + "</key><clientNumber>"
				+ clientNumber
				+ "</clientNumber><areaTypeCode>"
				+ areaTypeCode
				+ "</areaTypeCode><areaTypeName>"
				+ areaTypeName
				+ "</areaTypeName></AreaTypeCode>";
	}
	
	/**
	 * JSON 문자열 반환
	 * @return JSON
	 */
	public String toJSON() {
		return "{\"key\":\"" + this.getKeyValue()
				+ "\", \"clientNumber\":\"" + clientNumber
				+ "\", \"areaTypeCode\":\"" + areaTypeCode
				+ "\", \"areaTypeName\":\"" + areaTypeName
				+ "\"}";
	}

}
