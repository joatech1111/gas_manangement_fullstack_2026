package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 충전관리 매입 정보 모델
 * @author 서경엔씨에스
 * @version 1.0
 */
public class BulkBuy {
	
	private String clientNumber;
	private String carCode;
	private String buyType;
	private String buyDate;
	private String seqNo;
	private String customerCode;
	private String customerName;
	private String employeeCode;
	private String employeeName;
	private String beforeVolumeKg;
	private String chargeVolumeL;
	private String chargeVolumeKg;
	private String afterVolumeKg;
	private String unitPrice;
	private String price;
	private String memo;

	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap() {
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("MNG_NO", getClientNumber());
		keys.put("CAR_CODE", getCarCode());
		keys.put("CAR_DATE", getBuyDate());
		keys.put("BUY_TYPE", getBuyType());
		keys.put("R_SNO", getSeqNo());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}

	public String getClientNumber() {
		return clientNumber;
	}

	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	/**
	 * @return the carCode
	 */
	public String getCarCode() {
		return carCode;
	}

	/**
	 * @param carCode the carCode to set
	 */
	public void setCarCode(String carCode) {
		this.carCode = carCode;
	}

	/**
	 * @return the buyType
	 */
	public String getBuyType() {
		return buyType;
	}

	/**
	 * @param buyType the buyType to set
	 */
	public void setBuyType(String buyType) {
		this.buyType = buyType;
	}

	/**
	 * @return the buyDate
	 */
	public String getBuyDate() {
		return buyDate;
	}

	/**
	 * @param buyDate the buyDate to set
	 */
	public void setBuyDate(String buyDate) {
		this.buyDate = buyDate;
	}

	/**
	 * @return the seqNo
	 */
	public String getSeqNo() {
		return seqNo;
	}

	/**
	 * @param seqNo the seqNo to set
	 */
	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}

	/**
	 * @return the customerCode
	 */
	public String getCustomerCode() {
		return customerCode;
	}

	/**
	 * @param customerCode the customerCode to set
	 */
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the employeeCode
	 */
	public String getEmployeeCode() {
		return employeeCode;
	}

	/**
	 * @param employeeCode the employeeCode to set
	 */
	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}

	/**
	 * @return the employeeName
	 */
	public String getEmployeeName() {
		return employeeName;
	}

	/**
	 * @param employeeName the employeeName to set
	 */
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	/**
	 * @return the beforeVolumeKg
	 */
	public String getBeforeVolumeKg() {
		return beforeVolumeKg;
	}

	/**
	 * @param beforeVolumeKg the beforeVolumeKg to set
	 */
	public void setBeforeVolumeKg(String beforeVolumeKg) {
		this.beforeVolumeKg = beforeVolumeKg;
	}

	/**
	 * @return the chargeVolumeL
	 */
	public String getChargeVolumeL() {
		return chargeVolumeL;
	}

	/**
	 * @param chargeVolumeL the chargeVolumeL to set
	 */
	public void setChargeVolumeL(String chargeVolumeL) {
		this.chargeVolumeL = chargeVolumeL;
	}

	/**
	 * @return the chargeVolumeKg
	 */
	public String getChargeVolumeKg() {
		return chargeVolumeKg;
	}

	/**
	 * @param chargeVolumeKg the chargeVolumeKg to set
	 */
	public void setChargeVolumeKg(String chargeVolumeKg) {
		this.chargeVolumeKg = chargeVolumeKg;
	}

	/**
	 * @return the afterVolumeKg
	 */
	public String getAfterVolumeKg() {
		return afterVolumeKg;
	}

	/**
	 * @param afterVolumeKg the afterVolumeKg to set
	 */
	public void setAfterVolumeKg(String afterVolumeKg) {
		this.afterVolumeKg = afterVolumeKg;
	}

	/**
	 * @return the unitPrice
	 */
	public String getUnitPrice() {
		return unitPrice;
	}

	/**
	 * @param unitPrice the unitPrice to set
	 */
	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}

	/**
	 * @return the price
	 */
	public String getPrice() {
		return price;
	}

	/**
	 * @param price the price to set
	 */
	public void setPrice(String price) {
		this.price = price;
	}

	/**
	 * @return the memo
	 */
	public String getMemo() {
		return memo;
	}

	/**
	 * @param memo the memo to set
	 */
	public void setMemo(String memo) {
		this.memo = memo;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "BulkBuy [key=" + this.getKeyValue() 
				+ ", clientNumber=" + clientNumber 
				+ ", carCode=" + carCode 
				+ ", buyType=" + buyType
				+ ", buyDate=" + buyDate
				+ ", seqNo=" + seqNo
				+ ", customerCode=" + customerCode
				+ ", customerName=" + customerName
				+ ", customerCode=" + employeeCode
				+ ", customerName=" + employeeName
				+ ", beforeVolumeKg=" + beforeVolumeKg
				+ ", chargeVolumeL=" + chargeVolumeL
				+ ", chargeVolumeKg=" + chargeVolumeKg
				+ ", afterVolumeKg=" + afterVolumeKg
				+ ", unitPrice=" + unitPrice
				+ ", price=" + price
				+ ", memo=" + memo + "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<BulkBuy><key>" + this.getKeyValue() + "</key><clientNumber>"
				+ clientNumber
				+ "</clientNumber><carCode>"
				+ carCode
				+ "</carCode><buyType>"
				+ buyType
				+ "</buyType><buyDate>"
				+ buyDate
				+ "</buyDate><seqNo>"
				+ seqNo
				+ "</seqNo><customerCode>"
				+ customerCode
				+ "</customerCode><customerName><![CDATA["
				+ customerName
				+ "]]></customerName><employeeCode>"
				+ employeeCode
				+ "</employeeCode><employeeName><![CDATA["
				+ employeeName
				+ "]]></employeeName><beforeVolumeKg>"
				+ beforeVolumeKg
				+ "</beforeVolumeKg><chargeVolumeL>"
				+ chargeVolumeL
				+ "</chargeVolumeL><chargeVolumeKg>"
				+ chargeVolumeKg
				+ "</chargeVolumeKg><afterVolumeKg>"
				+ afterVolumeKg
				+ "</afterVolumeKg><unitPrice>"
				+ unitPrice
				+ "</unitPrice><price>"
				+ price
				+ "</price><memo><![CDATA["
				+ memo
				+ "]]></memo></BulkBuy>";
	}
}
