package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 거래처 정보
 * @author 네오브랜딩
 * @version 1.0
 */

public class CustomerInfo {
	/**
	 * 업체코드 - key
	 */
	private String clientNumber;

	/**
	 * 거래처 코드 - key
	 */
	private String customerCode;

	/**
	 * 거래처 구분
	 */
	private String customerDiv;

	/**
	 * 거래처명
	 */
	private String customerName;

	/**
	 * 기초검침
	 */
	private String meterLavel;
	
	/**
	 * 비고
	 */
	private String remark;

	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap(){
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("C_MNG_NO", getClientNumber());
		keys.put("CUST_CODE", getCustomerCode());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}
	
	/**
	 * @return the clientNumber
	 */
	public String getClientNumber() {
		return clientNumber;
	}

	/**
	 * @param clientNumber the clientNumber to set
	 */
	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	/**
	 * @return the customerCode
	 */
	public String getCustomerCode() {
		return customerCode;
	}

	/**
	 * @param customerCode the customerCode to set
	 */
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	/**
	 * @return the customerDiv
	 */
	public String getCustomerDiv() {
		return customerDiv;
	}

	/**
	 * @param customerDiv the customerDiv to set
	 */
	public void setCustomerDiv(String customerDiv) {
		this.customerDiv = customerDiv;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the remark
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * @param remark the remark to set
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
	 * @return the meterLavel
	 */
	public String getMeterLavel() {
		return meterLavel;
	}

	/**
	 * @param meterLavel the meterLavel to set
	 */
	public void setMeterLavel(String meterLavel) {
		this.meterLavel = meterLavel;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CustomerInfo [key=" + this.getKeyValue() 
				+ ", clientNumber=" + clientNumber
				+ ", customerCode=" + customerCode
				+ ", customerDiv=" 	+ customerDiv
				+ ", customerName=" + customerName
				+ ", meterLavel=" 	+ meterLavel
				+ ", remark="
				+ remark + "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<CustomerInfo><key>" + this.getKeyValue()
				+ "</key><clientNumber>" + clientNumber + "</clientNumber><customerCode>"
				+ customerCode + "</customerCode><customerDiv>"
				+ customerDiv + "</customerDiv><customerName><![CDATA[" + customerName
				+ "]]></customerName><meterLavel>" + meterLavel
				+ "</meterLavel><remark>" + remark
				+ "</remark></CustomerInfo>";
	}
}
