package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 주간수신내역 정보 모델
 * @author 백원태
 * @version 1.0
 */
public class WeeklyList {
	/**
	 * CMNGNO	
	 * 고객번호 - key
	 */
	 private String clientNumber;

	/**
	 * TANKCODE	
	 * 탱크코드
	 */
	 private String tankCode;

	/**
	 * CUSTCODE	
	 * 거래처코드 - key
	 */
	 private String customerCode;

	/**
	 * TRANSMCD	
	 * 발신기코드
	 */
	 private String transmitterCode;

	/**
	 * TANKVOL	
	 * 탱크용량
	 */
	 private String tankCapacity;

	/**
	 * CUSTNAME	
	 * 거래처명
	 */
	 private String customerName;

	/**
	 * INSTDATE	
	 * 설치일자
	 */
	 private String installationDate;

	/**
	 * CUSTTEL	
	 * 전화번호
	 */
	 private String phoneNumber;

	/**
	 * CUSTHP	
	 * 핸드폰
	 */
	 private String mobileNumber;

	/**
	 * ADDR	
	 * 주소
	 */
	 private String address;

	/**
	 * LVL9
	 * 레벨D9
	 */
	 private String level9;

	/**
	 * LVL8
	 * 레벨D8
	 */
	 private String level8;

	 /**
	 * LVL7
	 * 레벨D7
	 */
	 private String level7;
	 
	/**
	 * LVL6
	 * 레벨D6
	 */
	 private String level6;
	 
	 /**
	  * LVL5
	  * 레벨D5
	  */
	 private String level5;
	 
	 /**
	  * LVL4	
	  * 레벨D4
	  */
	 private String level4;

	/**
	 * LVL3	
	 * 레벨D3
	 */
	 private String level3;

	/**
	 * LVL2	
	 * 레벨D2
	 */
	 private String level2;

	/**
	 * LVL1	
	 * 레벨D1 
	 */
	 private String level1;

	/**
	 * LVL0	
	 * 레벨D0
	 */
	 private String level0;
	 
	 /**
	  * R_DATE	
	  * 최종수신일
	  */
	 private String lastReceiveDate;
	 
	 /**
	  * LVL_Last
	  * 최종레벨
	  */
	 private String lastLevel;
	 
	 /**
	  * RMKS
	  * 비고
	  */
	 private String remark;

	 /**
	  * LVL_STATE
	  * 상태
	  */
	 private String levelState;
	 
	 
	 private String lastCharge ;
	 
	 private String avgDay ;
	 
	 private String avgUsage ;
	 
	 
	 
	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap(){
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("C_MNG_NO", getClientNumber());
		keys.put("CUSTCODE", getCustomerCode());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}

	/**
	 * @return the clientNumber
	 */
	public String getClientNumber() {
		return clientNumber;
	}

	/**
	 * @param clientNumber the clientNumber to set
	 */
	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	/**
	 * @return the tankCode
	 */
	public String getTankCode() {
		return tankCode;
	}

	/**
	 * @param tankCode the tankCode to set
	 */
	public void setTankCode(String tankCode) {
		this.tankCode = tankCode;
	}

	/**
	 * @return the customerCode
	 */
	public String getCustomerCode() {
		return customerCode;
	}

	/**
	 * @param customerCode the customerCode to set
	 */
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	/**
	 * @return the transmitterCode
	 */
	public String getTransmitterCode() {
		return transmitterCode;
	}

	/**
	 * @param transmitterCode the transmitterCode to set
	 */
	public void setTransmitterCode(String transmitterCode) {
		this.transmitterCode = transmitterCode;
	}

	/**
	 * @return the tankCapacity
	 */
	public String getTankCapacity() {
		return tankCapacity;
	}

	/**
	 * @param tankCapacity the tankCapacity to set
	 */
	public void setTankCapacity(String tankCapacity) {
		this.tankCapacity = tankCapacity;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the installationDate
	 */
	public String getInstallationDate() {
		return installationDate;
	}

	/**
	 * @param installationDate the installationDate to set
	 */
	public void setInstallationDate(String installationDate) {
		this.installationDate = installationDate;
	}

	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * @return the mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * @param mobileNumber the mobileNumber to set
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the level9
	 */
	public String getLevel9() {
		return level9;
	}

	/**
	 * @param level9 the level9 to set
	 */
	public void setLevel9(String level9) {
		this.level9 = level9;
	}

	/**
	 * @return the level8
	 */
	public String getLevel8() {
		return level8;
	}

	/**
	 * @param level8 the level8 to set
	 */
	public void setLevel8(String level8) {
		this.level8 = level8;
	}

	/**
	 * @return the level7
	 */
	public String getLevel7() {
		return level7;
	}

	/**
	 * @param level7 the level7 to set
	 */
	public void setLevel7(String level7) {
		this.level7 = level7;
	}
	
	
	/**
	 * @return the level6
	 */
	public String getLevel6() {
		return level6;
	}

	/**
	 * @param level6 the level6 to set
	 */
	public void setLevel6(String level6) {
		this.level6 = level6;
	}

	/**
	 * @return the level5
	 */
	public String getLevel5() {
		return level5;
	}

	/**
	 * @param level5 the level5 to set
	 */
	public void setLevel5(String level5) {
		this.level5 = level5;
	}

	/**
	 * @return the level4
	 */
	public String getLevel4() {
		return level4;
	}

	/**
	 * @param level4 the level4 to set
	 */
	public void setLevel4(String level4) {
		this.level4 = level4;
	}

	/**
	 * @return the level3
	 */
	public String getLevel3() {
		return level3;
	}

	/**
	 * @param level3 the level3 to set
	 */
	public void setLevel3(String level3) {
		this.level3 = level3;
	}

	/**
	 * @return the level2
	 */
	public String getLevel2() {
		return level2;
	}

	/**
	 * @param level2 the level2 to set
	 */
	public void setLevel2(String level2) {
		this.level2 = level2;
	}

	/**
	 * @return the level1
	 */
	public String getLevel1() {
		return level1;
	}

	/**
	 * @param level1 the level1 to set
	 */
	public void setLevel1(String level1) {
		this.level1 = level1;
	}

	/**
	 * @return the level0
	 */
	public String getLevel0() {
		return level0;
	}

	/**
	 * @param level0 the level0 to set
	 */
	public void setLevel0(String level0) {
		this.level0 = level0;
	}

	/**
	 * @return the lastReceiveDate
	 */
	public String getLastReceiveDate() {
		return lastReceiveDate;
	}

	/**
	 * @param lastReceiveDate the lastReceiveDate to set
	 */
	public void setLastReceiveDate(String lastReceiveDate) {
		this.lastReceiveDate = lastReceiveDate;
	}

	/**
	 * @return the lastLevel
	 */
	public String getLastLevel() {
		return lastLevel;
	}

	/**
	 * @param lastLevel the lastLevel to set
	 */
	public void setLastLevel(String lastLevel) {
		this.lastLevel = lastLevel;
	}

	/**
	 * @return the remark
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * @param remark the remark to set
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
	 * @return the levelState
	 */
	public String getLevelState() {
		return levelState;
	}

	/**
	 * @param remark the levelState to set
	 */
	public void setLevelState(String levelState) {
		this.levelState = levelState;
	}

	/**
	 * @return the lastCharge
	 */
	public String getLastCharge() {
		return lastCharge;
	}
	
	/**
	 * @param lastCharge the lastCharge to set
	 */
	public void setLastCharge(String lastCharge) {
		this.lastCharge = lastCharge;
	}

	/**
	 * @return the avgDay
	 */
	public String getAvgDay() {
		return avgDay;
	}
	
	/**
	 * @param avgDay the avgDay to set
	 */
	public void setAvgDay(String avgDay) {
		this.avgDay = avgDay;
	}
	
	/**
	 * @return the avgDay
	 */
	public String getAvgUsage() {
		return avgUsage;
	}
	
	/**
	 * @param avgDay the avgDay to set
	 */
	public void setAvgUsage(String avgUsage) {
		this.avgUsage = avgUsage;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "WeeklyList [key=" + this.getKeyValue() + ", clientNumber="
				+ clientNumber
				+ ", tankCode="
				+ tankCode
				+ ", customerCode="
				+ customerCode
				+ ", transmitterCode="
				+ transmitterCode
				+ ", tankCapacity="
				+ tankCapacity
				+ ", customerName="
				+ customerName
				+ ", installationDate="
				+ installationDate
				+ ", phoneNumber="
				+ phoneNumber
				+ ", mobileNumber="
				+ mobileNumber
				+ ", address="
				+ address
				+ ", level9="
				+ level9
				+ ", level8="
				+ level8
				+ ", level7="
				+ level7
				+ ", level6="
				+ level6
				+ ", level5="
				+ level5
				+ ", level4="
				+ level4
				+ ", level3="
				+ level3
				+ ", level2="
				+ level2
				+ ", level1="
				+ level1
				+ ", level0="
				+ level0
				+ ", lastReceiveDate="
				+ lastReceiveDate
				+ ", lastLevel="
				+ lastLevel
				+ ", remark="
				+ remark
				+ ", levelState="
				+ levelState
				+ ", lastCharge="
				+ lastCharge
				+ ", avgDay="
				+ avgDay 
				+ ", avgUsage="
				+ avgUsage
				+ "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<WeeklyList><key>" + this.getKeyValue() + "</key><clientNumber>"
				+ clientNumber
				+ "</clientNumber><tankCode>"
				+ tankCode
				+ "</tankCode><customerCode>"
				+ customerCode
				+ "</customerCode><transmitterCode>"
				+ transmitterCode
				+ "</transmitterCode><tankCapacity>"
				+ tankCapacity
				+ "</tankCapacity><customerName><![CDATA["
				+ customerName
				+ "]]></customerName><installationDate>"
				+ installationDate
				+ "</installationDate><phoneNumber>"
				+ phoneNumber
				+ "</phoneNumber><mobileNumber>"
				+ mobileNumber
				+ "</mobileNumber><address><![CDATA["
				+ address
				+ "]]></address><level9>"
				+ level9
				+ "</level9><level8>"
				+ level8
				+ "</level8><level7>"
				+ level7
				+ "</level7><level6>"
				+ level6
				+ "</level6><level5>"
				+ level5
				+ "</level5><level4>"
				+ level4
				+ "</level4><level3>"
				+ level3
				+ "</level3><level2>"
				+ level2
				+ "</level2><level1>"
				+ level1
				+ "</level1><level0>"
				+ level0 
				+ "</level0><lastReceiveDate>"
				+ lastReceiveDate 
				+ "</lastReceiveDate><lastLevel>"
				+ lastLevel 
				+ "</lastLevel><remark><![CDATA["
				+ remark + "]]></remark><levelState>"
				+ levelState 
				+ "</levelState><lastCharge>"
				+ lastCharge 
				+ "</lastCharge><avgDay>"
				+ avgDay     
				+ "</avgDay><avgUsage>"
				+ avgUsage   
				+ "</avgUsage></WeeklyList>";
	}
		
}
