package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 거래처 정보
 * @author 네오브랜딩
 * @version 1.0
 */

public class CylinderPlanList {
	/**
	 * 업체코드 - key
	 */
	private String clientNumber;

	/**
	 * 거래처 코드 - key
	 */
	private String customerCode;

	/**
	 * 절체기 거래처 코드
	 */
	private String custJCode;
	
	/**
	 * 검침 거래처 코드
	 */
	private String custMCode;
	
	/**
	 * 발신기코드
	 */
	private String transmCd;
	
	/**
	 * 거래처명
	 */
	private String customerName;
	
	/**
	 * 공급품목 용량
	 */
	private String cVol;
	
	/**
	 * 공급수량
	 */
	private String cQty;
	
	/**
	 * 품목명(용량*수량)
	 */
	private String cVolQty;
	
	/**
	 * 설정일자
	 */
	private String cDate;
	
	/**
	 * 등록구분 (2:절체기, 3: 검침)
	 */
	private String jmDiv;
	
	/**
	 * 전검침
	 */
	private String meterF;
	
	/**
	 * 현검침
	 */
	private String meterT;
	
	/**
	 * 예상공급 사용량 설정값
	 */
	private String setCount;
	
	/**
	 * 초과 사용량
	 */
	private String meterOver;
	
	/**
	 * 사용량 구분(1:초과, 2:예정, 3:기타)
	 */
	private String filterType;
	
	/**
	 * 미수신 여부(0:정상, 1:미수신) 2일이상 수신신호 유무로 판단
	 */
	private String rcvType;
	
	/**
	 * 절체기 최종 수신상태값(1:3:5 요청, 2:4:6 완료) 
	 */
	private String jState;
	
	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap(){
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("JM_DIV", getJmDiv());
		keys.put("C_MNG_NO", getClientNumber());
		keys.put("CUST_CODE", getCustomerCode());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}
	
	/**
	 * getters/setters
	 * @return
	 */
	public String getClientNumber() {
		return clientNumber;
	}

	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getCustJCode() {
		return custJCode;
	}

	public void setCustJCode(String custJCode) {
		this.custJCode = custJCode;
	}

	public String getCustMCode() {
		return custMCode;
	}

	public void setCustMCode(String custMCode) {
		this.custMCode = custMCode;
	}

	public String getTransmCd() {
		return transmCd;
	}

	public void setTransmCd(String transmCd) {
		this.transmCd = transmCd;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getcVol() {
		return cVol;
	}

	public void setcVol(String cVol) {
		this.cVol = cVol;
	}

	public String getcQty() {
		return cQty;
	}

	public void setcQty(String cQty) {
		this.cQty = cQty;
	}

	public String getcVolQty() {
		return cVolQty;
	}

	public void setcVolQty(String cVolQty) {
		this.cVolQty = cVolQty;
	}

	public String getcDate() {
		return cDate;
	}

	public void setcDate(String cDate) {
		this.cDate = cDate;
	}

	public String getJmDiv() {
		return jmDiv;
	}

	public void setJmDiv(String jmDiv) {
		this.jmDiv = jmDiv;
	}

	public String getMeterF() {
		return meterF;
	}

	public void setMeterF(String meterF) {
		this.meterF = meterF;
	}

	public String getMeterT() {
		return meterT;
	}

	public void setMeterT(String meterT) {
		this.meterT = meterT;
	}

	public String getSetCount() {
		return setCount;
	}

	public void setSetCount(String setCount) {
		this.setCount = setCount;
	}

	public String getMeterOver() {
		return meterOver;
	}

	public void setMeterOver(String meterOver) {
		this.meterOver = meterOver;
	}

	public String getFilterType() {
		return filterType;
	}

	public void setFilterType(String filterType) {
		this.filterType = filterType;
	}

	public String getRcvType() {
		return rcvType;
	}

	public void setRcvType(String rcvType) {
		this.rcvType = rcvType;
	}
	
	public String getjState() {
		return jState;
	}

	public void setjState(String jState) {
		this.jState = jState;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CylinderPlanList [key=" + this.getKeyValue() 
				+ ", clientNumber=" + clientNumber
				+ ", customerCode=" + customerCode
				+ ", custJCode=" + custJCode
				+ ", custMCode=" + custMCode
				+ ", transmCd=" + transmCd
				+ ", customerName=" + customerName
				+ ", cVol=" + cVol
				+ ", cQty=" + cQty
				+ ", cVolQty=" + cVolQty
				+ ", cDate=" + cDate
				+ ", jmDiv=" + jmDiv
				+ ", meterF=" + meterF
				+ ", meterT=" + meterT
				+ ", setCount=" + setCount
				+ ", meterOver=" + meterOver
				+ ", filterType=" + filterType
				+ ", rcvType=" + rcvType
				+ ", jState="
				+ jState + "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<CylinderPlanList><key>" + this.getKeyValue()
				+ "</key><clientNumber>" + clientNumber + "</clientNumber>"
				+ "<customerCode>" + customerCode + "</customerCode>"
				+ "<custJCode>" + custJCode + "</custJCode>"
				+ "<custMCode>" + custMCode + "</custMCode>"
				+ "<transmCd>" + transmCd + "</transmCd>"
				+ "<customerName>" + customerName + "</customerName>"
				+ "<cVol>" + cVol + "</cVol>"
				+ "<cQty>" + cQty + "</cQty>"
				+ "<cVolQty>" + cVolQty + "</cVolQty>"
				+ "<cDate>" + cDate + "</cDate>"
				+ "<jmDiv>" + jmDiv + "</jmDiv>"
				+ "<meterF>" + meterF + "</meterF>"
				+ "<meterT>" + meterT + "</meterT>"
				+ "<setCount>" + setCount + "</setCount>"
				+ "<meterOver>" + meterOver + "</meterOver>"
				+ "<filterType>" + filterType + "</filterType>"
				+ "<rcvType>" + rcvType + "</rcvType>"
				+ "<jState>" + jState + "</jState>"
				+ "</CylinderPlanList>";
	}
}
