package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 충전관리 거래처 정보 모델
 * @author 서경엔씨에스
 * @version 1.0
 */
public class BulkCustomer {
	
	private String clientNumber;
	private String customerCode;
	private String customerName;
	private String customerTel;
	private String customerHp;
	private String customerAddr;
	private String remark;
	private String tankVolume;
	private String transmitterCode;
	private String tankLevel;
	private String eventName;
	private String tankLevelState;
	private String receiveDate;
	private String chargeType;

	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap() {
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("MNG_NO", getClientNumber());
		keys.put("CUST_CODE", getCustomerCode());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}

	public String getClientNumber() {
		return clientNumber;
	}

	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = (customerName == null) ? "" : customerName;
	}

	public String getCustomerTel() {
		return customerTel;
	}

	public void setCustomerTel(String customerTel) {
		this.customerTel = (customerTel == null) ? "" : customerTel;
	}

	public String getCustomerHp() {
		return customerHp;
	}

	public void setCustomerHp(String customerHp) {
		this.customerHp = (customerHp == null) ? "" : customerHp;
	}

	public String getCustomerAddr() {
		return customerAddr;
	}

	public void setCustomerAddr(String customerAddr) {
		this.customerAddr = (customerAddr == null) ? "" : customerAddr;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = (remark == null) ? "" : remark;
	}

	public String getTankVolume() {
		return tankVolume;
	}

	public void setTankVolume(String tankVolume) {
		this.tankVolume = (tankVolume == null) ? "" : tankVolume;
	}

	public String getTransmitterCode() {
		return transmitterCode;
	}

	public void setTransmitterCode(String transmitterCode) {
		this.transmitterCode = (transmitterCode == null) ? "" : transmitterCode;
	}

	public String getTankLevel() {
		return tankLevel;
	}

	public void setTankLevel(String tankLevel) {
		this.tankLevel = (tankLevel == null) ? "" : tankLevel;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = (eventName == null) ? "" : eventName;
	}

	public String getTankLevelState() {
		return tankLevelState;
	}

	public void setTankLevelState(String tankLevelState) {
		this.tankLevelState = (tankLevelState == null) ? "" : tankLevelState;
	}

	public String getReceiveDate() {
		return receiveDate;
	}

	public void setReceiveDate(String receiveDate) {
		this.receiveDate = (receiveDate == null) ? "" : receiveDate;
	}

	public String getChargeType() {
		return chargeType;
	}

	public void setChargeType(String chargeType) {
		this.chargeType = (chargeType == null) ? "" : chargeType;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "BulkCustomer [key=" + this.getKeyValue() 
				+ ", clientNumber=" + clientNumber 
				+ ", customerCode=" + customerCode
				+ ", customerName=" + customerName
				+ ", customerTel=" + customerTel
				+ ", customerHp=" + customerHp
				+ ", customerAddr=" + customerAddr
				+ ", remark=" + remark
				+ ", tankVolume=" + tankVolume
				+ ", transmitterCode=" + transmitterCode
				+ ", tankLevel=" + tankLevel
				+ ", eventName=" + eventName
				+ ", tankLevelState=" + tankLevelState
				+ ", receiveDate=" + receiveDate
				+ ", chargeType=" + chargeType + "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<BulkCustomer><key>" + this.getKeyValue() + "</key><clientNumber>"
				+ clientNumber
				+ "</clientNumber><customerCode>"
				+ customerCode
				+ "</customerCode><customerName><![CDATA["
				+ customerName
				+ "]]></customerName><customerTel>"
				+ customerTel
				+ "</customerTel><customerHp>"
				+ customerHp
				+ "</customerHp><customerAddr><![CDATA["
				+ customerAddr
				+ "]]></customerAddr><remark><![CDATA["
				+ remark
				+ "]]></remark><tankVolume>"
				+ tankVolume
				+ "</tankVolume><transmitterCode>"
				+ transmitterCode
				+ "</transmitterCode><tankLevel>"
				+ tankLevel
				+ "</tankLevel><eventName><![CDATA["
				+ eventName
				+ "]]></eventName><tankLevelState>"
				+ tankLevelState
				+ "</tankLevelState><receiveDate>"
				+ receiveDate
				+ "</receiveDate><chargeType>"
				+ chargeType
				+ "</chargeType></BulkCustomer>";
	}
}
