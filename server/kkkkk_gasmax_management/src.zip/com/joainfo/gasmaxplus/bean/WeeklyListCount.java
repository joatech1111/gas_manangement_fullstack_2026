package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 주간수신 집계정보 모델
 * @author 네오브랜딩
 * @version 1.0
 */
public class WeeklyListCount {
	/**
	 * CMNGNO	
	 * 고객번호 - key
	 */
	 private String clientNumber;

	/**
	 * CUSTCODE	
	 * 거래처코드 - key
	 */
	 private String customerCode;

	 /**
	 * LVL_STATE = 0, 1, 2, 3	
	 * 합계
	 */
	 private String levelTotal;

	 /**
	 * LVL_STATE = 0	
	 * 긴급
	 */
	 private String levelCount0;
	 
	/**
	 * LVL_STATE = 1	
	 * 경보
	 */	 
	 private String levelCount1;
	 
	/**
	 * LVL_STATE = 2 
	 * 주의
	 */
	 private String levelCount2;
	 
	/**
	 * LVL_STATE = 3 
	 * 정상
	 */
	 private String levelCount3;
	 
	 /**
	 * R_DATE_OVER	
	 * 미수신
	 */
	 private String receiveDateOverCount;
	 
	 /**
	 * DONGIL_YN	
	 * 동일레벨
	 */
	 private String uniformLevelCount;

	 /**
	 * LOW_BAT	
	 * 배터리
	 */
	 private String lowBatteryCount;

	/**
	 * @return the levelTotal
	 */
	public String getLevelTotal() {
		return levelTotal;
	}

	/**
	 * @param levelTotal the levelCoulevelTotalnt0 to set
	 */
	public void setLevelTotal(String levelTotal) {
		this.levelTotal = levelTotal;
	}

	/**
	 * @return the levelCount0
	 */
	public String getLevelCount0() {
		return levelCount0;
	}

	/**
	 * @param levelCount0 the levelCount0 to set
	 */
	public void setLevelCount0(String levelCount0) {
		this.levelCount0 = levelCount0;
	}

	/**
	 * @return the levelCount1
	 */
	public String getLevelCount1() {
		return levelCount1;
	}

	/**
	 * @param levelCount1 the levelCount1 to set
	 */
	public void setLevelCount1(String levelCount1) {
		this.levelCount1 = levelCount1;
	}

	/**
	 * @return the levelCount2
	 */
	public String getLevelCount2() {
		return levelCount2;
	}

	/**
	 * @param levelCount2 the levelCount2 to set
	 */
	public void setLevelCount2(String levelCount2) {
		this.levelCount2 = levelCount2;
	}

	/**
	 * @return the levelCount3
	 */
	public String getLevelCount3() {
		return levelCount3;
	}

	/**
	 * @param levelCount3 the levelCount3 to set
	 */
	public void setLevelCount3(String levelCount3) {
		this.levelCount3 = levelCount3;
	}

	/**
	 * @return the receiveDateOverCount
	 */
	public String getReceiveDateOverCount() {
		return receiveDateOverCount;
	}

	/**
	 * @param receiveDateOverCount the addrreceiveDateOverCountess to set
	 */
	public void setReceiveDateOver(String receiveDateOverCount) {
		this.receiveDateOverCount = receiveDateOverCount;
	}

	/**
	 * @return the uniformLevelCount
	 */
	public String getUniformLevelCount() {
		return uniformLevelCount;
	}

	/**
	 * @param uniformLevelCount the uniformLevelCount to set
	 */
	public void setUniformLevelCount(String uniformLevelCount) {
		this.uniformLevelCount = uniformLevelCount;
	}

	/**
	 * @return the lowBatteryCount
	 */
	public String getLowBatteryCount() {
		return lowBatteryCount;
	}

	/**
	 * @param lowBatteryCount the lowBatteryCount to set
	 */
	public void setLowBatteryCount(String lowBatteryCount) {
		this.lowBatteryCount = lowBatteryCount;
	}
	
	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap(){
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("LVL_TOTAL", getLevelTotal());
		
		return keys; 
	}
	
	/**
	 * @return the clientNumber
	 */
	public String getClientNumber() {
		return clientNumber;
	}

	/**
	 * @param clientNumber the clientNumber to set
	 */
	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	/**
	 * @return the customerCode
	 */
	public String getCustomerCode() {
		return customerCode;
	}

	/**
	 * @param customerCode the customerCode to set
	 */
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}	

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "WeeklyListCount [levelTotal=" + levelTotal
				+ ", levelCount0=" + levelCount0
				+ ", levelCount1="	+ levelCount1
				+ ", levelCount2=" + levelCount2
				+ ", levelCount3=" + levelCount3
				+ ", receiveDateOverCount="	+ receiveDateOverCount
				+ ", uniformLevelCount=" + uniformLevelCount
				+ ", lowBatteryCount=" + lowBatteryCount
				+ "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<WeeklyListCount><levelTotal>"
				+ levelTotal + "</levelTotal><levelCount0>"
				+ levelCount0 + "</levelCount0><levelCount1>"
				+ levelCount1 + "</levelCount1><levelCount2>"
				+ levelCount2 + "</levelCount2><levelCount3>"
				+ levelCount3 + "</levelCount3><receiveDateOverCount>"
				+ receiveDateOverCount + "</receiveDateOverCount><uniformLevelCount>"
				+ uniformLevelCount + "</uniformLevelCount><lowBatteryCount>"
				+ lowBatteryCount + "</lowBatteryCount></WeeklyListCount>";
	}
	
	/**
	 * JSON 문자열 반환
	 * @return JSON
	 */
	public String toJSON() {
		return "{\"levelTotal\":\"" + levelTotal
				+ "\", \"levelCount0\":\"" + levelCount0
				+ "\", \"levelCount1\":\""	+ levelCount1
				+ "\", \"levelCount2\":\"" + levelCount2
				+ "\", \"levelCount3\":\"" + levelCount3
				+ "\", \"receiveDateOverCount\":\""	+ receiveDateOverCount
				+ "\", \"uniformLevelCount\":\"" + uniformLevelCount
				+ "\", \"lowBatteryCount\":\"" + lowBatteryCount
				+ "\"}";
	}
		
}
