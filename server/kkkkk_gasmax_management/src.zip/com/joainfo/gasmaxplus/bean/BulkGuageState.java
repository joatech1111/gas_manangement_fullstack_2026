package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 충전관리 벌크로리 재고 현황 정보 모델
 * @author 서경엔씨에스
 * @version 1.0
 */
public class BulkGuageState {
	
	private String clientNumber;
	private String carCode;
	private String findDate;
	private String prevGuage;
	private String warehousing;
	private String delivery;
	private String guage;

	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap() {
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("MNG_NO", getClientNumber());
		keys.put("CAR_CODE", getCarCode());
		keys.put("JAEGO_Date", getFindDate());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}

	public String getClientNumber() {
		return clientNumber;
	}

	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	public String getCarCode() {
		return carCode;
	}

	public void setCarCode(String carCode) {
		this.carCode = carCode;
	}

	public String getFindDate() {
		return findDate;
	}

	public void setFindDate(String findDate) {
		this.findDate = findDate;
	}

	public String getPrevGuage() {
		return prevGuage;
	}

	public void setPrevGuage(String prevGuage) {
		this.prevGuage = prevGuage;
	}

	public String getWarehousing() {
		return warehousing;
	}

	public void setWarehousing(String warehousing) {
		this.warehousing = warehousing;
	}

	public String getDelivery() {
		return delivery;
	}

	public void setDelivery(String delivery) {
		this.delivery = delivery;
	}

	public String getGuage() {
		return guage;
	}

	public void setGuage(String guage) {
		this.guage = guage;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "BulkGuageState [key=" + this.getKeyValue() 
				+ ", clientNumber=" + clientNumber 
				+ ", carCode=" + carCode 
				+ ", findDate=" + findDate
				+ ", prevGuage=" + prevGuage
				+ ", warehousing=" + warehousing
				+ ", delivery=" + delivery
				+ ", guage=" + guage + "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<BulkGuageState><key>" + this.getKeyValue() + "</key><clientNumber>"
				+ clientNumber
				+ "</clientNumber><carCode>"
				+ carCode
				+ "</carCode><findDate>"
				+ findDate
				+ "</findDate><prevGuage>"
				+ prevGuage
				+ "</prevGuage><warehousing>"
				+ warehousing
				+ "</warehousing><delivery>"
				+ delivery
				+ "</delivery><guage>"
				+ guage
				+ "</guage></BulkGuageState>";
	}
}
