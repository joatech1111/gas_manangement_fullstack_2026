package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 충전관리 벌크로리 정보 모델
 * @author 서경엔씨에스
 * @version 1.0
 */
public class BulkCar {
	
	private String clientNumber;
	private String carCode;
	private String carName;
	private String employeeCode;
	private String employeeName;

	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap() {
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("MNG_NO", getClientNumber());
		keys.put("CAR_CODE", getCarCode());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}

	public String getClientNumber() {
		return clientNumber;
	}

	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	public String getCarCode() {
		return carCode;
	}

	public void setCarCode(String carCode) {
		this.carCode = carCode;
	}

	public String getCarName() {
		return carName;
	}

	public void setCarName(String carName) {
		this.carName = carName;
	}

	public String getEmployeeCode() {
		return employeeCode;
	}

	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "BulkCar [key=" + this.getKeyValue() 
				+ ", clientNumber=" + clientNumber 
				+ ", carCode=" + carCode 
				+ ", carName=" + carName
				+ ", employeeCode=" + employeeCode
				+ ", employeeName=" + employeeName + "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<BulkCar><key>" + this.getKeyValue() + "</key><clientNumber>"
				+ clientNumber
				+ "</clientNumber><carCode>"
				+ carCode
				+ "</carCode><carName><![CDATA["
				+ carName
				+ "]]></carName><employeeCode>"
				+ employeeCode
				+ "</employeeCode><employeeName><![CDATA["
				+ employeeName
				+ "]]></employeeName></BulkCar>";
	}
	
	/**
	 * JSON 문자열 반환
	 * @return JSON
	 */
	public String toJSON() {
		return "{\"key\":\"" + this.getKeyValue()
				+ "\", \"clientNumber\":\"" + clientNumber
				+ "\", \"carCode\":\"" + carCode
				+ "\", \"carName\":\"" + carName
				+ "\", \"employeeCode\":\"" + employeeCode
				+ "\", \"employeeName\":\"" + employeeName
				+ "\"}";
	}
}
