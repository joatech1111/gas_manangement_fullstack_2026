package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 충전관리 충전현황 정보 모델
 * @author 서경엔씨에스
 * @version 1.0
 */
public class BulkCharge {
	
	private String clientNumber;
	private String carCode;
	private String chargeDate;
	private String chargeTime;
	private String carName;
	private String transmitterCode;
	private String chargeType;
	private String customerCode;
	private String customerName;
	private String employeeCode;
	private String employeeName;
	private String chargeVolumeL;
	private String chargeVolumeKg;
	private String totalChargeVolumeL;
	private String chargeCount;
	private String temperature;
	private String unitPrice;
	private String price;
	private String memo;

	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap() {
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("MNG_NO", getClientNumber());
		keys.put("CAR_CODE", getCarCode());
		keys.put("DATE", getChargeDate());
		keys.put("TIME", getChargeTime());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}

	public String getClientNumber() {
		return clientNumber;
	}

	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	public String getCarCode() {
		return carCode;
	}

	public void setCarCode(String carCode) {
		this.carCode = carCode;
	}

	public String getChargeDate() {
		return chargeDate;
	}

	public void setChargeDate(String chargeDate) {
		this.chargeDate = chargeDate;
	}

	public String getChargeTime() {
		return chargeTime;
	}

	public void setChargeTime(String chargeTime) {
		this.chargeTime = chargeTime;
	}

	public String getCarName() {
		return carName;
	}

	public void setCarName(String carName) {
		this.carName = carName;
	}

	public String getTransmitterCode() {
		return transmitterCode;
	}

	public void setTransmitterCode(String transmitterCode) {
		this.transmitterCode = transmitterCode;
	}

	public String getChargeType() {
		return chargeType;
	}

	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmployeeCode() {
		return employeeCode;
	}

	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getChargeVolumeL() {
		return chargeVolumeL;
	}

	public void setChargeVolumeL(String chargeVolumeL) {
		this.chargeVolumeL = chargeVolumeL;
	}

	public String getChargeVolumeKg() {
		return chargeVolumeKg;
	}

	public void setChargeVolumeKg(String chargeVolumeKg) {
		this.chargeVolumeKg = chargeVolumeKg;
	}

	public String getTotalChargeVolumeL() {
		return totalChargeVolumeL;
	}

	public void setTotalChargeVolumeL(String totalChargeVolumeL) {
		this.totalChargeVolumeL = totalChargeVolumeL;
	}

	public String getChargeCount() {
		return chargeCount;
	}

	public void setChargeCount(String chargeCount) {
		this.chargeCount = chargeCount;
	}

	public String getTemperature() {
		return temperature;
	}

	public void setTemperature(String temperature) {
		this.temperature = temperature;
	}

	public String getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(String unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "BulkCharge [key=" + this.getKeyValue() 
				+ ", clientNumber=" + clientNumber 
				+ ", carCode=" + carCode 
				+ ", chargeDate=" + chargeDate
				+ ", chargeTime=" + chargeTime
				+ ", carName=" + carName
				+ ", transmitterCode=" + transmitterCode
				+ ", chargeType=" + chargeType
				+ ", customerCode=" + customerCode
				+ ", customerName=" + customerName
				+ ", customerCode=" + employeeCode
				+ ", customerName=" + employeeName
				+ ", chargeVolumeL=" + chargeVolumeL
				+ ", chargeVolumeKg=" + chargeVolumeKg
				+ ", totalChargeVolumeL=" + totalChargeVolumeL
				+ ", chargeCount=" + chargeCount
				+ ", temperature=" + temperature
				+ ", unitPrice=" + unitPrice
				+ ", price=" + price
				+ ", memo=" + memo + "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<BulkCharge><key>" + this.getKeyValue() + "</key><clientNumber>"
				+ clientNumber
				+ "</clientNumber><carCode>"
				+ carCode
				+ "</carCode><chargeDate>"
				+ chargeDate
				+ "</chargeDate><chargeTime>"
				+ chargeTime
				+ "</chargeTime><carName><![CDATA["
				+ carName
				+ "]]></carName><transmitterCode>"
				+ transmitterCode
				+ "</transmitterCode><chargeType>"
				+ chargeType
				+ "</chargeType><customerCode>"
				+ customerCode
				+ "</customerCode><customerName><![CDATA["
				+ customerName
				+ "]]></customerName><employeeCode>"
				+ employeeCode
				+ "</employeeCode><employeeName><![CDATA["
				+ employeeName
				+ "]]></employeeName><chargeVolumeL>"
				+ chargeVolumeL
				+ "</chargeVolumeL><chargeVolumeKg>"
				+ chargeVolumeKg
				+ "</chargeVolumeKg><totalChargeVolumeL>"
				+ totalChargeVolumeL
				+ "</totalChargeVolumeL><chargeCount>"
				+ chargeCount
				+ "</chargeCount><temperature>"
				+ temperature
				+ "</temperature><unitPrice>"
				+ unitPrice
				+ "</unitPrice><price>"
				+ price
				+ "</price><memo><![CDATA["
				+ memo
				+ "]]></memo></BulkCharge>";
	}
}
