package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 충전관리 충전현황 정보 모델
 * @author 서경엔씨에스
 * @version 1.0
 */
public class BulkChargeState {
	
	private String clientNumber;
	private String carCode;
	private String chargeSeqNo;
	private String chargeDate;
	private String chargeTime;
	private String chargeType;
	private String transmitterCode;
	private String customerCode;
	private String customerName;
	private String chargeVolumeL;
	private String chargeVolumeKg;
	private String tankVolume;
	private String gpsX;
	private String gpsY;

	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap() {
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("MNG_NO", getClientNumber());
		keys.put("CAR_CODE", getCarCode());
		keys.put("SNO", getChargeSeqNo());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}

	public String getClientNumber() {
		return clientNumber;
	}

	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	public String getCarCode() {
		return carCode;
	}

	public void setCarCode(String carCode) {
		this.carCode = carCode;
	}

	public String getChargeSeqNo() {
		return chargeSeqNo;
	}

	public void setChargeSeqNo(String chargeSeqNo) {
		this.chargeSeqNo = chargeSeqNo;
	}

	public String getChargeDate() {
		return chargeDate;
	}

	public void setChargeDate(String chargeDate) {
		this.chargeDate = chargeDate;
	}

	public String getChargeTime() {
		return chargeTime;
	}

	public void setChargeTime(String chargeTime) {
		this.chargeTime = chargeTime;
	}

	public String getChargeType() {
		return chargeType;
	}

	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}

	public String getTransmitterCode() {
		return transmitterCode;
	}

	public void setTransmitterCode(String transmitterCode) {
		this.transmitterCode = transmitterCode;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getChargeVolumeL() {
		return chargeVolumeL;
	}

	public void setChargeVolumeL(String chargeVolumeL) {
		this.chargeVolumeL = chargeVolumeL;
	}

	public String getChargeVolumeKg() {
		return chargeVolumeKg;
	}

	public void setChargeVolumeKg(String chargeVolumeKg) {
		this.chargeVolumeKg = chargeVolumeKg;
	}

	public String getTankVolume() {
		return tankVolume;
	}

	public void setTankVolume(String tankVolume) {
		this.tankVolume = tankVolume;
	}
	
	public String getGpsX() {
		return gpsX;
	}

	public void setGpsX(String gpsX) {
		this.gpsX = gpsX;
	}

	public String getGpsY() {
		return gpsY;
	}

	public void setGpsY(String gpsY) {
		this.gpsY = gpsY;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "BulkChargeState [key=" + this.getKeyValue() 
				+ ", clientNumber=" + clientNumber 
				+ ", carCode=" + carCode 
				+ ", chargeSeqNo=" + chargeSeqNo
				+ ", chargeDate=" + chargeDate
				+ ", chargeTime=" + chargeTime
				+ ", chargeType=" + chargeType
				+ ", transmitterCode=" + transmitterCode
				+ ", customerCode=" + customerCode
				+ ", customerName=" + customerName
				+ ", chargeVolumeL=" + chargeVolumeL
				+ ", chargeVolumeKg=" + chargeVolumeKg
				+ ", tankVolume=" + tankVolume
				+ ", gpsX=" + gpsX
				+ ", gpsY=" + gpsY + "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<BulkChargeState><key>" + this.getKeyValue() + "</key><clientNumber>"
				+ clientNumber
				+ "</clientNumber><carCode>"
				+ carCode
				+ "</carCode><chargeSeqNo>"
				+ chargeSeqNo
				+ "</chargeSeqNo><chargeDate>"
				+ chargeDate
				+ "</chargeDate><chargeTime>"
				+ chargeTime
				+ "</chargeTime><chargeType>"
				+ chargeType
				+ "</chargeType><transmitterCode>"
				+ transmitterCode
				+ "</transmitterCode><customerCode>"
				+ customerCode
				+ "</customerCode><customerName><![CDATA["
				+ customerName
				+ "]]></customerName><chargeVolumeL>"
				+ chargeVolumeL
				+ "</chargeVolumeL><chargeVolumeKg>"
				+ chargeVolumeKg
				+ "</chargeVolumeKg><tankVolume>"
				+ tankVolume
				+ "</tankVolume><gpsX>"
				+ gpsX
				+ "</gpsX><gpsY>"
				+ gpsY
				+ "</gpsY></BulkChargeState>";
	}
	
	/**
	 * JSON 문자열 반환
	 * @return JSON
	 */
	public String toJSON() {
		return "{\"key\":\"" + this.getKeyValue()
				+ "\", \"clientNumber\":\"" + clientNumber
				+ "\", \"carCode\":\""	+ carCode
				+ "\", \"chargeSeqNo\":\"" + chargeSeqNo
				+ "\", \"chargeDate\":\""	+ chargeDate
				+ "\", \"chargeTime\":\"" + chargeTime
				+ "\", \"chargeType\":\"" + chargeType
				+ "\", \"customerName\":\"" + customerName
				+ "\", \"chargeVolumeL\":\"" + chargeVolumeL
				+ "\", \"chargeVolumeKg\":\"" + chargeVolumeKg
				+ "\", \"tankVolume\":\"" + tankVolume
				+ "\", \"gpsX\":\"" + gpsX
				+ "\", \"gpsY\":\"" + gpsY
				+ "\"}";
	}
}
