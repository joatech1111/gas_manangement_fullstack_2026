package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 충전관리 거래처 정보 모델
 * @author 서경엔씨에스
 * @version 1.0
 */
public class TankCustomer {
	
	private String clientNumber;
	private String customerCode;
	private String customerName;
	private String remark;
	private String customerTel;
	private String customerHp;
	private String customerZipCode;
	private String customerAddr1;
	private String customerAddr2;
	private String gpsX;
	private String gpsY;
	private String employeeCode;
	private String employeeName;
	private String areaTypeCode;
	private String areaTypeName;
	private String transmitterCode;
	private String tankVolume;
	private String chargeType;

	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap() {
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("MNG_NO", getClientNumber());
		keys.put("CUST_CODE", getCustomerCode());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}

	public String getClientNumber() {
		return clientNumber;
	}

	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = (customerName == null) ? "" : customerName;
	}

	public String getCustomerTel() {
		return customerTel;
	}

	public void setCustomerTel(String customerTel) {
		this.customerTel = (customerTel == null) ? "" : customerTel;
	}

	public String getCustomerHp() {
		return customerHp;
	}

	public void setCustomerHp(String customerHp) {
		this.customerHp = (customerHp == null) ? "" : customerHp;
	}

	public String getCustomerAddr1() {
		return customerAddr1;
	}

	public void setCustomerAddr1(String customerAddr1) {
		this.customerAddr1 = (customerAddr1 == null) ? "" : customerAddr1;
	}
	
	public String getCustomerAddr2() {
		return customerAddr2;
	}

	public void setCustomerAddr2(String customerAddr2) {
		this.customerAddr2 = (customerAddr2 == null) ? "" : customerAddr2;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = (remark == null) ? "" : remark;
	}

	public String getTankVolume() {
		return tankVolume;
	}

	public void setTankVolume(String tankVolume) {
		this.tankVolume = (tankVolume == null) ? "" : tankVolume;
	}

	public String getTransmitterCode() {
		return transmitterCode;
	}

	public void setTransmitterCode(String transmitterCode) {
		this.transmitterCode = (transmitterCode == null) ? "" : transmitterCode;
	}

	public String getChargeType() {
		return chargeType;
	}

	public void setChargeType(String chargeType) {
		this.chargeType = (chargeType == null) ? "" : chargeType;
	}

	/**
	 * @return the customerZipCode
	 */
	public String getCustomerZipCode() {
		return customerZipCode;
	}

	/**
	 * @param customerZipCode the customerZipCode to set
	 */
	public void setCustomerZipCode(String customerZipCode) {
		this.customerZipCode = customerZipCode;
	}

	/**
	 * @return the gpsX
	 */
	public String getGpsX() {
		return gpsX;
	}

	/**
	 * @param gpsX the gpsX to set
	 */
	public void setGpsX(String gpsX) {
		this.gpsX = gpsX;
	}

	/**
	 * @return the gpsY
	 */
	public String getGpsY() {
		return gpsY;
	}

	/**
	 * @param gpsY the gpsY to set
	 */
	public void setGpsY(String gpsY) {
		this.gpsY = gpsY;
	}

	/**
	 * @return the employeeCode
	 */
	public String getEmployeeCode() {
		return employeeCode;
	}

	/**
	 * @param employeeCode the employeeCode to set
	 */
	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}

	/**
	 * @return the employeeName
	 */
	public String getEmployeeName() {
		return employeeName;
	}

	/**
	 * @param employeeName the employeeName to set
	 */
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	/**
	 * @return the areaTypeCode
	 */
	public String getAreaTypeCode() {
		return areaTypeCode;
	}

	/**
	 * @param areaTypeCode the areaTypeCode to set
	 */
	public void setAreaTypeCode(String areaTypeCode) {
		this.areaTypeCode = areaTypeCode;
	}

	/**
	 * @return the areaTypeName
	 */
	public String getAreaTypeName() {
		return areaTypeName;
	}

	/**
	 * @param areaTypeName the areaTypeName to set
	 */
	public void setAreaTypeName(String areaTypeName) {
		this.areaTypeName = areaTypeName;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TankCustomer [key=" + this.getKeyValue() 
				+ ", clientNumber=" + clientNumber 
				+ ", customerCode=" + customerCode
				+ ", customerName=" + customerName
				+ ", remark=" + remark
				+ ", customerTel=" + customerTel
				+ ", customerHp=" + customerHp
				+ ", customerZipCode=" + customerZipCode
				+ ", customerAddr1=" + customerAddr1
				+ ", customerAddr2=" + customerAddr2
				+ ", gpsX=" + gpsX
				+ ", gpsY=" + gpsY
				+ ", employeeCode=" + employeeCode
				+ ", employeeName=" + employeeName
				+ ", areaTypeCode=" + areaTypeCode
				+ ", areaTypeName=" + areaTypeName
				+ ", transmitterCode=" + transmitterCode
				+ ", tankVolume=" + tankVolume
				+ ", chargeType=" + chargeType + "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<TankCustomer><key>" + this.getKeyValue() + "</key><clientNumber>"
				+ clientNumber
				+ "</clientNumber><customerCode>"
				+ customerCode
				+ "</customerCode><customerName><![CDATA["
				+ customerName
				+ "]]></customerName><remark><![CDATA["
				+ remark
				+ "]]></remark><customerTel>"
				+ customerTel
				+ "</customerTel><customerHp>"
				+ customerHp
				+ "</customerHp><customerZipCode>"
				+ customerZipCode
				+ "</customerZipCode><customerAddr1><![CDATA["
				+ customerAddr1
				+ "]]></customerAddr1><customerAddr2><![CDATA["
				+ customerAddr2
				+ "]]></customerAddr2><gpsX>"
				+ gpsX
				+ "</gpsX><gpsY>"
				+ gpsY
				+ "</gpsY><employeeCode>"
				+ employeeCode
				+ "</employeeCode><employeeName><![CDATA["
				+ employeeName
				+ "]]></employeeName><areaTypeCode>"
				+ areaTypeCode
				+ "</areaTypeCode><areaTypeName><![CDATA["
				+ areaTypeName
				+ "]]></areaTypeName><transmitterCode>"
				+ transmitterCode
				+ "</transmitterCode><tankVolume>"
				+ tankVolume
				+ "</tankVolume><chargeType>"
				+ chargeType
				+ "</chargeType></TankCustomer>";
	}
}
