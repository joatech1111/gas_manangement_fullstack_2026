package com.joainfo.gasmaxplus.bean.list;


import java.util.HashMap;
import java.util.LinkedHashMap;

import com.joainfo.gasmaxplus.bean.CylinderSupplyList;

/**
 * 절체기 정보의 해시 집합
 * @author 네오브랜딩
 * @version 1.0
 */
public class CylinderSupplyListMap {

	/**
	 * Cylinder 목록
	 */
	private LinkedHashMap<String, CylinderSupplyList> cylinderSupplyLists;
	
	/**
	 * 전체 건수
	 */
	private String totalRowCount;
	
	/**
	 * 디폴트 생성자
	 */
	public CylinderSupplyListMap(){
		if (cylinderSupplyLists == null) {
			cylinderSupplyLists = new LinkedHashMap<String, CylinderSupplyList>();
		}
	}
	
	/**
	 * @return LinkedHashMap
	 */
	public LinkedHashMap<String, CylinderSupplyList> getCylinders(){
		return cylinderSupplyLists;
	}
	
	/**
	 * @param cylinderLists
	 */
	public void setCylinderLists(LinkedHashMap<String, CylinderSupplyList> cylinderSupplyLists){
		this.cylinderSupplyLists = cylinderSupplyLists;
	}
	
	/**
	 * @param id
	 * @return Cylinder
	 */
	public CylinderSupplyList getCylinderSupplyList(String id){
		return this.cylinderSupplyLists.get(id);
	}
	
	/**
	 * @param id
	 * @param cylinderList
	 */
	public void setCylinderSupplyList(String id, CylinderSupplyList cylinderSupplyLists){
		this.cylinderSupplyLists.put(id, cylinderSupplyLists);
	}
	
	/**
	 * @param cylinder
	 */
	public void setCylinderSupplyList(CylinderSupplyList cylinderSupplyLists){
		this.cylinderSupplyLists.put(cylinderSupplyLists.getKeyValue(), cylinderSupplyLists);
	}
	
	/**
	 * @param id
	 */
	public void removeCylinderSupplyList(String id){
		this.cylinderSupplyLists.remove(id);
	}
	
	/**
	 * @return the totalRowCount
	 */
	public String getTotalRowCount() {
		return totalRowCount;
	}

	/**
	 * @param totalRowCount the totalRowCount to set
	 */
	public void setTotalRowCount(String totalRowCount) {
		this.totalRowCount = totalRowCount;
	}

	/**
	 * @param id
	 * @return 키에 해당하는 값의 존재 여부를 반환
	 */
	public boolean isExist(String id){
		return  this.cylinderSupplyLists.get(id)==null?false:true;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return cylinderSupplyLists.toString();
	}
	
	/**
	 * @return XML
	 */
	public String toXML(){
		String xml = "<CylinderLists>";
				
		java.util.Iterator<String> iterator = cylinderSupplyLists.keySet().iterator(); 
		
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			xml += cylinderSupplyLists.get(key).toXML();
		  }
		xml += "</CylinderLists>";
		
		return xml; 
	}

	/**
	 * XML을 페이지로 나눠서 HashMap으로 반환
	 * @param rowCount 한 페이지에 들어갈 행의 개수
	 * @return 페이지로 나눠 XML을 담은 HashMap
	 */
	public HashMap<String, String> toPagingXML(int rowCount){
		int pageNumber = 1;
		int rowNumber = 1;
		int totalRowCount = cylinderSupplyLists.size();
		this.setTotalRowCount("" + totalRowCount);
		HashMap<String, String> pageXML = new HashMap<String, String>();
		java.util.Iterator<String> iterator = cylinderSupplyLists.keySet().iterator(); 
		String xml = "";
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			CylinderSupplyList cylinderList = cylinderSupplyLists.get(key);
			if (rowNumber < (pageNumber * rowCount)) {
				xml += cylinderList.toXML();
			} else {
				xml +=  cylinderList.toXML();
				pageXML.put(new Integer(pageNumber).toString(), "<CylinderSupplyLists>" + new String(xml) + "</CylinderSupplyLists>");
				xml = "";
				pageNumber ++;
			}
			rowNumber ++;
		}
		if (!"".equals(xml)){
			pageXML.put(new Integer(pageNumber).toString(),  "<CylinderSupplyLists>" + new String(xml) + "</CylinderSupplyLists>");
		}
		return pageXML;
	}
}
