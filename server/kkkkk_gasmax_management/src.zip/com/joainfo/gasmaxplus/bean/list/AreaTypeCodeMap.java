package com.joainfo.gasmaxplus.bean.list;


import java.util.LinkedHashMap;

import com.joainfo.gasmaxplus.bean.AreaTypeCode;

/**
 * 지역코드 정보의 해시 집합
 * @author 백원태
 * @version 1.0
 */
public class AreaTypeCodeMap {

	/**
	 * AreaTypeCode 목록
	 */
	private LinkedHashMap<String, AreaTypeCode> areaTypeCodes;
	
	/**
	 * 디폴트 생성자
	 */
	public AreaTypeCodeMap(){
		if (areaTypeCodes == null) {
			areaTypeCodes = new LinkedHashMap<String, AreaTypeCode>();
		}
	}
	
	/**
	 * @return LinkedHashMap
	 */
	public LinkedHashMap<String, AreaTypeCode> getAreaTypeCodes(){
		return areaTypeCodes;
	}
	
	/**
	 * @param areaTypeCodes
	 */
	public void setAreaTypeCodes(LinkedHashMap<String, AreaTypeCode> areaTypeCodes){
		this.areaTypeCodes = areaTypeCodes;
	}
	
	/**
	 * @param id
	 * @return AreaTypeCode
	 */
	public AreaTypeCode getAreaTypeCode(String id){
		return this.areaTypeCodes.get(id);
	}
	
	/**
	 * @param id
	 * @param areaTypeCode
	 */
	public void setAreaTypeCode(String id, AreaTypeCode areaTypeCode){
		this.areaTypeCodes.put(id, areaTypeCode);
	}
	
	/**
	 * @param areaTypeCode
	 */
	public void setAreaTypeCode(AreaTypeCode areaTypeCode){
		this.areaTypeCodes.put(areaTypeCode.getKeyValue(), areaTypeCode);
	}
	
	/**
	 * @param id
	 */
	public void removeAreaTypeCode(String id){
		this.areaTypeCodes.remove(id);
	}
	
	/**
	 * @param id
	 * @return 키에 해당하는 값의 존재 여부를 반환
	 */
	public boolean isExist(String id){
		return  this.areaTypeCodes.get(id)==null?false:true;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return areaTypeCodes.toString();
	}
	
	/**
	 * @return XML
	 */
	public String toXML(){
		String xml = "<AreaTypeCodes>";
				
		java.util.Iterator<String> iterator = areaTypeCodes.keySet().iterator(); 
		
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			xml += areaTypeCodes.get(key).toXML();
		  }
		xml += "</AreaTypeCodes>";
		
		return xml; 
	}
	
	/**
	 * @return JSON
	 */
	public String toJSON(){
		String json = "\"areaTypeCodes\":[";
				
		java.util.Iterator<String> iterator = areaTypeCodes.keySet().iterator(); 
		while (iterator.hasNext()) { 
			String key = iterator.next();
			json += areaTypeCodes.get(key).toJSON();
			
			if (iterator.hasNext()) {
				json += ",";
			}
		  }
		json += "]";
		
		return json; 
	}
	
}
