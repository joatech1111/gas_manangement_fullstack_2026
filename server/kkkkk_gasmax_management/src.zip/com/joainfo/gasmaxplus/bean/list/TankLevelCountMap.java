package com.joainfo.gasmaxplus.bean.list;


import java.util.HashMap;
import java.util.LinkedHashMap;

import com.joainfo.gasmaxplus.bean.TankLevelCount;

/**
 * 주간수신 집계정보의 해시 집합
 * @author 네오브랜딩
 * @version 1.0
 */
public class TankLevelCountMap {

	/**
	 * TankLevelCount 목록
	 */
	private LinkedHashMap<String, TankLevelCount> tankLevelCounts;
	
	/**
	 * 전체 건수
	 */
	private String totalRowCount;
	
	/**
	 * 디폴트 생성자
	 */
	public TankLevelCountMap(){
		if (tankLevelCounts == null) {
			tankLevelCounts = new LinkedHashMap<String, TankLevelCount>();
		}
	}
	
	/**
	 * @return LinkedHashMap
	 */
	public LinkedHashMap<String, TankLevelCount> getTankLevelCounts(){
		return tankLevelCounts;
	}
	
	/**
	 * @param tankLevelCounts
	 */
	public void setTankLevelCount(LinkedHashMap<String, TankLevelCount> tankLevelCounts){
		this.tankLevelCounts = tankLevelCounts;
	}
	
	/**
	 * @param id
	 * @return TankLevelCount
	 */
	public TankLevelCount getTankLevelCount(String id){
		return this.tankLevelCounts.get(id);
	}
	
	/**
	 * @param id
	 * @param TankLevelCount
	 */
	public void setTankLevelCount(String id, TankLevelCount TankLevelCount){
		this.tankLevelCounts.put(id, TankLevelCount);
	}
	
	/**
	 * @param TankLevelCount
	 */
	public void setTankLevelCount(TankLevelCount TankLevelCount){
		this.tankLevelCounts.put(TankLevelCount.getKeyValue(), TankLevelCount);
	}
	
	/**
	 * @param id
	 */
	public void removeTankLevelCount(String id){
		this.tankLevelCounts.remove(id);
	}
	
	/**
	 * @return the totalRowCount
	 */
	public String getTotalRowCount() {
		return totalRowCount;
	}

	/**
	 * @param totalRowCount the totalRowCount to set
	 */
	public void setTotalRowCount(String totalRowCount) {
		this.totalRowCount = totalRowCount;
	}

	/**
	 * @param id
	 * @return 키에 해당하는 값의 존재 여부를 반환
	 */
	public boolean isExist(String id){
		return  this.tankLevelCounts.get(id)==null?false:true;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return tankLevelCounts.toString();
	}
	
	/**
	 * @return XML
	 */
	public String toXML(){
		String xml = "<TankLevelCounts>";
				
		java.util.Iterator<String> iterator = tankLevelCounts.keySet().iterator(); 
		
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			xml += tankLevelCounts.get(key).toXML();
		  }
		xml += "</TankLevelCounts>";
		
		return xml; 
	}

	/**
	 * XML을 페이지로 나눠서 HashMap으로 반환
	 * @param rowCount 한 페이지에 들어갈 행의 개수
	 * @return 페이지로 나눠 XML을 담은 HashMap
	 */
	public HashMap<String, String> toPagingXML(int rowCount){
		int pageNumber = 1;
		int rowNumber = 1;
		int totalRowCount = tankLevelCounts.size();
		this.setTotalRowCount("" + totalRowCount);
		HashMap<String, String> pageXML = new HashMap<String, String>();
		java.util.Iterator<String> iterator = tankLevelCounts.keySet().iterator(); 
		String xml = "";
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			TankLevelCount TankLevelCount = tankLevelCounts.get(key);
			if (rowNumber < (pageNumber * rowCount)) {
				xml += TankLevelCount.toXML();
			} else {
				xml +=  TankLevelCount.toXML();
				pageXML.put(new Integer(pageNumber).toString(), "<TankLevelCounts>" + new String(xml) + "</TankLevelCounts>");
				xml = "";
				pageNumber ++;
			}
			rowNumber ++;
		}
		if (!"".equals(xml)){
			pageXML.put(new Integer(pageNumber).toString(),  "<TankLevelCounts>" + new String(xml) + "</TankLevelCounts>");
		}
		return pageXML;
	}

	/**
	 * @return JSON
	 */
	public String toJSON(){
		String json = "\"TankLevelCounts\":[";
				
		java.util.Iterator<String> iterator = tankLevelCounts.keySet().iterator(); 
		while (iterator.hasNext()) { 
			String key = iterator.next();
			json += tankLevelCounts.get(key).toJSON();
			
			if (iterator.hasNext()) {
				json += ",";
			}
		  }
		json += "]";
		
		return json; 
	}
}
