package com.joainfo.gasmaxplus.bean.list;

import java.util.HashMap;
import java.util.LinkedHashMap;

import com.joainfo.gasmaxplus.bean.BulkRun;

/**
 * 충전관리 운행 정보의 해시 집합
 * @author 서경엔씨에스
 * @version 1.0
 */
public class BulkRunMap {

	/**
	 * 목록
	 */
	private LinkedHashMap<String, BulkRun> mMaps;
	
	/**
	 * 전체 건수
	 */
	private String totalRowCount;
	
	/**
	 * 디폴트 생성자
	 */
	public BulkRunMap() {
		if (mMaps == null) {
			mMaps = new LinkedHashMap<String, BulkRun>();
		}
	}
	
	/**
	 * @return LinkedHashMap
	 */
	public LinkedHashMap<String, BulkRun> getValues() {
		return mMaps;
	}
	
	/**
	 * @param maps
	 */
	public void setValues(LinkedHashMap<String, BulkRun> maps) {
		this.mMaps = maps;
	}
	
	/**
	 * @param id
	 * @return value
	 */
	public BulkRun getValue(String id) {
		return this.mMaps.get(id);
	}
	
	/**
	 * @param id
	 * @param value
	 */
	public void setValue(String id, BulkRun value) {
		this.mMaps.put(id, value);
	}
	
	/**
	 * @param id
	 */
	public void removeValue(String id) {
		this.mMaps.remove(id);
	}
	
	/**
	 * @return the totalRowCount
	 */
	public String getTotalRowCount() {
		return totalRowCount;
	}

	/**
	 * @param totalRowCount the totalRowCount to set
	 */
	public void setTotalRowCount(String totalRowCount) {
		this.totalRowCount = totalRowCount;
	}

	/**
	 * @param id
	 * @return 키에 해당하는 값의 존재 여부를 반환
	 */
	public boolean isExist(String id) {
		return  this.mMaps.containsKey(id);
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return mMaps.toString();
	}
	
	/**
	 * @return XML
	 */
	public String toXML() {
		String xml = "<BulkRuns>";
				
		java.util.Iterator<String> iterator = mMaps.keySet().iterator(); 
		
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			xml += mMaps.get(key).toXML();
		}
		xml += "</BulkRuns>";
		
		return xml; 
	}

	/**
	 * XML을 페이지로 나눠서 HashMap으로 반환
	 * @param rowCount 한 페이지에 들어갈 행의 개수
	 * @return 페이지로 나눠 XML을 담은 HashMap
	 */
	public HashMap<String, String> toPagingXML(int rowCount) {
		int pageNumber = 1;
		int rowNumber = 1;
		int totalRowCount = mMaps.size();
		this.setTotalRowCount("" + totalRowCount);
		HashMap<String, String> pageXML = new HashMap<String, String>();
		java.util.Iterator<String> iterator = mMaps.keySet().iterator(); 
		String xml = "";
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			BulkRun value = mMaps.get(key);
			if (rowNumber < (pageNumber * rowCount)) {
				xml += value.toXML();
			} else {
				xml +=  value.toXML();
				pageXML.put(new Integer(pageNumber).toString(), "<BulkRuns>" + new String(xml) + "</BulkRuns>");
				xml = "";
				pageNumber ++;
			}
			rowNumber ++;
		}
		if (!"".equals(xml)){
			pageXML.put(new Integer(pageNumber).toString(),  "<BulkRuns>" + new String(xml) + "</BulkRuns>");
		}
		return pageXML;
	}
}
