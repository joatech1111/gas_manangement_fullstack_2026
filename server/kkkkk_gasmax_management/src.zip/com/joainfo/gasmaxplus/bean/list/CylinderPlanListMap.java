package com.joainfo.gasmaxplus.bean.list;


import java.util.HashMap;
import java.util.LinkedHashMap;

import com.joainfo.gasmaxplus.bean.CylinderPlanList;

/**
 * 절체기 정보의 해시 집합
 * @author 네오브랜딩
 * @version 1.0
 */
public class CylinderPlanListMap {

	/**
	 * Cylinder 목록
	 */
	private LinkedHashMap<String, CylinderPlanList> cylinderPlanLists;
	
	/**
	 * 전체 건수
	 */
	private String totalRowCount;
	
	/**
	 * 디폴트 생성자
	 */
	public CylinderPlanListMap(){
		if (cylinderPlanLists == null) {
			cylinderPlanLists = new LinkedHashMap<String, CylinderPlanList>();
		}
	}
	
	/**
	 * @return LinkedHashMap
	 */
	public LinkedHashMap<String, CylinderPlanList> getCylinders(){
		return cylinderPlanLists;
	}
	
	/**
	 * @param cylinderLists
	 */
	public void setCylinderLists(LinkedHashMap<String, CylinderPlanList> cylinderPlanLists){
		this.cylinderPlanLists = cylinderPlanLists;
	}
	
	/**
	 * @param id
	 * @return Cylinder
	 */
	public CylinderPlanList getCylinderPlanList(String id){
		return this.cylinderPlanLists.get(id);
	}
	
	/**
	 * @param id
	 * @param cylinderList
	 */
	public void setCylinderPlanList(String id, CylinderPlanList cylinderPlanLists){
		this.cylinderPlanLists.put(id, cylinderPlanLists);
	}
	
	/**
	 * @param cylinder
	 */
	public void setCylinderPlanList(CylinderPlanList cylinderPlanLists){
		this.cylinderPlanLists.put(cylinderPlanLists.getKeyValue(), cylinderPlanLists);
	}
	
	/**
	 * @param id
	 */
	public void removeCylinderPlanList(String id){
		this.cylinderPlanLists.remove(id);
	}
	
	/**
	 * @return the totalRowCount
	 */
	public String getTotalRowCount() {
		return totalRowCount;
	}

	/**
	 * @param totalRowCount the totalRowCount to set
	 */
	public void setTotalRowCount(String totalRowCount) {
		this.totalRowCount = totalRowCount;
	}

	/**
	 * @param id
	 * @return 키에 해당하는 값의 존재 여부를 반환
	 */
	public boolean isExist(String id){
		return  this.cylinderPlanLists.get(id)==null?false:true;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return cylinderPlanLists.toString();
	}
	
	/**
	 * @return XML
	 */
	public String toXML(){
		String xml = "<CylinderLists>";
				
		java.util.Iterator<String> iterator = cylinderPlanLists.keySet().iterator(); 
		
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			xml += cylinderPlanLists.get(key).toXML();
		  }
		xml += "</CylinderLists>";
		
		return xml; 
	}

	/**
	 * XML을 페이지로 나눠서 HashMap으로 반환
	 * @param rowCount 한 페이지에 들어갈 행의 개수
	 * @return 페이지로 나눠 XML을 담은 HashMap
	 */
	public HashMap<String, String> toPagingXML(int rowCount){
		int pageNumber = 1;
		int rowNumber = 1;
		int totalRowCount = cylinderPlanLists.size();
		this.setTotalRowCount("" + totalRowCount);
		HashMap<String, String> pageXML = new HashMap<String, String>();
		java.util.Iterator<String> iterator = cylinderPlanLists.keySet().iterator(); 
		String xml = "";
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			CylinderPlanList cylinderList = cylinderPlanLists.get(key);
			if (rowNumber < (pageNumber * rowCount)) {
				xml += cylinderList.toXML();
			} else {
				xml +=  cylinderList.toXML();
				pageXML.put(new Integer(pageNumber).toString(), "<CylinderPlanLists>" + new String(xml) + "</CylinderPlanLists>");
				xml = "";
				pageNumber ++;
			}
			rowNumber ++;
		}
		if (!"".equals(xml)){
			pageXML.put(new Integer(pageNumber).toString(),  "<CylinderPlanLists>" + new String(xml) + "</CylinderPlanLists>");
		}
		return pageXML;
	}
}
