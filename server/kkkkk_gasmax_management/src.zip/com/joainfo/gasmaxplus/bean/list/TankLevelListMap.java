package com.joainfo.gasmaxplus.bean.list;


import java.util.HashMap;
import java.util.LinkedHashMap;

import com.joainfo.gasmaxplus.bean.TankLevelList;

/**
 * 탱크잔량조회 정보의 해시 집합
 * @author 서경엔씨에스
 * @version 1.0
 */
public class TankLevelListMap {

	/**
	 * TankLevelList 목록
	 */
	private LinkedHashMap<String, TankLevelList> tankLevelLists;
	
	/**
	 * 전체 건수
	 */
	private String totalRowCount;
	
	/**
	 * 디폴트 생성자
	 */
	public TankLevelListMap(){
		if (tankLevelLists == null) {
			tankLevelLists = new LinkedHashMap<String, TankLevelList>();
		}
	}
	
	/**
	 * @return LinkedHashMap
	 */
	public LinkedHashMap<String, TankLevelList> getTankLevelLists(){
		return tankLevelLists;
	}
	
	/**
	 * @param tankLevelLists
	 */
	public void setTankLevelLists(LinkedHashMap<String, TankLevelList> tankLevelLists){
		this.tankLevelLists = tankLevelLists;
	}
	
	/**
	 * @param id
	 * @return TankLevelList
	 */
	public TankLevelList getTankLevelList(String id){
		return this.tankLevelLists.get(id);
	}
	
	/**
	 * @param id
	 * @param tankLevelList
	 */
	public void setTankLevelList(String id, TankLevelList tankLevelList){
		this.tankLevelLists.put(id, tankLevelList);
	}
	
	/**
	 * @param tankLevelList
	 */
	public void setTankLevelList(TankLevelList tankLevelList){
		this.tankLevelLists.put(tankLevelList.getKeyValue(), tankLevelList);
	}
	
	/**
	 * @param id
	 */
	public void removeTankLevelList(String id){
		this.tankLevelLists.remove(id);
	}
	
	/**
	 * @return the totalRowCount
	 */
	public String getTotalRowCount() {
		return totalRowCount;
	}

	/**
	 * @param totalRowCount the totalRowCount to set
	 */
	public void setTotalRowCount(String totalRowCount) {
		this.totalRowCount = totalRowCount;
	}

	/**
	 * @param id
	 * @return 키에 해당하는 값의 존재 여부를 반환
	 */
	public boolean isExist(String id){
		return  this.tankLevelLists.get(id)==null?false:true;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return tankLevelLists.toString();
	}
	
	/**
	 * @return XML
	 */
	public String toXML(){
		String xml = "<TankLevelLists>";
				
		java.util.Iterator<String> iterator = tankLevelLists.keySet().iterator(); 
		
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			xml += tankLevelLists.get(key).toXML();
		  }
		xml += "</TankLevelLists>";
		
		return xml; 
	}

	/**
	 * XML을 페이지로 나눠서 HashMap으로 반환
	 * @param rowCount 한 페이지에 들어갈 행의 개수
	 * @return 페이지로 나눠 XML을 담은 HashMap
	 */
	public HashMap<String, String> toPagingXML(int rowCount){
		int pageNumber = 1;
		int rowNumber = 1;
		int totalRowCount = tankLevelLists.size();
		this.setTotalRowCount("" + totalRowCount);
		HashMap<String, String> pageXML = new HashMap<String, String>();
		java.util.Iterator<String> iterator = tankLevelLists.keySet().iterator(); 
		String xml = "";
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			TankLevelList tankLevelList = tankLevelLists.get(key);
			if (rowNumber < (pageNumber * rowCount)) {
				xml += tankLevelList.toXML();
			} else {
				xml +=  tankLevelList.toXML();
				pageXML.put(new Integer(pageNumber).toString(), "<TankLevelLists>" + new String(xml) + "</TankLevelLists>");
				xml = "";
				pageNumber ++;
			}
			rowNumber ++;
		}
		if (!"".equals(xml)){
			pageXML.put(new Integer(pageNumber).toString(),  "<TankLevelLists>" + new String(xml) + "</TankLevelLists>");
		}
		return pageXML;
	}
	
	/**
	 * @return JSON
	 */
	public String toJSON(){
		String json = "\"tankLevelLists\":[";
				
		java.util.Iterator<String> iterator = tankLevelLists.keySet().iterator(); 
		while (iterator.hasNext()) { 
			String key = iterator.next();
			json += tankLevelLists.get(key).toJSON();
			
			if (iterator.hasNext()) {
				json += ",";
			}
		  }
		json += "]";
		
		return json; 
	}
}
