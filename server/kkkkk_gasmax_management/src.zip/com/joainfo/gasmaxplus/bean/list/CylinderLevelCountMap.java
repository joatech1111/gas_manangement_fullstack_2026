package com.joainfo.gasmaxplus.bean.list;


import java.util.HashMap;
import java.util.LinkedHashMap;

import com.joainfo.gasmaxplus.bean.CylinderLevelCount;

/**
 * 주간수신 집계정보의 해시 집합
 * @author 네오브랜딩
 * @version 1.0
 */
public class CylinderLevelCountMap {

	/**
	 * Cylinder 목록
	 */
	private LinkedHashMap<String, CylinderLevelCount> cylinderLevelCounts;
	
	/**
	 * 전체 건수
	 */
	private String totalRowCount;
	
	/**
	 * 디폴트 생성자
	 */
	public CylinderLevelCountMap(){
		if (cylinderLevelCounts == null) {
			cylinderLevelCounts = new LinkedHashMap<String, CylinderLevelCount>();
		}
	}
	
	/**
	 * @return LinkedHashMap
	 */
	public LinkedHashMap<String, CylinderLevelCount> getCylinderLevelCounts(){
		return cylinderLevelCounts;
	}
	
	/**
	 * @param cylinderLevelCounts
	 */
	public void setCylinderLevelCount(LinkedHashMap<String, CylinderLevelCount> cylinderLevelCounts){
		this.cylinderLevelCounts = cylinderLevelCounts;
	}
	
	/**
	 * @param id
	 * @return CylinderLevelCount
	 */
	public CylinderLevelCount getCylinderLevelCount(String id){
		return this.cylinderLevelCounts.get(id);
	}
	
	/**
	 * @param id
	 * @param CylinderLevelCount
	 */
	public void setCylinderLevelCount(String id, CylinderLevelCount cylinderLevelCount){
		this.cylinderLevelCounts.put(id, cylinderLevelCount);
	}
	
	/**
	 * @param CylinderLevelCount
	 */
	public void setCylinderLevelCount(CylinderLevelCount cylinderLevelCount){
		this.cylinderLevelCounts.put(cylinderLevelCount.getKeyValue(), cylinderLevelCount);
	}
	
	/**
	 * @param id
	 */
	public void removeCylinderLevelCount(String id){
		this.cylinderLevelCounts.remove(id);
	}
	
	/**
	 * @return the totalRowCount
	 */
	public String getTotalRowCount() {
		return totalRowCount;
	}

	/**
	 * @param totalRowCount the totalRowCount to set
	 */
	public void setTotalRowCount(String totalRowCount) {
		this.totalRowCount = totalRowCount;
	}

	/**
	 * @param id
	 * @return 키에 해당하는 값의 존재 여부를 반환
	 */
	public boolean isExist(String id){
		return  this.cylinderLevelCounts.get(id)==null?false:true;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return cylinderLevelCounts.toString();
	}
	
	/**
	 * @return XML
	 */
	public String toXML(){
		String xml = "<CylinderLevelCounts>";
				
		java.util.Iterator<String> iterator = cylinderLevelCounts.keySet().iterator(); 
		
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			xml += cylinderLevelCounts.get(key).toXML();
		  }
		xml += "</CylinderLevelCounts>";
		
		return xml; 
	}

	/**
	 * XML을 페이지로 나눠서 HashMap으로 반환
	 * @param rowCount 한 페이지에 들어갈 행의 개수
	 * @return 페이지로 나눠 XML을 담은 HashMap
	 */
	public HashMap<String, String> toPagingXML(int rowCount){
		int pageNumber = 1;
		int rowNumber = 1;
		int totalRowCount = cylinderLevelCounts.size();
		this.setTotalRowCount("" + totalRowCount);
		HashMap<String, String> pageXML = new HashMap<String, String>();
		java.util.Iterator<String> iterator = cylinderLevelCounts.keySet().iterator(); 
		String xml = "";
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			CylinderLevelCount CylinderLevelCount = cylinderLevelCounts.get(key);
			if (rowNumber < (pageNumber * rowCount)) {
				xml += CylinderLevelCount.toXML();
			} else {
				xml +=  CylinderLevelCount.toXML();
				pageXML.put(new Integer(pageNumber).toString(), "<CylinderLevelCounts>" + new String(xml) + "</CylinderLevelCounts>");
				xml = "";
				pageNumber ++;
			}
			rowNumber ++;
		}
		if (!"".equals(xml)){
			pageXML.put(new Integer(pageNumber).toString(),  "<CylinderLevelCounts>" + new String(xml) + "</CylinderLevelCounts>");
		}
		return pageXML;
	}

	/**
	 * @return JSON
	 */
	public String toJSON(){
		String json = "\"CylinderLevelCounts\":[";
				
		java.util.Iterator<String> iterator = cylinderLevelCounts.keySet().iterator(); 
		while (iterator.hasNext()) { 
			String key = iterator.next();
			json += cylinderLevelCounts.get(key).toJSON();
			
			if (iterator.hasNext()) {
				json += ",";
			}
		  }
		json += "]";
		
		return json; 
	}
}
