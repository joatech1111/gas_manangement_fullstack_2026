package com.joainfo.gasmaxplus.bean.list;

import java.util.HashMap;
import java.util.LinkedHashMap;

import com.joainfo.gasmaxplus.bean.CylinderDetailList;

/**
 * 절체기 상세내역 정보의 해시 집합
 * @author 네오브랜딩
 * @version 1.0
 */
public class CylinderDetailListMap {

	/**
	 * CylinderDetailList 목록
	 */
	private LinkedHashMap<String, CylinderDetailList> cylinderDetailLists;

	/**
	 * 전체 건수
	 */
	private String totalRowCount;
	
	/**
	 * 디폴트 생성자
	 */
	public CylinderDetailListMap(){
		if (cylinderDetailLists == null) {
			cylinderDetailLists = new LinkedHashMap<String, CylinderDetailList>();
		}
	}
	
	/**
	 * @return LinkedHashMap
	 */
	public LinkedHashMap<String, CylinderDetailList> getCylinderDetailLists(){
		return cylinderDetailLists;
	}
	
	/**
	 * @param cylinderDetailLists
	 */
	public void setCylinderDetailLists(LinkedHashMap<String, CylinderDetailList> cylinderDetailLists){
		this.cylinderDetailLists = cylinderDetailLists;
	}
	
	/**
	 * @param id
	 * @return CylinderDetailList
	 */
	public CylinderDetailList getCylinderDetailList(String id){
		return this.cylinderDetailLists.get(id);
	}
	
	/**
	 * @param id
	 * @param cylinderDetailList
	 */
	public void setCylinderDetailList(String id, CylinderDetailList cylinderDetailList){
		this.cylinderDetailLists.put(id, cylinderDetailList);
	}
	
	/**
	 * @param cylinderDetailList
	 */
	public void setCylinderDetailList(CylinderDetailList cylinderDetailList){
		this.cylinderDetailLists.put(cylinderDetailList.getKeyValue(), cylinderDetailList);
	}
	
	/**
	 * @param id
	 */
	public void removeCylinderDetailList(String id){
		this.cylinderDetailLists.remove(id);
	}
	
	/**
	 * @param id
	 * @return 키에 해당하는 값의 존재 여부를 반환
	 */
	public boolean isExist(String id){
		return  this.cylinderDetailLists.get(id)==null?false:true;
	}
	
	/**
	 * @return the totalRowCount
	 */
	public String getTotalRowCount() {
		return totalRowCount;
	}

	/**
	 * @param totalRowCount the totalRowCount to set
	 */
	public void setTotalRowCount(String totalRowCount) {
		this.totalRowCount = totalRowCount;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return cylinderDetailLists.toString();
	}
	
	/**
	 * @return XML
	 */
	public String toXML(){
		String xml = "<CylinderDetailLists>";
				
		java.util.Iterator<String> iterator = cylinderDetailLists.keySet().iterator(); 
		
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			xml += cylinderDetailLists.get(key).toXML();
		  }
		xml += "</CylinderDetailLists>";
		
		return xml; 
	}

	/**
	 * XML을 페이지로 나눠서 HashMap으로 반환
	 * @param rowCount 한 페이지에 들어갈 행의 개수
	 * @return 페이지로 나눠 XML을 담은 HashMap
	 */
	public HashMap<String, String> toPagingXML(int rowCount){
		int pageNumber = 1;
		int rowNumber = 1;
		int totalRowCount = cylinderDetailLists.size();
		this.setTotalRowCount("" + totalRowCount);
		HashMap<String, String> pageXML = new HashMap<String, String>();
		java.util.Iterator<String> iterator = cylinderDetailLists.keySet().iterator(); 
		String xml = "";
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			CylinderDetailList cylinderDetailList = cylinderDetailLists.get(key);
			if (rowNumber < (pageNumber * rowCount)) {
				xml += cylinderDetailList.toXML();
			} else {
				xml +=  cylinderDetailList.toXML();
				pageXML.put(new Integer(pageNumber).toString(), "<CylinderDetailLists>" + new String(xml) + "</CylinderDetailLists>");
				xml = "";
				pageNumber ++;
			}
			rowNumber ++;
		}
		if (!"".equals(xml)){
			pageXML.put(new Integer(pageNumber).toString(),  "<CylinderDetailLists>" + new String(xml) + "</CylinderDetailLists>");
		}
		return pageXML;
	}
	
}
