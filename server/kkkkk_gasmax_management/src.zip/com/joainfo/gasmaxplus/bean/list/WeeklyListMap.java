package com.joainfo.gasmaxplus.bean.list;


import java.util.HashMap;
import java.util.LinkedHashMap;

import com.joainfo.gasmaxplus.bean.WeeklyList;

/**
 * 주간수신내역 정보의 해시 집합
 * @author 백원태
 * @version 1.0
 */
public class WeeklyListMap {

	/**
	 * WeeklyList 목록
	 */
	private LinkedHashMap<String, WeeklyList> weeklyLists;
	
	/**
	 * 전체 건수
	 */
	private String totalRowCount;
	
	/**
	 * 디폴트 생성자
	 */
	public WeeklyListMap(){
		if (weeklyLists == null) {
			weeklyLists = new LinkedHashMap<String, WeeklyList>();
		}
	}
	
	/**
	 * @return LinkedHashMap
	 */
	public LinkedHashMap<String, WeeklyList> getWeeklyLists(){
		return weeklyLists;
	}
	
	/**
	 * @param weeklyLists
	 */
	public void setWeeklyLists(LinkedHashMap<String, WeeklyList> weeklyLists){
		this.weeklyLists = weeklyLists;
	}
	
	/**
	 * @param id
	 * @return WeeklyList
	 */
	public WeeklyList getWeeklyList(String id){
		return this.weeklyLists.get(id);
	}
	
	/**
	 * @param id
	 * @param weeklyList
	 */
	public void setWeeklyList(String id, WeeklyList weeklyList){
		this.weeklyLists.put(id, weeklyList);
	}
	
	/**
	 * @param weeklyList
	 */
	public void setWeeklyList(WeeklyList weeklyList){
		this.weeklyLists.put(weeklyList.getKeyValue(), weeklyList);
	}
	
	/**
	 * @param id
	 */
	public void removeWeeklyList(String id){
		this.weeklyLists.remove(id);
	}
	
	/**
	 * @return the totalRowCount
	 */
	public String getTotalRowCount() {
		return totalRowCount;
	}

	/**
	 * @param totalRowCount the totalRowCount to set
	 */
	public void setTotalRowCount(String totalRowCount) {
		this.totalRowCount = totalRowCount;
	}

	/**
	 * @param id
	 * @return 키에 해당하는 값의 존재 여부를 반환
	 */
	public boolean isExist(String id){
		return  this.weeklyLists.get(id)==null?false:true;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return weeklyLists.toString();
	}
	
	/**
	 * @return XML
	 */
	public String toXML(){
		String xml = "<WeeklyLists>";
				
		java.util.Iterator<String> iterator = weeklyLists.keySet().iterator(); 
		
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			xml += weeklyLists.get(key).toXML();
		  }
		xml += "</WeeklyLists>";
		
		return xml; 
	}

	/**
	 * XML을 페이지로 나눠서 HashMap으로 반환
	 * @param rowCount 한 페이지에 들어갈 행의 개수
	 * @return 페이지로 나눠 XML을 담은 HashMap
	 */
	public HashMap<String, String> toPagingXML(int rowCount){
		int pageNumber = 1;
		int rowNumber = 1;
		int totalRowCount = weeklyLists.size();
		this.setTotalRowCount("" + totalRowCount);
		HashMap<String, String> pageXML = new HashMap<String, String>();
		java.util.Iterator<String> iterator = weeklyLists.keySet().iterator(); 
		String xml = "";
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			WeeklyList weeklyList = weeklyLists.get(key);
			if (rowNumber < (pageNumber * rowCount)) {
				xml += weeklyList.toXML();
			} else {
				xml +=  weeklyList.toXML();
				pageXML.put(new Integer(pageNumber).toString(), "<WeeklyLists>" + new String(xml) + "</WeeklyLists>");
				xml = "";
				pageNumber ++;
			}
			rowNumber ++;
		}
		if (!"".equals(xml)){
			pageXML.put(new Integer(pageNumber).toString(),  "<WeeklyLists>" + new String(xml) + "</WeeklyLists>");
		}
		return pageXML;
	}
	
}
