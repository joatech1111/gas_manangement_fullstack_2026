package com.joainfo.gasmaxplus.bean.list;


import java.util.HashMap;
import java.util.LinkedHashMap;

import com.joainfo.gasmaxplus.bean.CheckVolumeLevelCount;

/**
 * 원격검침 집계정보의 해시 집합
 * @author 네오브랜딩
 * @version 1.0
 */
public class CheckVolumeLevelCountMap {

	/**
	 * CheckVolumeLevelCount 목록
	 */
	private LinkedHashMap<String, CheckVolumeLevelCount> checkVolumeLevelCounts;
	
	/**
	 * 전체 건수
	 */
	private String totalRowCount;
	
	/**
	 * 디폴트 생성자
	 */
	public CheckVolumeLevelCountMap(){
		if (checkVolumeLevelCounts == null) {
			checkVolumeLevelCounts = new LinkedHashMap<String, CheckVolumeLevelCount>();
		}
	}
	
	/**
	 * @return LinkedHashMap
	 */
	public LinkedHashMap<String, CheckVolumeLevelCount> getCheckVolumeLevelCounts(){
		return checkVolumeLevelCounts;
	}
	
	/**
	 * @param checkVolumeLevelCounts
	 */
	public void setCheckVolumeLevelCount(LinkedHashMap<String, CheckVolumeLevelCount> checkVolumeLevelCounts){
		this.checkVolumeLevelCounts = checkVolumeLevelCounts;
	}
	
	/**
	 * @param id
	 * @return CheckVolumeLevelCount
	 */
	public CheckVolumeLevelCount getCheckVolumeLevelCount(String id){
		return this.checkVolumeLevelCounts.get(id);
	}
	
	/**
	 * @param id
	 * @param CheckVolumeLevelCount
	 */
	public void setCheckVolumeLevelCount(String id, CheckVolumeLevelCount CheckVolumeLevelCount){
		this.checkVolumeLevelCounts.put(id, CheckVolumeLevelCount);
	}
	
	/**
	 * @param CheckVolumeLevelCount
	 */
	public void setCheckVolumeLevelCount(CheckVolumeLevelCount CheckVolumeLevelCount){
		this.checkVolumeLevelCounts.put(CheckVolumeLevelCount.getKeyValue(), CheckVolumeLevelCount);
	}
	
	/**
	 * @param id
	 */
	public void removeCheckVolumeLevelCount(String id){
		this.checkVolumeLevelCounts.remove(id);
	}
	
	/**
	 * @return the totalRowCount
	 */
	public String getTotalRowCount() {
		return totalRowCount;
	}

	/**
	 * @param totalRowCount the totalRowCount to set
	 */
	public void setTotalRowCount(String totalRowCount) {
		this.totalRowCount = totalRowCount;
	}

	/**
	 * @param id
	 * @return 키에 해당하는 값의 존재 여부를 반환
	 */
	public boolean isExist(String id){
		return  this.checkVolumeLevelCounts.get(id)==null?false:true;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return checkVolumeLevelCounts.toString();
	}
	
	/**
	 * @return XML
	 */
	public String toXML(){
		String xml = "<CheckVolumeLevelCounts>";
				
		java.util.Iterator<String> iterator = checkVolumeLevelCounts.keySet().iterator(); 
		
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			xml += checkVolumeLevelCounts.get(key).toXML();
		  }
		xml += "</CheckVolumeLevelCounts>";
		
		return xml; 
	}

	/**
	 * XML을 페이지로 나눠서 HashMap으로 반환
	 * @param rowCount 한 페이지에 들어갈 행의 개수
	 * @return 페이지로 나눠 XML을 담은 HashMap
	 */
	public HashMap<String, String> toPagingXML(int rowCount){
		int pageNumber = 1;
		int rowNumber = 1;
		int totalRowCount = checkVolumeLevelCounts.size();
		this.setTotalRowCount("" + totalRowCount);
		HashMap<String, String> pageXML = new HashMap<String, String>();
		java.util.Iterator<String> iterator = checkVolumeLevelCounts.keySet().iterator(); 
		String xml = "";
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			CheckVolumeLevelCount CheckVolumeLevelCount = checkVolumeLevelCounts.get(key);
			if (rowNumber < (pageNumber * rowCount)) {
				xml += CheckVolumeLevelCount.toXML();
			} else {
				xml +=  CheckVolumeLevelCount.toXML();
				pageXML.put(new Integer(pageNumber).toString(), "<CheckVolumeLevelCounts>" + new String(xml) + "</CheckVolumeLevelCounts>");
				xml = "";
				pageNumber ++;
			}
			rowNumber ++;
		}
		if (!"".equals(xml)){
			pageXML.put(new Integer(pageNumber).toString(),  "<CheckVolumeLevelCounts>" + new String(xml) + "</CheckVolumeLevelCounts>");
		}
		return pageXML;
	}

	/**
	 * @return JSON
	 */
	public String toJSON(){
		String json = "\"CheckVolumeLevelCounts\":[";
				
		java.util.Iterator<String> iterator = checkVolumeLevelCounts.keySet().iterator(); 
		while (iterator.hasNext()) { 
			String key = iterator.next();
			json += checkVolumeLevelCounts.get(key).toJSON();
			
			if (iterator.hasNext()) {
				json += ",";
			}
		  }
		json += "]";
		
		return json; 
	}
}
