package com.joainfo.gasmaxplus.bean.list;


import java.util.HashMap;
import java.util.LinkedHashMap;

import com.joainfo.gasmaxplus.bean.CustomerTankDetailList;

/**
 * 거래처 탱크 잔량 상세내역 정보의 해시 집합
 * @author 백원태
 * @version 1.0
 */
public class CustomerTankDetailListMap {

	/**
	 * CustomerTankDetailList 목록
	 */
	private LinkedHashMap<String, CustomerTankDetailList> customerTankDetailLists;

	/**
	 * 전체 건수
	 */
	private String totalRowCount;
	
	/**
	 * 디폴트 생성자
	 */
	public CustomerTankDetailListMap(){
		if (customerTankDetailLists == null) {
			customerTankDetailLists = new LinkedHashMap<String, CustomerTankDetailList>();
		}
	}
	
	/**
	 * @return LinkedHashMap
	 */
	public LinkedHashMap<String, CustomerTankDetailList> getCustomerTankDetailLists(){
		return customerTankDetailLists;
	}
	
	/**
	 * @param customerTankDetailLists
	 */
	public void setCustomerTankDetailLists(LinkedHashMap<String, CustomerTankDetailList> customerTankDetailLists){
		this.customerTankDetailLists = customerTankDetailLists;
	}
	
	/**
	 * @param id
	 * @return CustomerTankDetailList
	 */
	public CustomerTankDetailList getCustomerTankDetailList(String id){
		return this.customerTankDetailLists.get(id);
	}
	
	/**
	 * @param id
	 * @param customerTankDetailList
	 */
	public void setCustomerTankDetailList(String id, CustomerTankDetailList customerTankDetailList){
		this.customerTankDetailLists.put(id, customerTankDetailList);
	}
	
	/**
	 * @param customerTankDetailList
	 */
	public void setCustomerTankDetailList(CustomerTankDetailList customerTankDetailList){
		this.customerTankDetailLists.put(customerTankDetailList.getKeyValue(), customerTankDetailList);
	}
	
	/**
	 * @param id
	 */
	public void removeCustomerTankDetailList(String id){
		this.customerTankDetailLists.remove(id);
	}
	
	/**
	 * @param id
	 * @return 키에 해당하는 값의 존재 여부를 반환
	 */
	public boolean isExist(String id){
		return  this.customerTankDetailLists.get(id)==null?false:true;
	}
	
	/**
	 * @return the totalRowCount
	 */
	public String getTotalRowCount() {
		return totalRowCount;
	}

	/**
	 * @param totalRowCount the totalRowCount to set
	 */
	public void setTotalRowCount(String totalRowCount) {
		this.totalRowCount = totalRowCount;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return customerTankDetailLists.toString();
	}
	
	/**
	 * @return XML
	 */
	public String toXML(){
		String xml = "<CustomerTankDetailLists>";
				
		java.util.Iterator<String> iterator = customerTankDetailLists.keySet().iterator(); 
		
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			xml += customerTankDetailLists.get(key).toXML();
		  }
		xml += "</CustomerTankDetailLists>";
		
		return xml; 
	}

	/**
	 * XML을 페이지로 나눠서 HashMap으로 반환
	 * @param rowCount 한 페이지에 들어갈 행의 개수
	 * @return 페이지로 나눠 XML을 담은 HashMap
	 */
	public HashMap<String, String> toPagingXML(int rowCount){
		int pageNumber = 1;
		int rowNumber = 1;
		int totalRowCount = customerTankDetailLists.size();
		this.setTotalRowCount("" + totalRowCount);
		HashMap<String, String> pageXML = new HashMap<String, String>();
		java.util.Iterator<String> iterator = customerTankDetailLists.keySet().iterator(); 
		String xml = "";
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			CustomerTankDetailList customerTankDetailList = customerTankDetailLists.get(key);
			if (rowNumber < (pageNumber * rowCount)) {
				xml += customerTankDetailList.toXML();
			} else {
				xml +=  customerTankDetailList.toXML();
				pageXML.put(new Integer(pageNumber).toString(), "<CustomerTankDetailLists>" + new String(xml) + "</CustomerTankDetailLists>");
				xml = "";
				pageNumber ++;
			}
			rowNumber ++;
		}
		if (!"".equals(xml)){
			pageXML.put(new Integer(pageNumber).toString(),  "<CustomerTankDetailLists>" + new String(xml) + "</CustomerTankDetailLists>");
		}
		return pageXML;
	}
	
}
