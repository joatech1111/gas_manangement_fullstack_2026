package com.joainfo.gasmaxplus.bean.list;


import java.util.LinkedHashMap;

import com.joainfo.gasmaxplus.bean.CustomerMap;

/**
 * 거래처 지도(위/경도) 정보의 해시 집합
 * @author 서경엔씨에스
 * @version 1.0
 */
public class CustomerMapMap {

	/**
	 * CustomerMap 목록
	 */
	private LinkedHashMap<String, CustomerMap> customerMaps;
	
	/**
	 * 디폴트 생성자
	 */
	public CustomerMapMap(){
		if (customerMaps == null) {
			customerMaps = new LinkedHashMap<String, CustomerMap>();
		}
	}
	
	/**
	 * @return LinkedHashMap
	 */
	public LinkedHashMap<String, CustomerMap> getCustomerMaps(){
		return customerMaps;
	}
	
	/**
	 * @param customerMaps
	 */
	public void setAppUsers(LinkedHashMap<String, CustomerMap> customerMaps){
		this.customerMaps = customerMaps;
	}
	
	/**
	 * @param id
	 * @return CustomerMap
	 */
	public CustomerMap getCustomerMap(String id){
		return this.customerMaps.get(id);
	}
	
	/**
	 * @param id
	 * @param customerMap
	 */
	public void setCustomerMap(String id, CustomerMap customerMap){
		this.customerMaps.put(id, customerMap);
	}
	
	/**
	 * @param customerMap
	 */
	public void setCustomerMap(CustomerMap customerMap){
		this.customerMaps.put(customerMap.getKeyValue(), customerMap);
	}
	
	/**
	 * @param id
	 */
	public void removeCustomerMap(String id){
		this.customerMaps.remove(id);
	}
	
	/**
	 * @param id
	 * @return 키에 해당하는 값의 존재 여부를 반환
	 */
	public boolean isExist(String id){
		return  this.customerMaps.get(id)==null?false:true;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return customerMaps.toString();
	}
	
	/**
	 * @return XML
	 */
	public String toXML(){
		String xml = "<CustomerMaps>";
				
		java.util.Iterator<String> iterator = customerMaps.keySet().iterator(); 
		
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			xml += customerMaps.get(key).toXML();
		  }
		xml += "</CustomerMaps>";
		
		return xml; 
	}
	
}
