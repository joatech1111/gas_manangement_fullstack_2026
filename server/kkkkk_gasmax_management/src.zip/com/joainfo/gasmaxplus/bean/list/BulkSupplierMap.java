package com.joainfo.gasmaxplus.bean.list;

import java.util.HashMap;
import java.util.LinkedHashMap;

import com.joainfo.gasmaxplus.bean.BulkSupplier;

/**
 * 충전관리 매입처 정보의 해시 집합
 * @author 서경엔씨에스
 * @version 1.0
 */
public class BulkSupplierMap {

	/**
	 * 목록
	 */
	private LinkedHashMap<String, BulkSupplier> mMaps;
	
	/**
	 * 전체 건수
	 */
	private String totalRowCount;
	
	/**
	 * 디폴트 생성자
	 */
	public BulkSupplierMap() {
		if (mMaps == null) {
			mMaps = new LinkedHashMap<String, BulkSupplier>();
		}
	}
	
	/**
	 * @return LinkedHashMap
	 */
	public LinkedHashMap<String, BulkSupplier> getValues() {
		return mMaps;
	}
	
	/**
	 * @param maps
	 */
	public void setValues(LinkedHashMap<String, BulkSupplier> maps) {
		this.mMaps = maps;
	}
	
	/**
	 * @param id
	 * @return value
	 */
	public BulkSupplier getValue(String id) {
		return this.mMaps.get(id);
	}
	
	/**
	 * @param id
	 * @param value
	 */
	public void setValue(String id, BulkSupplier value) {
		this.mMaps.put(id, value);
	}
	
	/**
	 * @param id
	 */
	public void removeValue(String id) {
		this.mMaps.remove(id);
	}
	
	/**
	 * @return the totalRowCount
	 */
	public String getTotalRowCount() {
		return totalRowCount;
	}

	/**
	 * @param totalRowCount the totalRowCount to set
	 */
	public void setTotalRowCount(String totalRowCount) {
		this.totalRowCount = totalRowCount;
	}

	/**
	 * @param id
	 * @return 키에 해당하는 값의 존재 여부를 반환
	 */
	public boolean isExist(String id) {
		return  this.mMaps.containsKey(id);
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return mMaps.toString();
	}
	
	/**
	 * @return XML
	 */
	public String toXML() {
		String xml = "<BulkSuppliers>";
				
		java.util.Iterator<String> iterator = mMaps.keySet().iterator(); 
		
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			xml += mMaps.get(key).toXML();
		}
		xml += "</BulkSuppliers>";
		
		return xml; 
	}

	/**
	 * XML을 페이지로 나눠서 HashMap으로 반환
	 * @param rowCount 한 페이지에 들어갈 행의 개수
	 * @return 페이지로 나눠 XML을 담은 HashMap
	 */
	public HashMap<String, String> toPagingXML(int rowCount) {
		int pageNumber = 1;
		int rowNumber = 1;
		int totalRowCount = mMaps.size();
		this.setTotalRowCount("" + totalRowCount);
		HashMap<String, String> pageXML = new HashMap<String, String>();
		java.util.Iterator<String> iterator = mMaps.keySet().iterator(); 
		String xml = "";
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			BulkSupplier value = mMaps.get(key);
			if (rowNumber < (pageNumber * rowCount)) {
				xml += value.toXML();
			} else {
				xml +=  value.toXML();
				pageXML.put(new Integer(pageNumber).toString(), "<BulkSuppliers>" + new String(xml) + "</BulkSuppliers>");
				xml = "";
				pageNumber ++;
			}
			rowNumber ++;
		}
		if (!"".equals(xml)){
			pageXML.put(new Integer(pageNumber).toString(),  "<BulkSuppliers>" + new String(xml) + "</BulkSuppliers>");
		}
		return pageXML;
	}
}
