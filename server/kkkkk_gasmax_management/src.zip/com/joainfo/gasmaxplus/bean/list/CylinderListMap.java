package com.joainfo.gasmaxplus.bean.list;


import java.util.HashMap;
import java.util.LinkedHashMap;

import com.joainfo.gasmaxplus.bean.CylinderList;

/**
 * 절체기 정보의 해시 집합
 * @author 네오브랜딩
 * @version 1.0
 */
public class CylinderListMap {

	/**
	 * Cylinder 목록
	 */
	private LinkedHashMap<String, CylinderList> cylinderLists;
	
	/**
	 * 전체 건수
	 */
	private String totalRowCount;
	
	/**
	 * 디폴트 생성자
	 */
	public CylinderListMap(){
		if (cylinderLists == null) {
			cylinderLists = new LinkedHashMap<String, CylinderList>();
		}
	}
	
	/**
	 * @return LinkedHashMap
	 */
	public LinkedHashMap<String, CylinderList> getCylinders(){
		return cylinderLists;
	}
	
	/**
	 * @param cylinderLists
	 */
	public void setCylinderLists(LinkedHashMap<String, CylinderList> cylinderLists){
		this.cylinderLists = cylinderLists;
	}
	
	/**
	 * @param id
	 * @return Cylinder
	 */
	public CylinderList getCylinderList(String id){
		return this.cylinderLists.get(id);
	}
	
	/**
	 * @param id
	 * @param cylinderList
	 */
	public void setCylinderList(String id, CylinderList cylinderList){
		this.cylinderLists.put(id, cylinderList);
	}
	
	/**
	 * @param cylinder
	 */
	public void setCylinderList(CylinderList cylinderList){
		this.cylinderLists.put(cylinderList.getKeyValue(), cylinderList);
	}
	
	/**
	 * @param id
	 */
	public void removeCylinderList(String id){
		this.cylinderLists.remove(id);
	}
	
	/**
	 * @return the totalRowCount
	 */
	public String getTotalRowCount() {
		return totalRowCount;
	}

	/**
	 * @param totalRowCount the totalRowCount to set
	 */
	public void setTotalRowCount(String totalRowCount) {
		this.totalRowCount = totalRowCount;
	}

	/**
	 * @param id
	 * @return 키에 해당하는 값의 존재 여부를 반환
	 */
	public boolean isExist(String id){
		return  this.cylinderLists.get(id)==null?false:true;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return cylinderLists.toString();
	}
	
	/**
	 * @return XML
	 */
	public String toXML(){
		String xml = "<CylinderLists>";
				
		java.util.Iterator<String> iterator = cylinderLists.keySet().iterator(); 
		
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			xml += cylinderLists.get(key).toXML();
		  }
		xml += "</CylinderLists>";
		
		return xml; 
	}

	/**
	 * XML을 페이지로 나눠서 HashMap으로 반환
	 * @param rowCount 한 페이지에 들어갈 행의 개수
	 * @return 페이지로 나눠 XML을 담은 HashMap
	 */
	public HashMap<String, String> toPagingXML(int rowCount){
		int pageNumber = 1;
		int rowNumber = 1;
		int totalRowCount = cylinderLists.size();
		this.setTotalRowCount("" + totalRowCount);
		HashMap<String, String> pageXML = new HashMap<String, String>();
		java.util.Iterator<String> iterator = cylinderLists.keySet().iterator(); 
		String xml = "";
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			CylinderList cylinderList = cylinderLists.get(key);
			if (rowNumber < (pageNumber * rowCount)) {
				xml += cylinderList.toXML();
			} else {
				xml +=  cylinderList.toXML();
				pageXML.put(new Integer(pageNumber).toString(), "<CylinderLists>" + new String(xml) + "</CylinderLists>");
				xml = "";
				pageNumber ++;
			}
			rowNumber ++;
		}
		if (!"".equals(xml)){
			pageXML.put(new Integer(pageNumber).toString(),  "<CylinderLists>" + new String(xml) + "</CylinderLists>");
		}
		return pageXML;
	}
}
