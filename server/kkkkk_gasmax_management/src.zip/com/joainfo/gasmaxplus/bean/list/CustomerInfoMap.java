package com.joainfo.gasmaxplus.bean.list;


import java.util.LinkedHashMap;

import com.joainfo.gasmaxplus.bean.CustomerInfo;

/**
 * 앱 거래처 정보의 해시 집합
 * @author 네오브랜딩
 * @version 1.0
 */
public class CustomerInfoMap {

	/**
	 * CustomerInfo 목록
	 */
	private LinkedHashMap<String, CustomerInfo> customerInfos;
	
	/**
	 * 디폴트 생성자
	 */
	public CustomerInfoMap(){
		if (customerInfos == null) {
			customerInfos = new LinkedHashMap<String, CustomerInfo>();
		}
	}
	
	/**
	 * @return LinkedHashMap
	 */
	public LinkedHashMap<String, CustomerInfo> getCustomerInfos(){
		return customerInfos;
	}
	
	/**
	 * @param customerInfos
	 */
	public void setCustomerInfos(LinkedHashMap<String, CustomerInfo> customerInfos){
		this.customerInfos = customerInfos;
	}
	
	/**
	 * @param id
	 * @return CustomerInfo
	 */
	public CustomerInfo getCustomerInfo(String id){
		return this.customerInfos.get(id);
	}
	
	/**
	 * @param id
	 * @param customerInfo
	 */
	public void setCustomerInfo(String id, CustomerInfo customerInfo){
		this.customerInfos.put(id, customerInfo);
	}
	
	/**
	 * @param customerInfo
	 */
	public void setCustomerInfo(CustomerInfo customerInfo){
		this.customerInfos.put(customerInfo.getKeyValue(), customerInfo);
	}
	
	/**
	 * @param id
	 */
	public void removeAppUser(String id){
		this.customerInfos.remove(id);
	}
	
	/**
	 * @param id
	 * @return 키에 해당하는 값의 존재 여부를 반환
	 */
	public boolean isExist(String id){
		return  this.customerInfos.get(id)==null?false:true;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return customerInfos.toString();
	}
	
	/**
	 * @return XML
	 */
	public String toXML(){
		String xml = "<CustomerInfos>";
				
		java.util.Iterator<String> iterator = customerInfos.keySet().iterator(); 
		
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			xml += customerInfos.get(key).toXML();
		  }
		xml += "</CustomerInfos>";
		
		return xml; 
	}
	
}
