package com.joainfo.gasmaxplus.bean.list;


import java.util.HashMap;
import java.util.LinkedHashMap;

import com.joainfo.gasmaxplus.bean.WeeklyListCount;

/**
 * 주간수신 집계정보의 해시 집합
 * @author 네오브랜딩
 * @version 1.0
 */
public class WeeklyListCountMap {

	/**
	 * Cylinder 목록
	 */
	private LinkedHashMap<String, WeeklyListCount> weeklyListCounts;
	
	/**
	 * 전체 건수
	 */
	private String totalRowCount;
	
	/**
	 * 디폴트 생성자
	 */
	public WeeklyListCountMap(){
		if (weeklyListCounts == null) {
			weeklyListCounts = new LinkedHashMap<String, WeeklyListCount>();
		}
	}
	
	/**
	 * @return LinkedHashMap
	 */
	public LinkedHashMap<String, WeeklyListCount> getWeeklyListCounts(){
		return weeklyListCounts;
	}
	
	/**
	 * @param weeklyListCounts
	 */
	public void setWeeklyListCount(LinkedHashMap<String, WeeklyListCount> weeklyListCounts){
		this.weeklyListCounts = weeklyListCounts;
	}
	
	/**
	 * @param id
	 * @return WeeklyListCount
	 */
	public WeeklyListCount getWeeklyListCount(String id){
		return this.weeklyListCounts.get(id);
	}
	
	/**
	 * @param id
	 * @param weeklyListCount
	 */
	public void setWeeklyListCount(String id, WeeklyListCount weeklyListCount){
		this.weeklyListCounts.put(id, weeklyListCount);
	}
	
	/**
	 * @param weeklyListCount
	 */
	public void setWeeklyListCount(WeeklyListCount weeklyListCount){
		this.weeklyListCounts.put(weeklyListCount.getKeyValue(), weeklyListCount);
	}
	
	/**
	 * @param id
	 */
	public void removeWeeklyListCount(String id){
		this.weeklyListCounts.remove(id);
	}
	
	/**
	 * @return the totalRowCount
	 */
	public String getTotalRowCount() {
		return totalRowCount;
	}

	/**
	 * @param totalRowCount the totalRowCount to set
	 */
	public void setTotalRowCount(String totalRowCount) {
		this.totalRowCount = totalRowCount;
	}

	/**
	 * @param id
	 * @return 키에 해당하는 값의 존재 여부를 반환
	 */
	public boolean isExist(String id){
		return  this.weeklyListCounts.get(id)==null?false:true;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return weeklyListCounts.toString();
	}
	
	/**
	 * @return XML
	 */
	public String toXML(){
		String xml = "<Cylinders>";
				
		java.util.Iterator<String> iterator = weeklyListCounts.keySet().iterator(); 
		
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			xml += weeklyListCounts.get(key).toXML();
		  }
		xml += "</Cylinders>";
		
		return xml; 
	}

	/**
	 * XML을 페이지로 나눠서 HashMap으로 반환
	 * @param rowCount 한 페이지에 들어갈 행의 개수
	 * @return 페이지로 나눠 XML을 담은 HashMap
	 */
	public HashMap<String, String> toPagingXML(int rowCount){
		int pageNumber = 1;
		int rowNumber = 1;
		int totalRowCount = weeklyListCounts.size();
		this.setTotalRowCount("" + totalRowCount);
		HashMap<String, String> pageXML = new HashMap<String, String>();
		java.util.Iterator<String> iterator = weeklyListCounts.keySet().iterator(); 
		String xml = "";
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			WeeklyListCount weeklyListCount = weeklyListCounts.get(key);
			if (rowNumber < (pageNumber * rowCount)) {
				xml += weeklyListCount.toXML();
			} else {
				xml +=  weeklyListCount.toXML();
				pageXML.put(new Integer(pageNumber).toString(), "<WeeklyListCounts>" + new String(xml) + "</WeeklyListCounts>");
				xml = "";
				pageNumber ++;
			}
			rowNumber ++;
		}
		if (!"".equals(xml)){
			pageXML.put(new Integer(pageNumber).toString(),  "<WeeklyListCounts>" + new String(xml) + "</WeeklyListCounts>");
		}
		return pageXML;
	}

	/**
	 * @return JSON
	 */
	public String toJSON(){
		String json = "\"WeeklyListCountLists\":[";
				
		java.util.Iterator<String> iterator = weeklyListCounts.keySet().iterator(); 
		while (iterator.hasNext()) { 
			String key = iterator.next();
			json += weeklyListCounts.get(key).toJSON();
			
			if (iterator.hasNext()) {
				json += ",";
			}
		  }
		json += "]";
		
		return json; 
	}
}
