package com.joainfo.gasmaxplus.bean.list;


import java.util.HashMap;
import java.util.LinkedHashMap;

import com.joainfo.gasmaxplus.bean.CheckVolumeDetailList;

/**
 *체적검침 상세내역 정보의 해시 집합
 * @author 백원태
 * @version 1.0
 */
public class CheckVolumeDetailListMap {

	/**
	 * CheckVolumeDetailList 목록
	 */
	private LinkedHashMap<String, CheckVolumeDetailList> checkVolumeDetailLists;

	/**
	 * 전체 건수
	 */
	private String totalRowCount;
	
	/**
	 * 디폴트 생성자
	 */
	public CheckVolumeDetailListMap(){
		if (checkVolumeDetailLists == null) {
			checkVolumeDetailLists = new LinkedHashMap<String, CheckVolumeDetailList>();
		}
	}
	
	/**
	 * @return LinkedHashMap
	 */
	public LinkedHashMap<String, CheckVolumeDetailList> getCheckVolumeDetailLists(){
		return checkVolumeDetailLists;
	}
	
	/**
	 * @param checkVolumeDetailLists
	 */
	public void setCheckVolumeDetailLists(LinkedHashMap<String, CheckVolumeDetailList> checkVolumeDetailLists){
		this.checkVolumeDetailLists = checkVolumeDetailLists;
	}
	
	/**
	 * @param id
	 * @return CheckVolumeDetailList
	 */
	public CheckVolumeDetailList getCheckVolumeDetailList(String id){
		return this.checkVolumeDetailLists.get(id);
	}
	
	/**
	 * @param id
	 * @param checkVolumeDetailList
	 */
	public void setCheckVolumeDetailList(String id, CheckVolumeDetailList checkVolumeDetailList){
		this.checkVolumeDetailLists.put(id, checkVolumeDetailList);
	}
	
	/**
	 * @param checkVolumeDetailList
	 */
	public void setCheckVolumeDetailList(CheckVolumeDetailList checkVolumeDetailList){
		this.checkVolumeDetailLists.put(checkVolumeDetailList.getKeyValue(), checkVolumeDetailList);
	}
	
	/**
	 * @param id
	 */
	public void removeCheckVolumeDetailList(String id){
		this.checkVolumeDetailLists.remove(id);
	}
	
	/**
	 * @param id
	 * @return 키에 해당하는 값의 존재 여부를 반환
	 */
	public boolean isExist(String id){
		return  this.checkVolumeDetailLists.get(id)==null?false:true;
	}
	
	/**
	 * @return the totalRowCount
	 */
	public String getTotalRowCount() {
		return totalRowCount;
	}

	/**
	 * @param totalRowCount the totalRowCount to set
	 */
	public void setTotalRowCount(String totalRowCount) {
		this.totalRowCount = totalRowCount;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString(){
		return checkVolumeDetailLists.toString();
	}
	
	/**
	 * @return XML
	 */
	public String toXML(){
		String xml = "<CheckVolumeDetailLists>";
				
		java.util.Iterator<String> iterator = checkVolumeDetailLists.keySet().iterator(); 
		
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			xml += checkVolumeDetailLists.get(key).toXML();
		  }
		xml += "</CheckVolumeDetailLists>";
		
		return xml; 
	}

	/**
	 * XML을 페이지로 나눠서 HashMap으로 반환
	 * @param rowCount 한 페이지에 들어갈 행의 개수
	 * @return 페이지로 나눠 XML을 담은 HashMap
	 */
	public HashMap<String, String> toPagingXML(int rowCount){
		int pageNumber = 1;
		int rowNumber = 1;
		int totalRowCount = checkVolumeDetailLists.size();
		this.setTotalRowCount("" + totalRowCount);
		HashMap<String, String> pageXML = new HashMap<String, String>();
		java.util.Iterator<String> iterator = checkVolumeDetailLists.keySet().iterator(); 
		String xml = "";
		while (iterator.hasNext()) { 
			String key = iterator.next(); 
			CheckVolumeDetailList checkVolumeDetailList = checkVolumeDetailLists.get(key);
			if (rowNumber < (pageNumber * rowCount)) {
				xml += checkVolumeDetailList.toXML();
			} else {
				xml +=  checkVolumeDetailList.toXML();
				pageXML.put(new Integer(pageNumber).toString(), "<CheckVolumeDetailLists>" + new String(xml) + "</CheckVolumeDetailLists>");
				xml = "";
				pageNumber ++;
			}
			rowNumber ++;
		}
		if (!"".equals(xml)){
			pageXML.put(new Integer(pageNumber).toString(),  "<CheckVolumeDetailLists>" + new String(xml) + "</CheckVolumeDetailLists>");
		}
		return pageXML;
	}
	
}
