package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 체적검침 상세내역 정보 모델
 * @author 백원태
 * @version 1.0
 */
public class TankAlarmList {
	/**
	 * C_MNG_NO	
	 * 고객번호 - key
	 */
	 private String clientNumber;

	/**
	 * CUST_CODE	
	 * 거래처코드 - key
	 */
	 private String customerCode;
	 
	/**
	 * CUST_NAME	
	 * 거래처명
	 */
	 private String customerName;

	/**
	 * R_DATE	
	 * 수신일자 - key
	 */
	 private String receivedDate;

	/**
	 * R_TIME	
	 * 수신시간 - key
	 */
	 private String receivedTime;
	 
	/**
	 * R_TRANSM_CD	
	 * 발신기코드
	 */
	 private String transmitterCode;

	/**
	 * R_LEVEL	
	 * 레벨
	 */
	 private String level;

	/**
	 * R_EVENT_DIV	
	 * 이벤트
	 */
	 private String eventCode;

	/**
	 * R_BAT	
	 * 배터리 전압
	 */
	 private String batteryVolt;
	 
	 /**
	 * R_ALARM	
	 * 경보기 알람유무 ( '', 0 : 정상  1 : 알람)
	 */
	 private String alarmFlag;

	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap(){
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("C_MNG_NO", getClientNumber());
		keys.put("CUST_CODE", getCustomerCode());
		keys.put("R_DATE", getReceivedDate());
		keys.put("R_TIME", getReceivedTime());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}

	/**
	 * @return the clientNumber
	 */
	public String getClientNumber() {
		return clientNumber;
	}

	/**
	 * @param clientNumber the clientNumber to set
	 */
	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	/**
	 * @return the customerCode
	 */
	public String getCustomerCode() {
		return customerCode;
	}

	/**
	 * @param customerCode the customerCode to set
	 */
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the receivedDate
	 */
	public String getReceivedDate() {
		return receivedDate;
	}

	/**
	 * @param receivedDate the receivedDate to set
	 */
	public void setReceivedDate(String receivedDate) {
		this.receivedDate = receivedDate;
	}

	/**
	 * @return the receivedTime
	 */
	public String getReceivedTime() {
		return receivedTime;
	}

	/**
	 * @param receivedTime the receivedTime to set
	 */
	public void setReceivedTime(String receivedTime) {
		this.receivedTime = receivedTime;
	}

	/**
	 * @return the transmitterCode
	 */
	public String getTransmitterCode() {
		return transmitterCode;
	}

	/**
	 * @param transmitterCode the transmitterCode to set
	 */
	public void setTransmitterCode(String transmitterCode) {
		this.transmitterCode = transmitterCode;
	}

	/**
	 * @return the level
	 */
	public String getLevel() {
		return level;
	}

	/**
	 * @param level the level to set
	 */
	public void setLevel(String level) {
		this.level = level;
	}

	/**
	 * @return the eventCode
	 */
	public String getEventCode() {
		return eventCode;
	}

	/**
	 * @param eventCode the eventCode to set
	 */
	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}

	/**
	 * @return the batteryVolt
	 */
	public String getBatteryVolt() {
		return batteryVolt;
	}

	/**
	 * @param batteryVolt the batteryVolt to set
	 */
	public void setBatteryVolt(String batteryVolt) {
		this.batteryVolt = batteryVolt;
	}

	/**
	 * @return the alarmFlag
	 */
	public String getAlarmFlag() {
		return alarmFlag;
	}

	/**
	 * @param alarmFlag the alarmFlag to set
	 */
	public void setAlarmFlag(String alarmFlag) {
		this.alarmFlag = alarmFlag;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TankAlarmList [key=" + this.getKeyValue() + ", clientNumber="
				+ clientNumber
				+ ", customerCode="
				+ customerCode
				+ ", customerName="
				+ customerName
				+ ", transmitterCode="
				+ transmitterCode
				+ ", receivedDate="
				+ receivedDate
				+ ", receivedTime="
				+ receivedTime
				+ ", level="
				+ level
				+ ", eventCode="
				+ eventCode
				+ ", batteryVolt="
				+ batteryVolt
				+ ", alarmFlag="
				+ alarmFlag + "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<TankAlarmList><key>" + this.getKeyValue() + "</key><clientNumber>"
				+ clientNumber
				+ "</clientNumber><customerCode>"
				+ customerCode
				+ "</customerCode><customerName><![CDATA["
				+ customerName
				+ "]]></customerName><transmitterCode>"
				+ transmitterCode
				+ "</transmitterCode><receivedDate>"
				+ receivedDate
				+ "</receivedDate><receivedTime>"
				+ receivedTime
				+ "</receivedTime><level>"
				+ level
				+ "</level><eventCode>"
				+ eventCode
				+ "</eventCode><batteryVolt>"
				+ batteryVolt + "</batteryVolt><alarmFlag>"
				+ alarmFlag + "</alarmFlag></TankAlarmList>";
	}

}
