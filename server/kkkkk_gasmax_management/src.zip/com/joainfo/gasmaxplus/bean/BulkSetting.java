package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 충전관리 설정 정보 모델
 * @author 서경엔씨에스
 * @version 1.0
 */
public class BulkSetting {
	
	private String clientNumber;
	private String appUser;
	private String regDate;
	private String carCode;
	private String carName;
	private String employeeCode;
	private String employeeName;
	private String carMaxLoadage;
	private String carMaxLoadingRate;
	private String convertRate;
	private String convertRound;

	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap() {
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("MNG_NO", getClientNumber());
		keys.put("APP_USER", getAppUser());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}

	public String getClientNumber() {
		return clientNumber;
	}

	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	public String getAppUser() {
		return appUser;
	}

	public void setAppUser(String appUser) {
		this.appUser = appUser;
	}

	public String getRegDate() {
		return regDate;
	}

	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}

	public String getCarCode() {
		return carCode;
	}

	public void setCarCode(String carCode) {
		this.carCode = carCode;
	}

	public String getCarName() {
		return carName;
	}

	public void setCarName(String carName) {
		this.carName = carName;
	}

	public String getEmployeeCode() {
		return employeeCode;
	}

	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getCarMaxLoadage() {
		return carMaxLoadage;
	}

	public void setCarMaxLoadage(String carMaxLoadage) {
		this.carMaxLoadage = carMaxLoadage;
	}

	public String getCarMaxLoadingRate() {
		return carMaxLoadingRate;
	}

	public void setCarMaxLoadingRate(String carMaxLoadingRate) {
		this.carMaxLoadingRate = carMaxLoadingRate;
	}

	public String getConvertRate() {
		return convertRate;
	}

	public void setConvertRate(String convertRate) {
		this.convertRate = convertRate;
	}

	public String getConvertRound() {
		return convertRound;
	}

	public void setConvertRound(String convertRound) {
		this.convertRound = convertRound;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "BulkSetting [key=" + this.getKeyValue() 
				+ ", clientNumber=" + clientNumber 
				+ ", appUser=" + appUser 
				+ ", regDate=" + regDate
				+ ", carCode=" + carCode
				+ ", carName=" + carName
				+ ", employeeCode=" + employeeCode
				+ ", employeeName=" + employeeName
				+ ", carMaxLoadage=" + carMaxLoadage
				+ ", carMaxLoadingRate=" + carMaxLoadingRate
				+ ", convertRate=" + convertRate
				+ ", convertRound=" + convertRound + "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<BulkSetting><key>" + this.getKeyValue() + "</key><clientNumber>"
				+ clientNumber
				+ "</clientNumber><appUser><![CDATA["
				+ appUser
				+ "]]></appUser><regDate>"
				+ regDate
				+ "</regDate><carCode>"
				+ carCode
				+ "</carCode><carName><![CDATA["
				+ carName
				+ "]]></carName><employeeCode>"
				+ employeeCode
				+ "</employeeCode><employeeName><![CDATA["
				+ employeeName
				+ "]]></employeeName><carMaxLoadage>"
				+ carMaxLoadage
				+ "</carMaxLoadage><carMaxLoadingRate>"
				+ carMaxLoadingRate
				+ "</carMaxLoadingRate><convertRate>"
				+ convertRate
				+ "</convertRate><convertRound>"
				+ convertRound
				+ "</convertRound></BulkSetting>";
	}
}
