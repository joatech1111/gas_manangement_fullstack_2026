package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 체적검침 상세내역 정보 모델
 * @author 백원태
 * @version 1.0
 */
public class CheckVolumeDetailList {
	/**
	 * C_MNG_NO	
	 * 고객번호 - key
	 */
	 private String clientNumber;

	/**
	 * CUST_CODE	
	 * 거래처코드 - key
	 */
	 private String customerCode;

	/**
	 * R_TRANSM_CD	
	 * 발신기코드
	 */
	 private String transmitterCode;

	/**
	 * R_DATE	
	 * 수신일자 - key
	 */
	 private String receiveDate;

	/**
	 * R_TIME	
	 * 수신시간 - key
	 */
	 private String receiveTime;

	/**
	 * R_LEVEL	
	 * 레벨
	 */
	 private String level;

	/**
	 * R_EVENT_DIV	
	 * 이벤트
	 */
	 private String eventCode;

	/**
	 * R_EVENT_DIV_NAME	
	 * 이벤트명칭
	 */
	 private String eventName;

	/**
	 * R_BAT	
	 * 배터리 전압
	 */
	 private String batteryVolt;

	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap(){
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("C_MNG_NO", getClientNumber());
		keys.put("CUSTCODE", getCustomerCode());
		keys.put("R_DATE", getReceiveDate());
		keys.put("R_TIME", getReceiveTime());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}

	/**
	 * @return the clientNumber
	 */
	public String getClientNumber() {
		return clientNumber;
	}

	/**
	 * @param clientNumber the clientNumber to set
	 */
	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	/**
	 * @return the customerCode
	 */
	public String getCustomerCode() {
		return customerCode;
	}

	/**
	 * @param customerCode the customerCode to set
	 */
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	/**
	 * @return the transmitterCode
	 */
	public String getTransmitterCode() {
		return transmitterCode;
	}

	/**
	 * @param transmitterCode the transmitterCode to set
	 */
	public void setTransmitterCode(String transmitterCode) {
		this.transmitterCode = transmitterCode;
	}

	/**
	 * @return the receiveDate
	 */
	public String getReceiveDate() {
		return receiveDate;
	}

	/**
	 * @param receiveDate the receiveDate to set
	 */
	public void setReceiveDate(String receiveDate) {
		this.receiveDate = receiveDate;
	}

	/**
	 * @return the receiveTime
	 */
	public String getReceiveTime() {
		return receiveTime;
	}

	/**
	 * @param receiveTime the receiveTime to set
	 */
	public void setReceiveTime(String receiveTime) {
		this.receiveTime = receiveTime;
	}

	/**
	 * @return the level
	 */
	public String getLevel() {
		return level;
	}

	/**
	 * @param level the level to set
	 */
	public void setLevel(String level) {
		this.level = level;
	}

	/**
	 * @return the eventCode
	 */
	public String getEventCode() {
		return eventCode;
	}

	/**
	 * @param eventCode the eventCode to set
	 */
	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}

	/**
	 * @return the eventName
	 */
	public String getEventName() {
		return eventName;
	}

	/**
	 * @param eventName the eventName to set
	 */
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	/**
	 * @return the batteryVolt
	 */
	public String getBatteryVolt() {
		return eventName;
	}

	/**
	 * @param batteryVolt the batteryVolt to set
	 */
	public void setBatteryVolt(String batteryVolt) {
		this.batteryVolt = batteryVolt;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CheckVolumeDetailList [key=" + this.getKeyValue() + ", clientNumber="
				+ clientNumber
				+ ", customerCode="
				+ customerCode
				+ ", transmitterCode="
				+ transmitterCode
				+ ", receiveDate="
				+ receiveDate
				+ ", receiveTime="
				+ receiveTime
				+ ", level="
				+ level
				+ ", eventCode="
				+ eventCode
				+ ", eventName="
				+ eventName
				+ ", batteryVolt="
				+ batteryVolt + "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<CheckVolumeDetailList><key>" + this.getKeyValue() + "</key><clientNumber>"
				+ clientNumber
				+ "</clientNumber><customerCode>"
				+ customerCode
				+ "</customerCode><transmitterCode>"
				+ transmitterCode
				+ "</transmitterCode><receiveDate>"
				+ receiveDate
				+ "</receiveDate><receiveTime>"
				+ receiveTime
				+ "</receiveTime><level>"
				+ level
				+ "</level><eventCode>"
				+ eventCode
				+ "</eventCode><eventName>"
				+ eventName
				+ "</eventName><batteryVolt>"
				+ batteryVolt + "</batteryVolt></CheckVolumeDetailList>";
	}

}
