package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 주간수신 집계정보 모델
 * @author 네오브랜딩
 * @version 1.0
 */
public class CylinderLevelCount {
	/**
	 * CMNGNO	
	 * 고객번호 - key
	 */
	 private String clientNumber;

	 /**
	 * LVL_STATE_ALL	
	 * 합계
	 */
	 private String levelStateAll;

	 /**
	 * LVL_STATE_FULL	(- 완료)
	 * 긴급
	 */
	 private String levelStateFull;
	 
	/**
	 * LVL_STATE_FAIL	(+ 요청)	
	 * 경보
	 */	 
	 private String levelStateFail;
	 
	 /**
	 * R_DATE_OVER	
	 * 미수신
	 */
	 private String receiveDateOver;
	 
	 /**
	 * DONGIL_YN	
	 * 동일레벨
	 */
	 private String uniformLevel;

	 /**
	 * LOW_BAT	
	 * 배터리
	 */
	 private String lowBattery;
	 
	 /**
	  * AVE_OVER	
	  * 초과
	  */
	 private String aveOver;

	/**
	 * @return the levelStateAll
	 */
	public String getLevelStateAll() {
		return levelStateAll;
	}

	/**
	 * @param levelStateAll the levelStateAll to set
	 */
	public void setLevelStateAll(String levelStateAll) {
		this.levelStateAll = levelStateAll;
	}

	/**
	 * @return the levelStateFull
	 */
	public String getLevelStateFull() {
		return levelStateFull;
	}

	/**
	 * @param levelStateFull the levelStateFull to set
	 */
	public void setLevelStateFull(String levelStateFull) {
		this.levelStateFull = levelStateFull;
	}

	/**
	 * @return the levelStateFail
	 */
	public String getLevelStateFail() {
		return levelStateFail;
	}

	/**
	 * @param levelStateFail the levelStateFail to set
	 */
	public void setLevelStateFail(String levelStateFail) {
		this.levelStateFail = levelStateFail;
	}

	/**
	 * @return the receiveDateOver
	 */
	public String getReceiveDateOver() {
		return receiveDateOver;
	}

	/**
	 * @param receiveDateOver the receiveDateOver to set
	 */
	public void setReceiveDateOver(String receiveDateOver) {
		this.receiveDateOver = receiveDateOver;
	}

	/**
	 * @return the uniformLevel
	 */
	public String getUniformLevel() {
		return uniformLevel;
	}

	/**
	 * @param uniformLevel the uniformLevel to set
	 */
	public void setUniformLevel(String uniformLevel) {
		this.uniformLevel = uniformLevel;
	}

	/**
	 * @return the lowBattery
	 */
	public String getLowBattery() {
		return lowBattery;
	}

	/**
	 * @param lowBattery the lowBattery to set
	 */
	public void setLowBattery(String lowBattery) {
		this.lowBattery = lowBattery;
	}
	
	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap(){
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("C_MNG_NO", getClientNumber());
		
		return keys; 
	}

	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}	
	
	/**
	 * @return the clientNumber
	 */
	public String getClientNumber() {
		return clientNumber;
	}

	/**
	 * @param clientNumber the clientNumber to set
	 */
	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}
	
	public String getAveOver() {
		return aveOver;
	}

	public void setAveOver(String aveOver) {
		this.aveOver = aveOver;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CylinderLevelCount [key=" + this.getKeyValue()
				+ ", clientNumber=" + clientNumber
				+ ", levelStateAll=" + levelStateAll
				+ ", levelStateFull=" + levelStateFull
				+ ", levelStateFail="	+ levelStateFail
				+ ", receiveDateOver="	+ receiveDateOver
				+ ", uniformLevel=" + uniformLevel
				+ ", lowBattery=" + lowBattery
				+ ", aveOver=" + aveOver
				+ "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<CylinderLevelCount><key>" + this.getKeyValue() + "</key><clientNumber>" 
				+ clientNumber + "</clientNumber><levelStateAll>"
				+ levelStateAll + "</levelStateAll><levelStateFull>"
				+ levelStateFull + "</levelStateFull><levelStateFail>"
				+ levelStateFail + "</levelStateFail><receiveDateOver>"
				+ receiveDateOver + "</receiveDateOver><uniformLevel>"
				+ uniformLevel + "</uniformLevel><lowBattery>"
				+ lowBattery + "</lowBattery><aveOver>"
				+ aveOver + "</aveOver></CylinderLevelCount>";
	}
	
	/**
	 * JSON 문자열 반환
	 * @return JSON
	 */
	public String toJSON() {
		return "{\"key\":\"" + this.getKeyValue()
				+ "\", \"levelStateAll\":\"" + levelStateAll
				+ "\", \"levelStateFull\":\"" + levelStateFull
				+ "\", \"levelStateFail\":\""	+ levelStateFail
				+ "\", \"receiveDateOver\":\""	+ receiveDateOver
				+ "\", \"uniformLevel\":\"" + uniformLevel
				+ "\", \"lowBattery\":\"" + lowBattery
				+ "\", \"aveOver\":\"" + aveOver
				+ "\"}";
	}		
}
