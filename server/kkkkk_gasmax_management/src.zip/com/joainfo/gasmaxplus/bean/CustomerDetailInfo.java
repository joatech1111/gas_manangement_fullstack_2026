package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 거래처 정보
 * @author 네오브랜딩
 * @version 1.0
 */

public class CustomerDetailInfo {
	/**
	 * 업체코드 - key
	 */
	private String clientNumber;

	/**
	 * 거래처 코드 - key
	 */
	private String customerCode;

	/**
	 * 거래처명
	 */
	private String customerName;

	/**
	 * 기초검침
	 */
	private String custCount;
	
	/**
	 * 전화번호1
	 */
	private String custTel;
	
	/**
	 * 전화번호2
	 */
	private String custHp;
	
	/**
	 * 우편번호
	 */
	private String zipCd;
	
	/**
	 * 주소
	 */
	private String addr1;
	
	/**
	 * 상세주소
	 */
	private String addr2;
	
	/**
	 * 주소 좌표(위도)
	 */
	private String gpsX;
	
	/**
	 * 주소 좌표(경도)
	 */
	private String gpsY;
	
	/**
	 * 담당사원코드
	 */
	private String swCode;
	
	/**
	 * 담당사원명
	 */
	private String swName;
	
	/**
	 * 지역분류코드
	 */
	private String cAreaCode;
	
	/**
	 * 지역분류명
	 */
	private String cAreaName;
	
	/**
	 * 발신기코드
	 */
	private String transmCd;
	
	/**
	 * 집합구분(0:용기,1:탱크)
	 */
	private String cType;
	
	/**
	 * 탱크용량
	 */
	private String tankVol;
	
	/**
	 * 사용품목 용량
	 */
	private String cVol;
	
	/**
	 * 사용품목 수량
	 */
	private String cQty;
	
	/**
	 * 비고
	 */
	private String remark;
	
	 /**
	  * LAST_R_DATE 
	  * 마지막수신일자 
	  */
	 private String lastRdate;
	 
	 /**
	  * E2_DATE_1
	  * 마지막 젗제 완료  
	  */
	 private String  e2Date1;

	 /**
	  * E2_AVE_DATE
	  * 평균 사용일   
	  */
	 private String  e2AveDate;

	 /**
	  * E2_AVE_METER
	  * 평균 사용량    
	  */
	 private String  e2AveMeter;
	
	 /**
	  * E2_AVE_METER
	  * 평균 사용량    
	  */
	 private String  gumGage;
	
	 
	 /**
	  * E2_AVE_METER
	  * 사용가능일
	  */
	 private String useDay;
	 
	 private String befUsage;
	 
	 private String monUsage;
	 
	 private String weekUsage;
	 
	 private String avgMonth;
	 
	 private String avgDay;
	 
	 private String finishLevelImg;
	 

	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap(){
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("C_MNG_NO", getClientNumber());
		keys.put("CUST_CODE", getCustomerCode());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}
	
	/**
	 * getters/setters
	 * @return
	 */
	public String getClientNumber() {
		return clientNumber;
	}

	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustCount() {
		return custCount;
	}

	public void setCustCount(String custCount) {
		this.custCount = custCount;
	}

	public String getCustTel() {
		return custTel;
	}

	public void setCustTel(String custTel) {
		this.custTel = custTel;
	}

	public String getCustHp() {
		return custHp;
	}

	public void setCustHp(String custHp) {
		this.custHp = custHp;
	}

	public String getZipCd() {
		return zipCd;
	}

	public void setZipCd(String zipCd) {
		this.zipCd = zipCd;
	}

	public String getAddr1() {
		return addr1;
	}

	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}

	public String getAddr2() {
		return addr2;
	}

	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}

	public String getGpsX() {
		return gpsX;
	}

	public void setGpsX(String gpsX) {
		this.gpsX = gpsX;
	}

	public String getGpsY() {
		return gpsY;
	}

	public void setGpsY(String gpsY) {
		this.gpsY = gpsY;
	}

	public String getSwCode() {
		return swCode;
	}

	public void setSwCode(String swCode) {
		this.swCode = swCode;
	}

	public String getSwName() {
		return swName;
	}

	public void setSwName(String swName) {
		this.swName = swName;
	}

	public String getcAreaCode() {
		return cAreaCode;
	}

	public void setcAreaCode(String cAreaCode) {
		this.cAreaCode = cAreaCode;
	}

	public String getcAreaName() {
		return cAreaName;
	}

	public void setcAreaName(String cAreaName) {
		this.cAreaName = cAreaName;
	}

	public String getTransmCd() {
		return transmCd;
	}

	public void setTransmCd(String transmCd) {
		this.transmCd = transmCd;
	}

	public String getcType() {
		return cType;
	}

	public void setcType(String cType) {
		this.cType = cType;
	}

	public String getTankVol() {
		return tankVol;
	}

	public void setTankVol(String tankVol) {
		this.tankVol = tankVol;
	}

	public String getcVol() {
		return cVol;
	}

	public void setcVol(String cVol) {
		this.cVol = cVol;
	}

	public String getcQty() {
		return cQty;
	}

	public void setcQty(String cQty) {
		this.cQty = cQty;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	
	/**
	 * @param lastRdate the lastRdate to set
	 */
	public String getLastRdate() {
		return lastRdate;
	}

	public void setLastRdate(String lastRdate) {
		this.lastRdate = lastRdate;
	}

	/**
	 * @param e2Date1 the e2Date1 to set
	 */
	public String getE2Date1() {
		return e2Date1;
	}

	public void setE2Date1(String e2Date1) {
		this.e2Date1 = e2Date1;
	}

	/**
	 * @param e2AveDate the e2AveDate to set
	 */
	public String getE2AveDate() {
		return e2AveDate;
	}

	public void setE2AveDate(String e2AveDate) {
		this.e2AveDate = e2AveDate;
	}

	/**
	 * @param e2AveMeter the e2AveMeter to set
	 */
	public String getE2AveMeter() {
		return e2AveMeter;
	}

	public void setE2AveMeter(String e2AveMeter) {
		this.e2AveMeter = e2AveMeter;
	}
	
	/**
	 * @param e2AveMeter the e2AveMeter to set
	 */
	public String getGumGage() {
		return gumGage;
	}

	public void setGumGage(String gumGage) {
		this.gumGage = gumGage;
	}
	
	/**
	 * @param e2AveMeter the e2AveMeter to set
	 */
	public String getUseDay() {
		return useDay;
	}

	public void setUseDay(String useDay) {
		this.useDay = useDay;
	}
	

	public String getBefUsage() {
		return befUsage;
	}

	public void setBefUsage(String befUsage) {
		this.befUsage = befUsage;
	}
	
	public String getMonUsage() {
		return monUsage;
	}

	public void setMonUsage(String monUsage) {
		this.monUsage = monUsage;
	}
	
	public String getWeekUsage() {
		return weekUsage;
	}

	public void setWeekUsage(String weekUsage) {
		this.weekUsage = weekUsage;
	}
	
	public String getAvgMonth() {
		return avgMonth;
	}

	public void setAvgMonth(String avgMonth) {
		this.avgMonth = avgMonth;
	}

	public String getAvgDay() {
		return avgDay;
	}

	public void setAvgDay(String avgDay) {
		this.avgDay = avgDay;
	}
	
	public String getFinishLevelImg() {
		return finishLevelImg;
	}

	public void setFinishLevelImg(String finishLevelImg) {
		this.finishLevelImg = finishLevelImg;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CustomerInfo [key=" + this.getKeyValue() 
				+ ", clientNumber=" + clientNumber
				+ ", customerCode=" + customerCode
				+ ", customerName=" + customerName
				+ ", custCount=" + custCount
				+ ", custTel=" + custTel
				+ ", custHp=" + custHp
				+ ", zipCd=" + zipCd
				+ ", addr1=" + addr1
				+ ", addr2=" + addr2
				+ ", gpsX=" + gpsX
				+ ", gpsY=" + gpsY
				+ ", swCode=" + swCode
				+ ", swName=" + swName
				+ ", cAreaCode=" + cAreaCode
				+ ", cAreaName=" + cAreaName
				+ ", transmCd=" + transmCd
				+ ", cType=" + cType
				+ ", tankVol=" + tankVol
				+ ", cVol=" + cVol
				+ ", cQty=" + cQty
				+ ", remark=" + remark 
				+ ", lastRdate=" + lastRdate
				+ ", e2Date1=" + e2Date1
				+ ", e2AveDate=" + e2AveDate
				+ ", e2AveMeter=" + e2AveMeter
				+ ", gumGage=" + gumGage
				+ ", useDay=" + useDay
				+ ", befUsage=" + befUsage
				+ ", monUsage=" + monUsage
				+ ", weekUsage=" + weekUsage
				+ ", avgMonth=" + avgMonth
				+ ", avgDay=" + avgDay
				+ ", finishLevelImg=" + finishLevelImg
				+ "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<CustomerInfo><key>" + this.getKeyValue()
				+ "</key><clientNumber>" + clientNumber + "</clientNumber>"
				+ "<customerCode>" + customerCode + "</customerCode>"
				+ "<customerName><![CDATA[" + customerName + "]]></customerName>"
				+ "<custCount>" + custCount + "</custCount>"
				+ "<custTel>" + custTel + "</custTel>"
				+ "<custHp>" + custHp + "</custHp>"
				+ "<zipCd>" + zipCd + "</zipCd>"
				+ "<addr1><![CDATA[" + addr1 + "]]></addr1>"
				+ "<addr2><![CDATA[" + addr2 + "]]></addr2>"
				+ "<gpsX>" + gpsX + "</gpsX>"
				+ "<gpsY>" + gpsY + "</gpsY>"
				+ "<swCode>" + swCode + "</swCode>"
				+ "<swName><![CDATA[" + swName + "]]></swName>"
				+ "<cAreaCode>" + cAreaCode + "</cAreaCode>"
				+ "<cAreaName><![CDATA[" + cAreaName + "]]></cAreaName>"
				+ "<transmCd>" + transmCd + "</transmCd>"
				+ "<cType>" + cType + "</cType>"
				+ "<tankVol>" + tankVol + "</tankVol>"
				+ "<cVol>" + cVol + "</cVol>"
				+ "<cQty>" + cQty + "</cQty>"
				+ "<remark>" + remark + "</remark>"
				+ "<lastRdate>" + lastRdate  + "</lastRdate>"
				+ "<e2Date1>" + e2Date1 + "</e2Date1>"
				+ "<e2AveDate>" + e2AveDate + "</e2AveDate>"
				+ "<e2AveMeter>" + e2AveMeter + "</e2AveMeter>"
				+ "<gumGage>" + gumGage + "</gumGage>"
				+ "<useDay>" + useDay + "</useDay>"
				+ "<befUsage>" + befUsage + "</befUsage>"
				+ "<monUsage>" + monUsage + "</monUsage>"
				+ "<weekUsage>" + weekUsage + "</weekUsage>"
				+ "<avgMonth>" + avgMonth + "</avgMonth>"
				+ "<avgDay>" + avgDay + "</avgDay>"
				+ "<finishLevelImg>" + finishLevelImg + "</finishLevelImg>"
				+ "</CustomerInfo>";
	}
}
