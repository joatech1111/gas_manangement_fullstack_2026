package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 원격검침 레벨 카운트 모델
 * @author 네오브랜딩
 * @version 1.0
 */
public class CheckVolumeLevelCount {
	/**
	 * CMNGNO	
	 * 고객번호 - key
	 */
	 private String clientNumber;

	 /**
	 * LVL_STATE = 0, 1, 2, 3	
	 * 합계
	 */
	 private String levelStateAll;

	 /**
	 * STATE_OK	
	 * 정상
	 */
	 private String levelStateOk;
	 
	 /**
	 * R_DATE_OVER	
	 * 미수신
	 */
	 private String receiveDateOver;
	 
	 /**
	 * DONGIL_YN	
	 * 동일레벨
	 */
	 private String uniformLevel;

	 /**
	 * LOW_BAT	
	 * 배터리
	 */
	 private String lowBattery;

	/**
	 * @return the levelStateAll
	 */
	public String getLevelStateAll() {
		return levelStateAll;
	}

	/**
	 * @param levelStateAll the levelStateAll to set
	 */
	public void setLevelStateAll(String levelStateAll) {
		this.levelStateAll = levelStateAll;
	}

	/**
	 * @return the stateOk
	 */
	public String getLevelStateOk() {
		return levelStateOk;
	}

	/**
	 * @param levelStateOk the levelStateOk to set
	 */
	public void setLevelStateOk(String levelStateOk) {
		this.levelStateOk = levelStateOk;
	}

	/**
	 * @return the receiveDateOver
	 */
	public String getReceiveDateOver() {
		return receiveDateOver;
	}

	/**
	 * @param receiveDateOver the receiveDateOver to set
	 */
	public void setReceiveDateOver(String receiveDateOver) {
		this.receiveDateOver = receiveDateOver;
	}

	/**
	 * @return the uniformLevel
	 */
	public String getUniformLevel() {
		return uniformLevel;
	}

	/**
	 * @param uniformLevel the uniformLevel to set
	 */
	public void setUniformLevel(String uniformLevel) {
		this.uniformLevel = uniformLevel;
	}

	/**
	 * @return the lowBattery
	 */
	public String getLowBattery() {
		return lowBattery;
	}

	/**
	 * @param lowBattery the lowBattery to set
	 */
	public void setLowBattery(String lowBattery) {
		this.lowBattery = lowBattery;
	}
	
	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap(){
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("C_MNG_NO", getClientNumber());
		
		return keys; 
	}

	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}	
	
	/**
	 * @return the clientNumber
	 */
	public String getClientNumber() {
		return clientNumber;
	}

	/**
	 * @param clientNumber the clientNumber to set
	 */
	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CheckVolumeLevelCount [key=" + this.getKeyValue()
				+ ", clientNumber=" + clientNumber
				+ ", levelStateAll=" + levelStateAll
				+ ", levelStateOk=" + levelStateOk
				+ ", receiveDateOver="	+ receiveDateOver
				+ ", uniformLevel=" + uniformLevel
				+ ", lowBattery=" + lowBattery
				+ "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<CheckVolumeLevelCount><key>" + this.getKeyValue() + "</key><clientNumber>" 
				+ clientNumber + "</clientNumber><levelStateAll>"
				+ levelStateAll + "</levelStateAll><levelStateOk>"
				+ levelStateOk + "</levelStateOk><receiveDateOver>"
				+ receiveDateOver + "</receiveDateOver><uniformLevel>"
				+ uniformLevel + "</uniformLevel><lowBattery>"
				+ lowBattery + "</lowBattery></CheckVolumeLevelCount>";
	}
	
	/**
	 * JSON 문자열 반환
	 * @return JSON
	 */
	public String toJSON() {
		return "{\"key\":\"" + this.getKeyValue()
				+ "\", \"levelStateAll\":\"" + levelStateAll
				+ "\", \"levelStateOk\":\"" + levelStateOk
				+ "\", \"receiveDateOver\":\""	+ receiveDateOver
				+ "\", \"uniformLevel\":\"" + uniformLevel
				+ "\", \"lowBattery\":\"" + lowBattery
				+ "\"}";
	}		
}
