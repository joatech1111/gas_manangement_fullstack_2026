package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 주간수신내역 정보 모델
 * @author 네오브랜딩
 * @version 1.0
 */
public class CylinderList {
	/**
	 * CMNGNO	
	 * 고객번호 - key
	 */
	 private String clientNumber;

	/**
	 * CUSTCODE	
	 * 거래처코드 - key
	 */
	 private String customerCode;

	/**
	 * TRANSMCD	
	 * 발신기코드
	 */
	 private String transmitterCode;


	/**
	 * CUSTNAME	
	 * 거래처명
	 */
	 private String customerName;

	/**
	 * INSTDATE	
	 * 설치일자
	 */
	 private String installationDate;

	/**
	 * CUSTTEL	
	 * 전화번호
	 */
	 private String phoneNumber;

	/**
	 * CUSTHP	
	 * 핸드폰
	 */
	 private String mobileNumber;

	/**
	 * ADDR	
	 * 주소
	 */
	 private String address;

	/**
	 * C_VOL_NAME
	 * 품목명
	 */
	private String itemName;

	/**
	 * C_QTY
	 * 수량
	 */
	private String itemQty;
	
	/**
	 * REMARK	
	 * 비고
	 */
	 private String remark;

    /**
	 * LVL9
	 * 레벨D9
	 */
	 private String level9;

    /**
	 * LVL8
	 * 레벨D8
	 */
	 private String level8;

    /**
	 * LVL7
	 * 레벨D7
	 */
	 private String level7;

	/**
	 * LVL6
	 * 레벨D6
	 */
	 private String level6;
	 
	 /**
	  * LVL5
	  * 레벨D5
	  */
	 private String level5;
	 
	 /**
	  * LVL4	
	  * 레벨D4
	  */
	 private String level4;

	/**
	 * LVL3	
	 * 레벨D3
	 */
	 private String level3;

	/**
	 * LVL2	
	 * 레벨D2
	 */
	 private String level2;

	/**
	 * LVL1	
	 * 레벨D1 
	 */
	 private String level1;

	/**
	 * LVL0	
	 * 레벨D0
	 */
	 private String level0;

	/**
	 * LVL_STATE
	 * 레벨 LVL_STATE
	 */
	 private String lastLevel;
	 
	 /**
	  * C_VOL_QTY
	  * 품목 C_VOL_QTY
	  */
	 private String volQty;
	 
	 /**
	  * GUM_GAGE
	  * 완료 ㎥
	  */
	 private String gumGage;
	 
	 /**
	  * GUM_GAGE_COLER
	  * 완료 ㎥
	  */
	 private String gumGageColer;
	 
	 /**
	  * GUM_GAGE_COLER
	  * 완료 ㎥
	  */
	 private String lastRMeter;
	 
	 /**
	  * CUST_NAME_COLER
	  * 거래처명 색상
	  */
	 private String custNameColer;
	 
	 

	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap(){
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("C_MNG_NO", getClientNumber());
		keys.put("CUSTCODE", getCustomerCode());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}

	/**
	 * @return the clientNumber
	 */
	public String getClientNumber() {
		return clientNumber;
	}

	/**
	 * @param clientNumber the clientNumber to set
	 */
	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	/**
	 * @return the customerCode
	 */
	public String getCustomerCode() {
		return customerCode;
	}

	/**
	 * @param customerCode the customerCode to set
	 */
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	/**
	 * @return the transmitterCode
	 */
	public String getTransmitterCode() {
		return transmitterCode;
	}

	/**
	 * @param transmitterCode the transmitterCode to set
	 */
	public void setTransmitterCode(String transmitterCode) {
		this.transmitterCode = transmitterCode;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the installationDate
	 */
	public String getInstallationDate() {
		return installationDate;
	}

	/**
	 * @param installationDate the installationDate to set
	 */
	public void setInstallationDate(String installationDate) {
		this.installationDate = installationDate;
	}

	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * @return the mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * @param mobileNumber the mobileNumber to set
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the itemName
	 */
	public String getItemName() {
		return itemName;
	}

	/**
	 * @param itemName the itemName to set
	 */
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	/**
	 * @return the itemQty
	 */
	public String getItemQty() {
		return itemQty;
	}

	/**
	 * @param itemQty the itemQty to set
	 */
	public void setItemQty(String itemQty) {
		this.itemQty = itemQty;
	}

	/**
	 * @return the remark
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * @param remark the remark to set
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}

	/**
	 * @return the level9
	 */
	public String getLevel9() {
		return level9;
	}

	/**
	 * @param level9 the level9 to set
	 */
	public void setLevel9(String level9) {
		this.level9 = level9;
	}

	/**
	 * @return the level8
	 */
	public String getLevel8() {
		return level8;
	}

	/**
	 * @param level8 the level8 to set
	 */
	public void setLevel8(String level8) {
		this.level8 = level8;
	}

	/**
	 * @return the level7
	 */
	public String getLevel7() {
		return level7;
	}

	/**
	 * @param level7 the level7 to set
	 */
	public void setLevel7(String level7) {
		this.level7 = level7;
	}

	/**
	 * @return the level6
	 */
	public String getLevel6() {
		return level6;
	}

	/**
	 * @param level6 the level6 to set
	 */
	public void setLevel6(String level6) {
		this.level6 = level6;
	}

	/**
	 * @return the level5
	 */
	public String getLevel5() {
		return level5;
	}

	/**
	 * @param level5 the level5 to set
	 */
	public void setLevel5(String level5) {
		this.level5 = level5;
	}

	/**
	 * @return the level4
	 */
	public String getLevel4() {
		return level4;
	}

	/**
	 * @param level4 the level4 to set
	 */
	public void setLevel4(String level4) {
		this.level4 = level4;
	}

	/**
	 * @return the level3
	 */
	public String getLevel3() {
		return level3;
	}

	/**
	 * @param level3 the level3 to set
	 */
	public void setLevel3(String level3) {
		this.level3 = level3;
	}

	/**
	 * @return the level2
	 */
	public String getLevel2() {
		return level2;
	}

	/**
	 * @param level2 the level2 to set
	 */
	public void setLevel2(String level2) {
		this.level2 = level2;
	}

	/**
	 * @return the level1
	 */
	public String getLevel1() {
		return level1;
	}

	/**
	 * @param level1 the level1 to set
	 */
	public void setLevel1(String level1) {
		this.level1 = level1;
	}

	/**
	 * @return the level0
	 */
	public String getLevel0() {
		return level0;
	}

	/**
	 * @param lastLevel the lastLevel to set
	 */
	public void setLevel0(String level0) {
		this.level0 = level0;
	}

	/**
	 * @return the level0
	 */
	public String getLastLevel() {
		return lastLevel;
	}

	/**
	 * @param level0 the level0 to set
	 */
	public void setLastLevel(String lastLevel) {
		this.lastLevel = lastLevel;
	}
	
	/**
	 * @return the volQty
	 */
	public String getVolQty() {
		return volQty;
	}
	
	/**
	 * @param level0 the level0 to set
	 */
	public void setVolQty(String volQty) {
		this.volQty = volQty;
	}
	
	/**
	 * @return the gumGage
	 */
	public String getGumGage() {
		return gumGage;
	}
	
	/**
	 * @param level0 the level0 to set
	 */
	public void setGumGage(String gumGage) {
		this.gumGage = gumGage;
	}
	
	/**
	 * @return the gumGageColer
	 */
	public String getGumGageColer() {
		return gumGageColer;
	}
	
	/**
	 * @param level0 the level0 to set
	 */
	public void setGumGageColer(String gumGageColer) {
		this.gumGageColer = gumGageColer;
	}
	
	/**
	 * @return the lastRMeter
	 */
	public String getLastRMeter() {
		return lastRMeter;
	}
	
	/**
	 * @param level0 the level0 to set
	 */
	public void setLastRMeter(String lastRMeter) {
		this.lastRMeter = lastRMeter;
	}
	
	public String getCustNameColer() {
		return custNameColer;
	}

	public void setCustNameColer(String custNameColer) {
		this.custNameColer = custNameColer;
	}
	
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CylinderList [key=" + this.getKeyValue() + ", clientNumber="
				+ clientNumber
				+ ", customerCode="
				+ customerCode
				+ ", transmitterCode="
				+ transmitterCode
				+ ", customerName="
				+ customerName
				+ ", installationDate="
				+ installationDate
				+ ", phoneNumber="
				+ phoneNumber
				+ ", mobileNumber="
				+ mobileNumber
				+ ", address="
				+ address
				+ ", itemName="
				+ itemName
				+ ", itemQty="
				+ itemQty
				+ ", remark="
				+ remark
				+ ", level9="
				+ level9
				+ ", level8="
				+ level8
				+ ", level7="
				+ level7
				+ ", level6="
				+ level6
				+ ", level5="
				+ level5
				+ ", level4="
				+ level4
				+ ", level3="
				+ level3
				+ ", level2="
				+ level2
				+ ", level1="
				+ level1
				+ ", level0="
				+ level0
				+ ", lastLevel="
				+ lastLevel
				+ ", volQty="
				+ volQty
				+ ", gumGage="
				+ gumGage
				+ ", gumGageColer="
				+ gumGageColer
				+ ", custNameColer="
				+ custNameColer
				+ ", lastRMeter="
				+ lastRMeter
				+ "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<CylinderList><key>" + this.getKeyValue() + "</key><clientNumber>"
				+ clientNumber
				+ "</clientNumber><customerCode>"
				+ customerCode
				+ "</customerCode><transmitterCode>"
				+ transmitterCode
				+ "</transmitterCode><customerName><![CDATA["
				+ customerName
				+ "]]></customerName><installationDate>"
				+ installationDate
				+ "</installationDate><phoneNumber>"
				+ phoneNumber
				+ "</phoneNumber><mobileNumber>"
				+ mobileNumber
				+ "</mobileNumber><address><![CDATA["
				+ address
				+ "]]></address><itemName><![CDATA["
				+ itemName
				+ "]]></itemName><itemQty>"
				+ itemQty
				+ "</itemQty><remark><![CDATA["
				+ remark
				+ "]]></remark><level9>"
				+ level9
				+ "</level9><level8>"
				+ level8
				+ "</level8><level7>"
				+ level7
				+ "</level7><level6>"
				+ level6
				+ "</level6><level5>"
				+ level5
				+ "</level5><level4>"
				+ level4
				+ "</level4><level3>"
				+ level3
				+ "</level3><level2>"
				+ level2
				+ "</level2><level1>"
				+ level1
				+ "</level1><level0>"
				+ level0 + "</level0><lastLevel>"
				+ lastLevel + "</lastLevel><volQty>"
				+ volQty + "</volQty><gumGage>"
				+ gumGage + "</gumGage><gumGageColer>"
				+ gumGageColer + "</gumGageColer><custNameColer>"
				+ custNameColer + "</custNameColer><lastRMeter>"
				+ lastRMeter + "</lastRMeter></CylinderList>";
	}
}
