package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 거래처 정보
 * @author 네오브랜딩
 * @version 1.0
 */

public class CylinderPlanInfo {
	/**
	 * 업체코드 - key
	 */
	private String clientNumber;

	/**
	 * 거래처 코드 - key
	 */
	private String customerCode;

	/**
	 * 검침 거래처코드
	 */
	private String customerMCode;

	/**
	 * 절체기 거래처코드
	 */
	private String customerJCode;

	/**
	 * 발신기코드
	 */
	private String transmCd;
	
	/**
	 * 공급품목 용량
	 */
	private String cVol;
	
	/**
	 * 공급수량
	 */
	private String cQty;
	
	/**
	 * 계량기 개수 (1개,2개,5개 …)
	 */
	private String meterQty;
	
	/**
	 * 검침 최종수신일시
	 */
	private String rCountDt;
	
	/**
	 * 검침 합계량
	 */
	private String rCountSum;
	
	/**
	 * 예상공급 사용량 설정값 
	 */
	private String setCount;
	
	/**
	 * 조회구분 (1.조회일 등록자료, 2.최근 등록자료, 3.최초등록)
	 */
	private String getType;
	
	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap(){
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("C_MNG_NO", getClientNumber());
		keys.put("CUST_CODE", getCustomerCode());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}
	
	/**
	 * getters/setters
	 * @return
	 */
	public String getClientNumber() {
		return clientNumber;
	}

	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}
	
	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getCustomerMCode() {
		return customerMCode;
	}

	public void setCustomerMCode(String customerMCode) {
		this.customerMCode = customerMCode;
	}

	public String getCustomerJCode() {
		return customerJCode;
	}

	public void setCustomerJCode(String customerJCode) {
		this.customerJCode = customerJCode;
	}

	public String getTransmCd() {
		return transmCd;
	}

	public void setTransmCd(String transmCd) {
		this.transmCd = transmCd;
	}

	public String getcVol() {
		return cVol;
	}

	public void setcVol(String cVol) {
		this.cVol = cVol;
	}

	public String getcQty() {
		return cQty;
	}

	public void setcQty(String cQty) {
		this.cQty = cQty;
	}

	public String getMeterQty() {
		return meterQty;
	}

	public void setMeterQty(String meterQty) {
		this.meterQty = meterQty;
	}

	public String getrCountDt() {
		return rCountDt;
	}

	public void setrCountDt(String rCountDt) {
		this.rCountDt = rCountDt;
	}

	public String getrCountSum() {
		return rCountSum;
	}

	public void setrCountSum(String rCountSum) {
		this.rCountSum = rCountSum;
	}

	public String getSetCount() {
		return setCount;
	}

	public void setSetCount(String setCount) {
		this.setCount = setCount;
	}

	public String getGetType() {
		return getType;
	}

	public void setGetType(String getType) {
		this.getType = getType;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CylinderPlanInfo [key=" + this.getKeyValue() 
				+ ", clientNumber=" + clientNumber
				+ ", customerCode=" + customerCode
				+ ", customerMCode=" + customerMCode
				+ ", customerJCode=" + customerJCode
				+ ", transmCd=" + transmCd
				+ ", cVol=" + cVol
				+ ", cQty=" + cQty
				+ ", meterQty=" + meterQty
				+ ", rCountDt=" + rCountDt
				+ ", rCountSum=" + rCountSum
				+ ", setCount=" + setCount
				+ ", getType="
				+ getType + "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<CylinderPlanInfo><key>" + this.getKeyValue()
				+ "</key><clientNumber>" + clientNumber + "</clientNumber>"
				+ "<customerCode>" + customerCode + "</customerCode>"
				+ "<customerMCode>" + customerMCode + "</customerMCode>"
				+ "<customerJCode>" + customerJCode + "</customerJCode>"
				+ "<transmCd>" + transmCd + "</transmCd>"
				+ "<cVol>" + cVol + "</cVol>"
				+ "<cQty>" + cQty + "</cQty>"
				+ "<meterQty>" + meterQty + "</meterQty>"
				+ "<rCountDt>" + rCountDt + "</rCountDt>"
				+ "<rCountSum>" + rCountSum + "</rCountSum>"
				+ "<setCount>" + setCount + "</setCount>"
				+ "<getType>" + getType + "</getType>"
				+ "</CylinderPlanInfo>";
	}
}
