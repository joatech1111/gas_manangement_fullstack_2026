package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 거래처 정보
 * @author 네오브랜딩
 * @version 1.0
 */

public class CylinderSupplyList {
	/**
	 * 업체코드 - key
	 */
	private String clientNumber;

	/**
	 * 거래처 코드 - key
	 */
	private String customerCode;

	/**
	 * 공급일자
	 */
	private String cDate;

	/**
	 * 공급 등록시간(hhmm)
	 */
	private String cTime;

	/**
	 * 발신기코드
	 */
	private String transmCd;

	/**
	 * 검침 거래처 코드
	 */
	private String custMCode;
	
	/**
	 * 절체기 거래처 코드
	 */
	private String custJCode;

	/**
	 * 등록구분 (2:절체기, 3: 검침)
	 */
	private String jmDiv;
	
	/**
	 * 거래처명
	 */
	private String customerName;
	
	/**
	 * 공급품목 용량
	 */
	private String cVol;
	
	/**
	 * 공급수량
	 */
	private String cQty;
	
	/**
	 * 품목명(용량*수량)
	 */
	private String cVolQty;
	
	/**
	 * 검침 최종수신일시
	 */
	private String rCountDt;
	
	/**
	 * 검침 합계량
	 */
	private String rCountSum;
	
	/**
	 * 예상공급 사용량 설정값
	 */
	private String setCount;

	/**
	 * 사용자명 ( 01020906987_홍길동) 
	 */
	private String wkId;
	
	
	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap(){
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("JM_DIV", getJmDiv());
		keys.put("C_MNG_NO", getClientNumber());
		keys.put("CUST_CODE", getCustomerCode());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}
	
	/**
	 * getters/setters
	 * @return
	 */
	public String getClientNumber() {
		return clientNumber;
	}

	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getcDate() {
		return cDate;
	}

	public void setcDate(String cDate) {
		this.cDate = cDate;
	}

	public String getcTime() {
		return cTime;
	}

	public void setcTime(String cTime) {
		this.cTime = cTime;
	}

	public String getTransmCd() {
		return transmCd;
	}

	public void setTransmCd(String transmCd) {
		this.transmCd = transmCd;
	}

	public String getCustMCode() {
		return custMCode;
	}

	public void setCustMCode(String custMCode) {
		this.custMCode = custMCode;
	}

	public String getCustJCode() {
		return custJCode;
	}

	public void setCustJCode(String custJCode) {
		this.custJCode = custJCode;
	}

	public String getJmDiv() {
		return jmDiv;
	}

	public void setJmDiv(String jmDiv) {
		this.jmDiv = jmDiv;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getcVol() {
		return cVol;
	}

	public void setcVol(String cVol) {
		this.cVol = cVol;
	}

	public String getcQty() {
		return cQty;
	}

	public void setcQty(String cQty) {
		this.cQty = cQty;
	}

	public String getcVolQty() {
		return cVolQty;
	}

	public void setcVolQty(String cVolQty) {
		this.cVolQty = cVolQty;
	}

	public String getrCountDt() {
		return rCountDt;
	}

	public void setrCountDt(String rCountDt) {
		this.rCountDt = rCountDt;
	}

	public String getrCountSum() {
		return rCountSum;
	}

	public void setrCountSum(String rCountSum) {
		this.rCountSum = rCountSum;
	}

	public String getSetCount() {
		return setCount;
	}

	public void setSetCount(String setCount) {
		this.setCount = setCount;
	}

	public String getWkId() {
		return wkId;
	}

	public void setWkId(String wkId) {
		this.wkId = wkId;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CylinderSupplyList [key=" + this.getKeyValue() 
				+ ", clientNumber=" + clientNumber
				+ ", customerCode=" + customerCode
				+ ", cDate=" + cDate
				+ ", cTime=" + cTime
				+ ", transmCd=" + transmCd
				+ ", custMCode=" + custMCode
				+ ", custJCode=" + custJCode
				+ ", jmDiv=" + jmDiv
				+ ", customerName=" + customerName
				+ ", cVol=" + cVol
				+ ", cQty=" + cQty
				+ ", cVolQty=" + cVolQty
				+ ", rCountDt=" + rCountDt
				+ ", rCountSum=" + rCountSum
				+ ", setCount=" + setCount
				+ ", wkId="
				+ wkId + "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<CylinderSupplyList><key>" + this.getKeyValue()
				+ "</key><clientNumber>" + clientNumber + "</clientNumber>"
				+ "<customerCode>" + customerCode + "</customerCode>"
				+ "<cDate>" + cDate + "</cDate>"
				+ "<cTime>" + cTime + "</cTime>"
				+ "<transmCd>" + transmCd + "</transmCd>"
				+ "<custMCode>" + custMCode + "</custMCode>"
				+ "<custJCode>" + custJCode + "</custJCode>"
				+ "<jmDiv>" + jmDiv + "</jmDiv>"
				+ "<customerName>" + customerName + "</customerName>"
				+ "<cVol>" + cVol + "</cVol>"
				+ "<cQty>" + cQty + "</cQty>"
				+ "<cVolQty>" + cVolQty + "</cVolQty>"
				+ "<rCountDt>" + rCountDt + "</rCountDt>"
				+ "<rCountSum>" + rCountSum + "</rCountSum>"
				+ "<setCount>" + setCount + "</setCount>"
				+ "<wkId>" + wkId + "</wkId>"
				+ "</CylinderSupplyList>";
	}
}
