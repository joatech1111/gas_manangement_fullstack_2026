package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 탱크잔량조회 정보 모델
 * @author 서경엔씨에스
 * @version 1.0
 */
public class TankLevelList {
	/**
	 * C_MNG_NO	
	 * 업체번호
	 */
	 private String clientNumber;

	/**
	 * CUST_CODE	
	 * 거래처코드
	 */
	 private String customerCode;
	 
	/**
	 * TANK_CODE	
	 * 탱크코드
	 */
	 private String tankCode;

	/**
	 * TRANSM_CD	
	 * 발신기코드
	 */
	 private String transmitterCode;
	 
	/**
	 * CUST_NAME	
	 * 거래처명
	 */	 
	 private String customerName;
	 
	 /**
	 * CUST_TEL	
	 * 전화번호
	 */
	 private String customerTel;
	 
	 /**
	 * CUST_HP	
	 * 핸드폰 번호
	 */
	 private String customerHp;
	 
	 /**
	 * SW_CODE	
	 * 담당 사원코드
	 */
	 private String sawonCode;
	 
	 /**
	 * SW_CODE_NAME	
	 * 담당 사원명
	 */
	 private String sawonName;
	 
	 /**
	 * AREA_CODE	
	 * 지역분류코드
	 */
	 private String areaTypeCode;
	 
	 /**
	 * AREA_CODE_NAME	
	 * 지역분류명
	 */
	 private String areaTypeName;
	 
	/**
	 * ZIP_CO 
	 * 우편번호
	 */
	 private String zipCode;
	 
	/**
	 * ADDR 
	 * 주소
	 */
	 private String address;
	 
	 /**
	 * MAP_POINT_X	
	 * 위도
	 */
	 private String latitude;
	 
	 /**
	 * MAP_POINT_Y	
	 * 경도
	 */
	 private String longitude;
	 
	 /**
	 * ALARM_LEVEL	
	 * 경보레벨(%)
	 */
	 private String alarmLevel;
	 
	 /**
	 * RMKS	
	 * 비고
	 */
	 private String remark;
	 
	 /**
	 * MAKE_CO	
	 * 제조사
	 */
	 private String makeCompany;
	 
	 /**
	 * TANK_SNO	
	 * 모델명
	 */
	 private String tankSerialNumber;
	 
	 /**
	 * MAKE_SNO	
	 * 제조번호
	 */
	 private String makeSerialNumber;
	 
	 /**
	 * TANK_VOL	
	 * 탱크용량
	 */
	 private String tankVolume;
	 
	 /**
	 * MAKE_DATE	
	 * 제조일
	 */
	 private String makeDate;
	 
	 /**
	 * TANK_RCV	
	 * 대여처
	 */
	 private String tankReceive;
	 
	 /**
	 * INST_DATE	
	 * 설치일자
	 */
	 private String installDate;
	 
	 /**
	 * INSP_DATE	
	 * 검사 : 최종 검사일
	 */
	 private String inspectDate;
	 
	 /**
	 * INSP_EXP_DATE	
	 * 검사 : 검사 예정일
	 */
	 private String inspectExpectDate;
	 
	 /**
	 * MM_CNT	
	 * 검사 : 잔여 개월
	 */
	 private String monthCount;
	 
	 /**
	 * DD_CNT	
	 * 검사 : 잔여 일자
	 */
	 private String dayCount;
	 
	/**
	 * LVL_9
	 * 주간수신 잔량(%) D-9일
	 */
	 private String level9;
	 
	 /**
	 * LVL_8
	 * 주간수신 잔량(%) D-8일
	 */
	 private String level8;
	 
	 /**
	 * LVL_7
	 * 주간수신 잔량(%) D-7일
	 */
	 private String level7;

	 /**
	 * LVL_6
	 * 주간수신 잔량(%) D-6일
	 */
	 private String level6;
	 
	 /**
	 * LVL_5
	 * 주간수신 잔량(%) D-5일
	 */
	 private String level5;
	 
	 /**
	 * LVL_4
	 * 주간수신 잔량(%) D-4일
	 */
	 private String level4;

	 /**
	 * LVL_3
	 * 주간수신 잔량(%) D-3일
	 */
	 private String level3;

	 /**
	 * LVL_2
	 * 주간수신 잔량(%) D-2일
	 */
	 private String level2;

	 /**
	 * LVL_1
	 * 주간수신 잔량(%) D-1일
	 */
	 private String level1;

	 /**
	 * LVL_0
	 * 주간수신 잔량(%) D-0일
	 */
	 private String level0;
	 
	 /**
	 * TRANSM_SNO
	 * 발신기명
	 */
	 private String transmitterSerialNumber;
	 
	 /**
	 * TRANSM_TYPE_NAME
	 * 발신기 모델
	 */
	 private String transmitterTypeName;
	 
	 /**
	 * TRANSM_BAT_NAME
	 * 전원 방식
	 */
	 private String transmitterBatteryName;
	 
	 /**
	 * TRANSM_TEL
	 * CDMA 전화번호
	 */
	 private String transmitterTel;
	 
	 /**
	 * TRANSM_RENT_YN
	 * 임대여부 (값 : Y)
	 */
	 private String transmitterRent;
	 
	 /**
	 * LAST_R_DATE
	 * 최근 수신일 (YYYYMMDD)
	 */
	 private String lastReceiveDate;
	 
	 /**
	 * LAST_R_TIME
	 * 최근 수신시간 (HHNNSS)
	 */
	 private String lastReceiveTime;
	 
	 /**
	 * LVL_LAST
	 * 최종수신 잔량
	 */
	 private String lastLevel;
	 
	 /**
	 * R_EVENT_DIV
	 * 수신이벤트
	 */
	 private String receiveEvent;
	 
	 /**
	 * R_EVENT_NAME
	 * 수신이벤트명
	 */
	 private String receiveEventName;
	 
	 /**
	 * BAT_PERCENT
	 * 베터리 잔량 (%)
	 */
	 private String batteryPercent;
	 
	 /**
	 * R_BAT_VOLT
	 * 베터리 전압(V) (0은 배터리 잔량체크 안되는 발신기)
	 */
	 private String receiveBatteryVolt;
	 
	 /**
	 * LVL_STATE
	 * 잔량 레벨 상태코드 (0:긴급, 1:경보, 2:주의, 3:정상)
	 */
	 private String levelState;
	 
	 /**
	 * R_DATE_OVER
	 * 미수신 거래처 유무 (값 : Y)
	 */
	 private String receiveDateOver;
	 
	 /**
	 * DONGIL_YN
	 * 동일레벨 유무(조회일-7일) (값 : Y)
	 */
	 private String uniformLevel;
	 
	 /**
	 * LOW_BAT
	 * LOW 베터리 유무 (값 : Y)
	 */
	 private String lowBattery;

	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap(){
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("C_MNG_NO", getClientNumber());
		keys.put("CUST_CODE", getCustomerCode());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}

	/**
	 * @return the clientNumber
	 */
	public String getClientNumber() {
		return clientNumber;
	}

	/**
	 * @param clientNumber the clientNumber to set
	 */
	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	/**
	 * @return the tankCode
	 */
	public String getTankCode() {
		return tankCode;
	}

	/**
	 * @param tankCode the tankCode to set
	 */
	public void setTankCode(String tankCode) {
		this.tankCode = tankCode;
	}

	/**
	 * @return the customerCode
	 */
	public String getCustomerCode() {
		return customerCode;
	}

	/**
	 * @param customerCode the customerCode to set
	 */
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	/**
	 * @return the transmitterCode
	 */
	public String getTransmitterCode() {
		return transmitterCode;
	}

	/**
	 * @param transmitterCode the transmitterCode to set
	 */
	public void setTransmitterCode(String transmitterCode) {
		this.transmitterCode = transmitterCode;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the level6
	 */
	public String getLevel6() {
		return level6;
	}

	/**
	 * @param level6 the level6 to set
	 */
	public void setLevel6(String level6) {
		this.level6 = level6;
	}

	/**
	 * @return the level5
	 */
	public String getLevel5() {
		return level5;
	}

	/**
	 * @param level5 the level5 to set
	 */
	public void setLevel5(String level5) {
		this.level5 = level5;
	}

	/**
	 * @return the level4
	 */
	public String getLevel4() {
		return level4;
	}

	/**
	 * @param level4 the level4 to set
	 */
	public void setLevel4(String level4) {
		this.level4 = level4;
	}

	/**
	 * @return the level3
	 */
	public String getLevel3() {
		return level3;
	}

	/**
	 * @param level3 the level3 to set
	 */
	public void setLevel3(String level3) {
		this.level3 = level3;
	}

	/**
	 * @return the level2
	 */
	public String getLevel2() {
		return level2;
	}

	/**
	 * @param level2 the level2 to set
	 */
	public void setLevel2(String level2) {
		this.level2 = level2;
	}

	/**
	 * @return the level1
	 */
	public String getLevel1() {
		return level1;
	}

	/**
	 * @param level1 the level1 to set
	 */
	public void setLevel1(String level1) {
		this.level1 = level1;
	}

	/**
	 * @return the level0
	 */
	public String getLevel0() {
		return level0;
	}

	/**
	 * @param level0 the level0 to set
	 */
	public void setLevel0(String level0) {
		this.level0 = level0;
	}

	/**
	 * @return the lastReceiveDate
	 */
	public String getLastReceiveDate() {
		return lastReceiveDate;
	}

	/**
	 * @param lastReceiveDate the lastReceiveDate to set
	 */
	public void setLastReceiveDate(String lastReceiveDate) {
		this.lastReceiveDate = lastReceiveDate;
	}

	/**
	 * @return the lastLevel
	 */
	public String getLastLevel() {
		return lastLevel;
	}

	/**
	 * @param lastLevel the lastLevel to set
	 */
	public void setLastLevel(String lastLevel) {
		this.lastLevel = lastLevel;
	}

	/**
	 * @return the customerTel
	 */
	public String getCustomerTel() {
		return customerTel;
	}

	/**
	 * @param customerTel the customerTel to set
	 */
	public void setCustomerTel(String customerTel) {
		this.customerTel = customerTel;
	}

	/**
	 * @return the customerHp
	 */
	public String getCustomerHp() {
		return customerHp;
	}

	/**
	 * @param customerHp the customerHp to set
	 */
	public void setCustomerHp(String customerHp) {
		this.customerHp = customerHp;
	}

	/**
	 * @return the sawonCode
	 */
	public String getSawonCode() {
		return sawonCode;
	}

	/**
	 * @param sawonCode the sawonCode to set
	 */
	public void setSawonCode(String sawonCode) {
		this.sawonCode = sawonCode;
	}

	/**
	 * @return the sawonName
	 */
	public String getSawonName() {
		return sawonName;
	}

	/**
	 * @param sawonName the sawonName to set
	 */
	public void setSawonName(String sawonName) {
		this.sawonName = sawonName;
	}

	/**
	 * @return the areaTypeCode
	 */
	public String getAreaTypeCode() {
		return areaTypeCode;
	}

	/**
	 * @param areaTypeCode the areaTypeCode to set
	 */
	public void setAreaTypeCode(String areaTypeCode) {
		this.areaTypeCode = areaTypeCode;
	}

	/**
	 * @return the areaTypeName
	 */
	public String getAreaTypeName() {
		return areaTypeName;
	}

	/**
	 * @param areaTypeName the areaTypeName to set
	 */
	public void setAreaTypeName(String areaTypeName) {
		this.areaTypeName = areaTypeName;
	}

	/**
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}

	/**
	 * @param zipCode the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	/**
	 * @return the latitude
	 */
	public String getLatitude() {
		return latitude;
	}

	/**
	 * @param latitude the latitude to set
	 */
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	/**
	 * @return the longitude
	 */
	public String getLongitude() {
		return longitude;
	}

	/**
	 * @param longitude the longitude to set
	 */
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	/**
	 * @return the alarmLevel
	 */
	public String getAlarmLevel() {
		return alarmLevel;
	}

	/**
	 * @param alarmLevel the alarmLevel to set
	 */
	public void setAlarmLevel(String alarmLevel) {
		this.alarmLevel = alarmLevel;
	}

	/**
	 * @return the remark
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * @param remark the remark to set
	 */
	public void setRemark(String remark) {
		if (remark != null) {
			remark = remark.replaceAll("(\\r|\\n|\\r\\n|\\t)+", " ");
		}
		
		this.remark = remark;
	}

	/**
	 * @return the makeCompany
	 */
	public String getMakeCompany() {
		return makeCompany;
	}

	/**
	 * @param makeCompany the makeCompany to set
	 */
	public void setMakeCompany(String makeCompany) {
		this.makeCompany = makeCompany;
	}

	/**
	 * @return the tankSerialNumber
	 */
	public String getTankSerialNumber() {
		return tankSerialNumber;
	}

	/**
	 * @param tankSerialNumber the tankSerialNumber to set
	 */
	public void setTankSerialNumber(String tankSerialNumber) {
		this.tankSerialNumber = tankSerialNumber;
	}

	/**
	 * @return the makeSerialNumber
	 */
	public String getMakeSerialNumber() {
		return makeSerialNumber;
	}

	/**
	 * @param makeSerialNumber the makeSerialNumber to set
	 */
	public void setMakeSerialNumber(String makeSerialNumber) {
		this.makeSerialNumber = makeSerialNumber;
	}

	/**
	 * @return the tankVolume
	 */
	public String getTankVolume() {
		return tankVolume;
	}

	/**
	 * @param tankVolume the tankVolume to set
	 */
	public void setTankVolume(String tankVolume) {
		this.tankVolume = tankVolume;
	}

	/**
	 * @return the makeDate
	 */
	public String getMakeDate() {
		return makeDate;
	}

	/**
	 * @param makeDate the makeDate to set
	 */
	public void setMakeDate(String makeDate) {
		this.makeDate = makeDate;
	}

	/**
	 * @return the tankReceive
	 */
	public String getTankReceive() {
		return tankReceive;
	}

	/**
	 * @param tankReceive the tankReceive to set
	 */
	public void setTankReceive(String tankReceive) {
		this.tankReceive = tankReceive;
	}

	/**
	 * @return the installDate
	 */
	public String getInstallDate() {
		return installDate;
	}

	/**
	 * @param installDate the installDate to set
	 */
	public void setInstallDate(String installDate) {
		this.installDate = installDate;
	}

	/**
	 * @return the inspectDate
	 */
	public String getInspectDate() {
		return inspectDate;
	}

	/**
	 * @param inspectDate the inspectDate to set
	 */
	public void setInspectDate(String inspectDate) {
		this.inspectDate = inspectDate;
	}

	/**
	 * @return the inspectExpectDate
	 */
	public String getInspectExpectDate() {
		return inspectExpectDate;
	}

	/**
	 * @param inspectExpectDate the inspectExpectDate to set
	 */
	public void setInspectExpectDate(String inspectExpectDate) {
		this.inspectExpectDate = inspectExpectDate;
	}

	/**
	 * @return the monthCount
	 */
	public String getMonthCount() {
		return monthCount;
	}

	/**
	 * @param monthCount the monthCount to set
	 */
	public void setMonthCount(String monthCount) {
		this.monthCount = monthCount;
	}

	/**
	 * @return the dayCount
	 */
	public String getDayCount() {
		return dayCount;
	}

	/**
	 * @param dayCount the dayCount to set
	 */
	public void setDayCount(String dayCount) {
		this.dayCount = dayCount;
	}

	/**
	 * @return the level9
	 */
	public String getLevel9() {
		return level9;
	}

	/**
	 * @param level9 the level9 to set
	 */
	public void setLevel9(String level9) {
		this.level9 = level9;
	}

	/**
	 * @return the level8
	 */
	public String getLevel8() {
		return level8;
	}

	/**
	 * @param level8 the level8 to set
	 */
	public void setLevel8(String level8) {
		this.level8 = level8;
	}

	/**
	 * @return the level7
	 */
	public String getLevel7() {
		return level7;
	}

	/**
	 * @param level7 the level7 to set
	 */
	public void setLevel7(String level7) {
		this.level7 = level7;
	}

	/**
	 * @return the transmitterSerialNumber
	 */
	public String getTransmitterSerialNumber() {
		return transmitterSerialNumber;
	}

	/**
	 * @param transmitterSerialNumber the transmitterSerialNumber to set
	 */
	public void setTransmitterSerialNumber(String transmitterSerialNumber) {
		this.transmitterSerialNumber = transmitterSerialNumber;
	}

	/**
	 * @return the transmitterTypeName
	 */
	public String getTransmitterTypeName() {
		return transmitterTypeName;
	}

	/**
	 * @param transmitterTypeName the transmitterTypeName to set
	 */
	public void setTransmitterTypeName(String transmitterTypeName) {
		this.transmitterTypeName = transmitterTypeName;
	}

	/**
	 * @return the transmitterBatteryName
	 */
	public String getTransmitterBatteryName() {
		return transmitterBatteryName;
	}

	/**
	 * @param transmitterBatteryName the transmitterBatteryName to set
	 */
	public void setTransmitterBatteryName(String transmitterBatteryName) {
		this.transmitterBatteryName = transmitterBatteryName;
	}

	/**
	 * @return the transmitterTel
	 */
	public String getTransmitterTel() {
		return transmitterTel;
	}

	/**
	 * @param transmitterTel the transmitterTel to set
	 */
	public void setTransmitterTel(String transmitterTel) {
		this.transmitterTel = transmitterTel;
	}

	/**
	 * @return the transmitterRent
	 */
	public String getTransmitterRent() {
		return transmitterRent;
	}

	/**
	 * @param transmitterRent the transmitterRent to set
	 */
	public void setTransmitterRent(String transmitterRent) {
		this.transmitterRent = transmitterRent;
	}

	/**
	 * @return the lastReceiveTime
	 */
	public String getLastReceiveTime() {
		return lastReceiveTime;
	}

	/**
	 * @param lastReceiveTime the lastReceiveTime to set
	 */
	public void setLastReceiveTime(String lastReceiveTime) {
		this.lastReceiveTime = lastReceiveTime;
	}

	/**
	 * @return the receiveEvent
	 */
	public String getReceiveEvent() {
		return receiveEvent;
	}

	/**
	 * @param receiveEvent the receiveEvent to set
	 */
	public void setReceiveEvent(String receiveEvent) {
		this.receiveEvent = receiveEvent;
	}

	/**
	 * @return the receiveEventName
	 */
	public String getReceiveEventName() {
		return receiveEventName;
	}

	/**
	 * @param receiveEventName the receiveEventName to set
	 */
	public void setReceiveEventName(String receiveEventName) {
		this.receiveEventName = receiveEventName;
	}

	/**
	 * @return the batteryPercent
	 */
	public String getBatteryPercent() {
		return batteryPercent;
	}

	/**
	 * @param batteryPercent the batteryPercent to set
	 */
	public void setBatteryPercent(String batteryPercent) {
		this.batteryPercent = batteryPercent;
	}

	/**
	 * @return the receiveBatteryVolt
	 */
	public String getReceiveBatteryVolt() {
		return receiveBatteryVolt;
	}

	/**
	 * @param receiveBatteryVolt the receiveBatteryVolt to set
	 */
	public void setReceiveBatteryVolt(String receiveBatteryVolt) {
		this.receiveBatteryVolt = receiveBatteryVolt;
	}

	/**
	 * @return the levelState
	 */
	public String getLevelState() {
		return levelState;
	}

	/**
	 * @param levelState the levelState to set
	 */
	public void setLevelState(String levelState) {
		this.levelState = levelState;
	}

	/**
	 * @return the receiveDateOver
	 */
	public String getReceiveDateOver() {
		return receiveDateOver;
	}

	/**
	 * @param receiveDateOver the receiveDateOver to set
	 */
	public void setReceiveDateOver(String receiveDateOver) {
		this.receiveDateOver = receiveDateOver;
	}

	/**
	 * @return the uniformLevel
	 */
	public String getUniformLevel() {
		return uniformLevel;
	}

	/**
	 * @param uniformLevel the uniformLevel to set
	 */
	public void setUniformLevel(String uniformLevel) {
		this.uniformLevel = uniformLevel;
	}

	/**
	 * @return the lowBattery
	 */
	public String getLowBattery() {
		return lowBattery;
	}

	/**
	 * @param lowBattery the lowBattery to set
	 */
	public void setLowBattery(String lowBattery) {
		this.lowBattery = lowBattery;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TankLevelList [key=" + this.getKeyValue()
				+ ", clientNumber=" + clientNumber
				+ ", customerCode="	+ customerCode
				+ ", tankCode="	+ tankCode
				+ ", transmitterCode=" + transmitterCode
				+ ", customerName="	+ customerName
				+ ", customerTel=" + customerTel
				+ ", customerHp=" + customerHp
				+ ", sawonCode=" + sawonCode
				+ ", sawonName=" + sawonName
				+ ", areaTypeCode="	+ areaTypeCode
				+ ", areaTypeName="	+ areaTypeName
				+ ", zipCode=" + zipCode
				+ ", address=" + address
				+ ", latitude="	+ latitude
				+ ", longitude=" + longitude
				+ ", alarmLevel=" + alarmLevel
				+ ", remark=" + remark
				+ ", makeCompany=" + makeCompany
				+ ", tankSerialNumber=" + tankSerialNumber
				+ ", makeSerialNumber=" + makeSerialNumber
				+ ", tankVolume=" + tankVolume
				+ ", makeDate=" + makeDate
				+ ", tankReceive=" + tankReceive
				+ ", installDate=" + installDate
				+ ", inspectDate=" + inspectDate
				+ ", inspectExpectDate=" + inspectExpectDate
				+ ", monthCount=" + monthCount
				+ ", dayCount=" + dayCount
				+ ", level9=" + level9
				+ ", level8=" + level8
				+ ", level7=" + level7
				+ ", level6=" + level6
				+ ", level5=" + level5
				+ ", level4=" + level4
				+ ", level3=" + level3
				+ ", level2=" + level2
				+ ", level1=" + level1
				+ ", level0=" + level0
				+ ", transmitterSerialNumber=" + transmitterSerialNumber
				+ ", transmitterTypeName=" + transmitterTypeName
				+ ", transmitterBatteryName=" + transmitterBatteryName
				+ ", transmitterTel=" + transmitterTel
				+ ", transmitterRent=" + transmitterRent
				+ ", lastReceiveDate=" + lastReceiveDate
				+ ", lastReceiveTime=" + lastReceiveTime
				+ ", lastLevel=" + lastLevel
				+ ", receiveEvent=" + receiveEvent
				+ ", receiveEventName=" + receiveEventName
				+ ", batteryPercent=" + batteryPercent
				+ ", receiveBatteryVolt=" + receiveBatteryVolt
				+ ", levelState=" + levelState
				+ ", receiveDateOver=" + receiveDateOver
				+ ", uniformLevel=" + uniformLevel
				+ ", lowBattery=" + lowBattery
				+ "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<TankLevelList><key>" + this.getKeyValue() + "</key><clientNumber>"
				+ clientNumber + "</clientNumber><customerCode>"
				+ customerCode + "</customerCode><tankCode>"
				+ tankCode + "</tankCode><transmitterCode>"
				+ transmitterCode + "</transmitterCode><customerName><![CDATA["
				+ customerName + "]]></customerName><customerTel>"
				+ customerTel + "</customerTel><customerHp>"
				+ customerHp + "</customerHp><sawonCode>"
				+ sawonCode + "</sawonCode><sawonName><![CDATA["
				+ sawonName + "]]></sawonName><areaTypeCode>"
				+ areaTypeCode + "</areaTypeCode><areaTypeName><![CDATA["
				+ areaTypeName + "]]></areaTypeName><zipCode>"
				+ zipCode + "</zipCode><address><![CDATA["
				+ address + "]]></address><latitude>"
				+ latitude + "</latitude><longitude>"
				+ longitude + "</longitude><alarmLevel>"
				+ alarmLevel + "</alarmLevel><remark><![CDATA["
				+ remark + "]]></remark><makeCompany><![CDATA["
				+ makeCompany + "]]></makeCompany><tankSerialNumber><![CDATA["
				+ tankSerialNumber + "]]></tankSerialNumber><makeSerialNumber><![CDATA["
				+ makeSerialNumber + "]]></makeSerialNumber><tankVolume>"
				+ tankVolume + "</tankVolume><makeDate>"
				+ makeDate + "</makeDate><tankReceive><![CDATA["
				+ tankReceive + "]]></tankReceive><installDate>"
				+ installDate + "</installDate><inspectDate>"
				+ inspectDate + "</inspectDate><inspectExpectDate>"
				+ inspectExpectDate + "</inspectExpectDate><monthCount>"
				+ monthCount + "</monthCount><dayCount>"
				+ dayCount + "</dayCount><level9>"
				+ level9 + "</level9><level8>"
				+ level8 + "</level8><level7>"
				+ level7 + "</level7><level6>"
				+ level6 + "</level6><level5>"
				+ level5 + "</level5><level4>"
				+ level4 + "</level4><level3>"
				+ level3 + "</level3><level2>"
				+ level2 + "</level2><level1>"
				+ level1 + "</level1><level0>"
				+ level0 + "</level0><transmitterSerialNumber><![CDATA["
				+ transmitterSerialNumber + "]]></transmitterSerialNumber><transmitterTypeName><![CDATA["
				+ transmitterTypeName + "]]></transmitterTypeName><transmitterBatteryName><![CDATA["
				+ transmitterBatteryName + "]]></transmitterBatteryName><transmitterTel>"
				+ transmitterTel + "</transmitterTel><transmitterRent>"
				+ transmitterRent + "</transmitterRent><lastReceiveDate>"
				+ lastReceiveDate + "</lastReceiveDate><lastReceiveTime>"
				+ lastReceiveTime + "</lastReceiveTime><lastLevel>"
				+ lastLevel + "</lastLevel><receiveEvent>"
				+ receiveEvent + "</receiveEvent><receiveEventName><![CDATA["
				+ receiveEventName + "]]></receiveEventName><batteryPercent>"
				+ batteryPercent + "</batteryPercent><receiveBatteryVolt>"
				+ receiveBatteryVolt + "</receiveBatteryVolt><levelState>"
				+ levelState + "</levelState><receiveDateOver>"
				+ receiveDateOver + "</receiveDateOver><uniformLevel>"
				+ uniformLevel + "</uniformLevel><lowBattery>"
				+ lowBattery + "</lowBattery></TankLevelList>";
	}
	
	/**
	 * JSON 문자열 반환
	 * @return JSON
	 */
	public String toJSON() {
		return "{\"key\":\"" + this.getKeyValue()
				+ "\", \"clientNumber\":\"" + clientNumber
				+ "\", \"customerCode\":\""	+ customerCode
				+ "\", \"tankCode\":\""	+ tankCode
				+ "\", \"transmitterCode\":\"" + transmitterCode
				+ "\", \"customerName\":\""	+ customerName
				+ "\", \"customerTel\":\"" + customerTel
				+ "\", \"customerHp\":\"" + customerHp
				+ "\", \"sawonCode\":\"" + sawonCode
				+ "\", \"sawonName\":\"" + sawonName
				+ "\", \"areaTypeCode\":\""	+ areaTypeCode
				+ "\", \"areaTypeName\":\""	+ areaTypeName
				+ "\", \"zipCode\":\"" + zipCode
				+ "\", \"address\":\"" + address
				+ "\", \"latitude\":\""	+ latitude
				+ "\", \"longitude\":\"" + longitude
				+ "\", \"alarmLevel\":\"" + alarmLevel
				+ "\", \"remark\":\"" + remark
				+ "\", \"makeCompany\":\"" + makeCompany
				+ "\", \"tankSerialNumber\":\"" + tankSerialNumber
				+ "\", \"makeSerialNumber\":\"" + makeSerialNumber
				+ "\", \"tankVolume\":\"" + tankVolume
				+ "\", \"makeDate\":\"" + makeDate
				+ "\", \"tankReceive\":\"" + tankReceive
				+ "\", \"installDate\":\"" + installDate
				+ "\", \"inspectDate\":\"" + inspectDate
				+ "\", \"inspectExpectDate\":\"" + inspectExpectDate
				+ "\", \"monthCount\":\"" + monthCount
				+ "\", \"dayCount\":\"" + dayCount
				+ "\", \"level9\":\"" + level9
				+ "\", \"level8\":\"" + level8
				+ "\", \"level7\":\"" + level7
				+ "\", \"level6\":\"" + level6
				+ "\", \"level5\":\"" + level5
				+ "\", \"level4\":\"" + level4
				+ "\", \"level3\":\"" + level3
				+ "\", \"level2\":\"" + level2
				+ "\", \"level1\":\"" + level1
				+ "\", \"level0\":\"" + level0
				+ "\", \"transmitterSerialNumber\":\"" + transmitterSerialNumber
				+ "\", \"transmitterTypeName\":\"" + transmitterTypeName
				+ "\", \"transmitterBatteryName\":\"" + transmitterBatteryName
				+ "\", \"transmitterTel\":\"" + transmitterTel
				+ "\", \"transmitterRent\":\"" + transmitterRent
				+ "\", \"lastReceiveDate\":\"" + lastReceiveDate
				+ "\", \"lastReceiveTime\":\"" + lastReceiveTime
				+ "\", \"lastLevel\":\"" + lastLevel
				+ "\", \"receiveEvent\":\"" + receiveEvent
				+ "\", \"receiveEventName\":\"" + receiveEventName
				+ "\", \"batteryPercent\":\"" + batteryPercent
				+ "\", \"receiveBatteryVolt\":\"" + receiveBatteryVolt
				+ "\", \"levelState\":\"" + levelState
				+ "\", \"receiveDateOver\":\"" + receiveDateOver
				+ "\", \"uniformLevel\":\"" + uniformLevel
				+ "\", \"lowBattery\":\"" + lowBattery
				+ "\"}";
	}
		
}
