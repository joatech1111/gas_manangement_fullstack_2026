package com.joainfo.gasmaxplus.bean;

import java.util.LinkedHashMap;

import com.joainfo.common.util.StringUtil;

/**
 * 업체정보 정보 모델
 * @author 서경엔씨에스
 * @version 1.0
 */
public class MyCompany {
	/**
	 * C_MNG_NO	
	 * 업체번호
	 */
	 private String clientNumber;
	 
	/**
	 * COMP_NAME	
	 * 업체명
	 */	 
	 private String companyName;
	 
	/**
	 * ZIP_CO 
	 * 우편번호
	 */
	 private String zipCode;
	 
	/**
	 * ADDR 
	 * 주소
	 */
	 private String address;
	 
	 /**
	 * MAP_POINT_X	
	 * 위도
	 */
	 private String latitude;
	 
	 /**
	 * MAP_POINT_Y	
	 * 경도
	 */
	 private String longitude;
	 
	/**
	 * key map 반환
	 * @return
	 */
	public LinkedHashMap<String, String> getKeyMap(){
		LinkedHashMap<String, String> keys = new LinkedHashMap<String, String>();
		keys.put("C_MNG_NO", getClientNumber());
		
		return keys; 
	}
	
	/**
	 * key 값 반환
	 * @return
	 */
	public String getKeyValue(){
		return StringUtil.getKeyValue(this.getKeyMap()); 
	}

	/**
	 * @return the clientNumber
	 */
	public String getClientNumber() {
		return clientNumber;
	}

	/**
	 * @param clientNumber the clientNumber to set
	 */
	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	/**
	 * @return the companyName
	 */
	public String getCompanyName() {
		return companyName;
	}

	/**
	 * @param companyName the companyName to set
	 */
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}

	/**
	 * @param zipCode the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	/**
	 * @return the latitude
	 */
	public String getLatitude() {
		return latitude;
	}

	/**
	 * @param latitude the latitude to set
	 */
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	/**
	 * @return the longitude
	 */
	public String getLongitude() {
		return longitude;
	}

	/**
	 * @param longitude the longitude to set
	 */
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MyCompany [key=" + this.getKeyValue()
				+ ", clientNumber=" + clientNumber
				+ ", companyName="	+ companyName
				+ ", zipCode=" + zipCode
				+ ", address=" + address
				+ ", latitude="	+ latitude
				+ ", longitude=" + longitude
				+ "]";
	}

	/**
	 * XML 문자열 반환
	 * @return XML
	 */
	public String toXML() {
		return "<MyCompany><key>" + this.getKeyValue() + "</key><clientNumber>"
				+ clientNumber + "</clientNumber><companyName><![CDATA["
				+ companyName + "]]></companyName><zipCode>"
				+ zipCode + "</zipCode><address><![CDATA["
				+ address + "]]></address><latitude>"
				+ latitude + "</latitude><longitude>"
				+ longitude + "</longitude></MyCompany>";
	}
	
	/**
	 * JSON 문자열 반환
	 * @return JSON
	 */
	public String toJSON() {
		return "{\"key\":\"" + this.getKeyValue()
				+ "\", \"clientNumber\":\"" + clientNumber
				+ "\", \"companyName\":\""	+ companyName
				+ "\", \"zipCode\":\"" + zipCode
				+ "\", \"address\":\"" + address
				+ "\", \"latitude\":\""	+ latitude
				+ "\", \"longitude\":\"" + longitude
				+ "\"}";
	}
		
}
